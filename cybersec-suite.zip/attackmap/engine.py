"""
AttackMap engine: watch an external attack surface and notice when it changes.

The premise: an attack surface is not a static list, it is a moving target, and
almost every real breach starts with something *new* appearing -- a forgotten
subdomain resolving again, a test server left running, a new port on a
production host, a certificate issued for a service nobody remembers.

So this product is built around diffing rather than scanning. The interesting
output is not "here is your surface", it is "here is what changed since
Tuesday, and here is why it matters".

Discovery sources, in order of preference:

1. **Supplied inventory** -- a file the operator already has (nmap export,
   asset register, CMDB). The most accurate source and the only one that can
   cover internal hosts.
2. **Passive certificate transparency** -- public CT logs list certificates
   without probing anything. Finds forgotten hosts nothing else would.
3. **Authorised connect probes** -- a TCP connect and a service banner grab,
   scope-enforced and rate limited. Bounded by :data:`PROBE_LIMITS`.

Not implemented: UDP sweeps (unreliable and noisy), OS fingerprinting beyond
banner inspection, any form of exploitation. See the README.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import re
import socket
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Optional

from core.models import Evidence, Finding, Severity, utcnow

PRODUCT = "attackmap"

# Bounds on authorised probing. These are not defaults to be raised casually:
# a connect sweep against a range you do not own is a network attack.
PROBE_LIMITS = {
    "max_hosts": 50,
    "max_ports_per_host": 12,
    "timeout_s": 2.0,
    "per_host_delay_s": 0.2,
}

COMMON_PORTS = [21, 22, 25, 53, 80, 110, 143, 443, 445, 587, 993, 995,
                1433, 1521, 3000, 3306, 3389, 5000, 5432, 5900, 6379, 8000,
                8080, 8443, 9000, 9200, 27017]

# Ports that are worth a finding when they appear unexpectedly.
SENSITIVE_PORTS = {
    21: ("FTP", "Credentials sent in cleartext; anonymous access is common."),
    23: ("Telnet", "Unencrypted administrative access."),
    22: ("SSH", "Administrative access; expected, but should be key-only."),
    445: ("SMB", "Windows file sharing exposed beyond the internal network."),
    1433: ("MSSQL", "Database port exposed to the internet."),
    3306: ("MySQL", "Database port exposed to the internet."),
    5432: ("PostgreSQL", "Database port exposed to the internet."),
    6379: ("Redis", "Redis defaults to no authentication at all."),
    9200: ("Elasticsearch", "Frequently deployed with no authentication."),
    27017: ("MongoDB", "Frequently deployed with no authentication."),
    3389: ("RDP", "Remote desktop; a standard ransomware entry point."),
    5900: ("VNC", "Remote desktop, usually weakly protected."),
}

DEV_HINTS = re.compile(
    r"(^|[.\-])(dev|test|stage|staging|qa|uat|sandbox|demo|proto|preview|"
    r"beta|alpha|tmp|temp|old|legacy|backup|bak|uat)([.\-]|$)", re.I)

ADMIN_HINTS = re.compile(r"(^|[.\-])(admin|internal|intranet|vpn|mgmt|"
                         r"manage|ops|jump|bastion)([.\-]|$)", re.I)


@dataclass
class Service:
    """
    One reachable service.

    ``service`` is the second field rather than ``protocol``. With ``protocol``
    second, ``Service(8080, "nginx")`` silently bound "nginx" to the protocol,
    which changed the service key from ``tcp/8080`` to ``nginx/8080`` and made
    every service-change comparison silently miss. Positional construction is
    common enough in this codebase's tests that the field order is worth
    getting right rather than documenting "use keywords".
    """
    port: int
    service: str = "unknown"
    protocol: str = "tcp"
    state: str = "open"
    banner: str = ""
    tls: bool = False
    cert_subject: str = ""
    cert_issuer: str = ""
    cert_expires: str = ""
    cert_fingerprint: str = ""

    def key(self) -> str:
        return f"{self.protocol}/{self.port}"


@dataclass
class Host:
    """One asset."""
    hostname: str
    addresses: list[str] = field(default_factory=list)
    services: list[Service] = field(default_factory=list)
    source: str = "unknown"        # inventory | ct | probe
    first_seen: str = field(default_factory=utcnow)

    def ports(self) -> set[int]:
        return {s.port for s in self.services if s.state == "open"}

    def service_keys(self) -> set[str]:
        return {s.key() for s in self.services if s.state == "open"}

    def cert_fingerprints(self) -> set[str]:
        return {s.cert_fingerprint for s in self.services
                if s.cert_fingerprint}

    def key(self) -> str:
        return self.hostname.lower().strip(".")


@dataclass
class Snapshot:
    """A complete observation of the surface at one moment."""
    taken_at: str = field(default_factory=utcnow)
    scope: str = ""
    hosts: list[Host] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)

    def host_map(self) -> dict[str, Host]:
        return {h.key(): h for h in self.hosts}

    def totals(self) -> dict:
        services = [s for h in self.hosts for s in h.services if s.state == "open"]
        return {
            "hosts": len(self.hosts),
            "open_ports": len(services),
            "tls_endpoints": sum(1 for s in services if s.tls),
            "distinct_services": len({s.service for s in services
                                      if s.service != "unknown"}),
        }

    def to_json(self) -> str:
        return json.dumps({
            "taken_at": self.taken_at,
            "scope": self.scope,
            "sources": self.sources,
            "hosts": [asdict(h) for h in self.hosts],
        }, indent=2)

    @classmethod
    def from_json(cls, text: str) -> "Snapshot":
        data = json.loads(text)
        hosts = []
        for raw in data.get("hosts", []):
            services = [Service(**s) for s in raw.get("services", [])]
            hosts.append(Host(hostname=raw["hostname"],
                              addresses=raw.get("addresses", []),
                              services=services,
                              source=raw.get("source", "unknown"),
                              first_seen=raw.get("first_seen", utcnow())))
        return cls(taken_at=data.get("taken_at", utcnow()),
                   scope=data.get("scope", ""), hosts=hosts,
                   sources=data.get("sources", []))


# -- discovery -----------------------------------------------------------

def load_inventory(path: str) -> list[Host]:
    """
    Read an existing inventory.

    Accepts this tool's own snapshot format and a simple CSV of
    ``hostname,ip,port,service``. An operator who already has an asset list
    should never have to re-derive it, and re-deriving it is exactly how
    shadow assets get missed.
    """
    hosts: dict[str, Host] = {}
    with open(path, encoding="utf-8") as handle:
        if path.endswith(".json"):
            snapshot = Snapshot.from_json(handle.read())
            return snapshot.hosts

        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split(",")]
            hostname = parts[0]
            if not hostname:
                continue
            host = hosts.setdefault(hostname, Host(hostname=hostname,
                                                   source="inventory"))
            if len(parts) > 1 and parts[1]:
                try:
                    ipaddress.ip_address(parts[1])
                    host.addresses.append(parts[1])
                except ValueError:
                    pass
            if len(parts) > 2 and parts[2].isdigit():
                host.services.append(Service(
                    port=int(parts[2]),
                    service=parts[3] if len(parts) > 3 else "unknown",
                    state=parts[4] if len(parts) > 4 else "open"))
    return list(hosts.values())


def from_ct_log(domain: str, log=print) -> list[Host]:
    """
    Derive hostnames from certificate transparency logs.

    CT logs are public records of certificates issued. Reading them is passive:
    nothing is probed, so this is the one discovery method that is always
    authorized regardless of who owns the domain.

    Network access is optional and failure is non-fatal -- the tool is fully
    useful from an inventory alone, and a scanner that cannot start because a
    public API is down is a scanner that gets uninstalled.
    """
    log = log or (lambda *a: None)
    try:
        import httpx
        response = httpx.get(
            f"https://crt.sh/?q=%25.{domain}&output=json", timeout=20.0)
        response.raise_for_status()
        records = response.json()
    except Exception as exc:
        log(f"  CT log unavailable ({type(exc).__name__}); continuing without it")
        return []

    hosts: dict[str, Host] = {}
    for record in records:
        for name in str(record.get("name_value", "")).split("\n"):
            name = name.strip().lstrip("*.").lower()
            if not name or not name.endswith(domain.lower()):
                continue
            if name in hosts:
                continue
            issuer = str(record.get("issuer_name", "")).split("\n")[0]
            hosts[name] = Host(
                hostname=name, source="ct",
                services=[Service(
                    port=443, protocol="tcp", service="https", tls=True,
                    cert_subject=record.get("common_name", name),
                    cert_issuer=issuer,
                    cert_expires=str(record.get("not_after", ""))[:10],
                    cert_fingerprint=_cert_key(record))])
    log(f"  {len(hosts)} hostname(s) from certificate transparency")
    return list(hosts.values())


def _cert_key(record: dict) -> str:
    raw = "|".join(str(record.get(k, "")) for k in
                   ("common_name", "issuer_name", "not_after", "serial_number"))
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def probe_host(hostname: str, ports: Optional[list[int]] = None,
               scope_note: str = "", log=print) -> Host:
    """
    Connect probe against one hostname.

    Bounded twice over: the port list is capped, and every port is checked
    against the caller-declared scope before a socket is opened. A scanner that
    will happily connect to anything it is handed is a scanner that will be
    pointed at a network by someone who should not have it.
    """
    ports = list(ports or COMMON_PORTS)[: PROBE_LIMITS["max_ports_per_host"]]
    if scope_note:
        log(f"  scope: {scope_note}")
    host = Host(hostname=hostname, source="probe")

    try:
        host.addresses.append(socket.gethostbyname(hostname))
    except socket.gaierror:
        pass    # does not resolve: still a finding, handled in the diff

    for port in ports:
        if not _port_in_scope(port, scope_note):
            continue
        result = _connect(hostname, port)
        if result is None:
            continue
        service = result
        host.services.append(service)
        log(f"  open {port}/{service.protocol} {service.service}")

    time.sleep(PROBE_LIMITS["per_host_delay_s"])
    return host


def _port_in_scope(port: int, scope_note: str) -> bool:
    """
    Enforce a declared port scope.

    ``"22,443"`` or ``"80-443"``. An empty scope means no restriction beyond
    the tool's own cap, which is stated rather than assumed.
    """
    if not scope_note:
        return True
    for part in scope_note.split(","):
        part = part.strip()
        if "-" in part:
            low, _, high = part.partition("-")
            if low.strip().isdigit() and high.strip().isdigit():
                if int(low) <= port <= int(high):
                    return True
        elif part.isdigit() and int(part) == port:
            return True
    return False


def _connect(hostname: str, port: int, timeout: float = None) -> Optional[Service]:
    """
    One TCP connect, then a passive banner grab if the service offers one.

    Only connect() is used -- no half-open SYN sweep. A SYN sweep from
    unprivileged code also produces a distinctive traffic pattern that looks
    exactly like an attack, which is not a trade worth making for speed.
    """
    timeout = timeout or PROBE_LIMITS["timeout_s"]
    service = Service(port=port)
    try:
        with socket.create_connection((hostname, port), timeout=timeout) as sock:
            service.state = "open"
            service.service = _service_name(port)
            try:
                sock.settimeout(0.6)
                if port == 443:
                    import ssl
                    context = ssl.create_default_context()
                    context.check_hostname = False
                    context.verify_mode = ssl.CERT_NONE
                    with context.wrap_socket(sock, server_hostname=hostname) as tls:
                        cert = tls.getpeercert()
                        if cert:
                            for field_pair in cert.get("subject", ()):
                                for key, value in field_pair:
                                    if key == "commonName":
                                        service.cert_subject = value
                            service.cert_issuer = dict(
                                x[0] for x in cert.get("issuer", ())).get(
                                    "organizationName", "")
                            service.cert_expires = cert.get("notAfter", "")
                        service.tls = True
                        return service
                banner = sock.recv(256).decode("utf-8", "replace").strip()
                service.banner = banner[:200]
            except (socket.timeout, ssl_errors(), OSError):
                pass    # silent service, which is normal and not a problem
            return service
    except (socket.timeout, ConnectionRefusedError, socket.gaierror, OSError):
        return None


def ssl_errors():
    import ssl
    return ssl.SSLError


def _service_name(port: int) -> str:
    """
    Best-effort service label.

    ``SENSITIVE_PORTS`` is authoritative for the ports it lists; a second map
    naming some of the same ports differently meant port 22 resolved to "SSH"
    here and "ssh" elsewhere, so a service-change check comparing two labels
    could report a change that never happened.
    """
    if port in SENSITIVE_PORTS:
        return SENSITIVE_PORTS[port][0]
    return {80: "http", 443: "https", 25: "smtp", 8080: "http-alt",
            8443: "https-alt", 3000: "http-alt", 5000: "http-alt",
            9000: "http-alt"}.get(port, "unknown")


# -- the diff ------------------------------------------------------------

@dataclass
class Change:
    """One difference between two snapshots."""
    kind: str                    # host_added | host_removed | port_added |
                                 # port_removed | service_changed |
                                 # cert_changed | host_resolved |
                                 # host_unresolved
    subject: str
    detail: str
    severity: Severity
    significance: str = ""      # why this matters, in one clause
    evidence: dict = field(default_factory=dict)

    def key(self) -> str:
        return f"{self.kind}|{self.subject}|{self.detail}"

    def fingerprint(self) -> str:
        raw = f"{self.kind}|{self.subject}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def to_finding(self, scope: str) -> Finding:
        detector = f"attackmap:{self.kind}"
        return Finding(
            title=self.detail,
            severity=self.severity,
            category="A05:2021 Security Misconfiguration",
            target=scope, location=self.subject,
            detector=detector, product=PRODUCT,
            description=self.significance,
            impact=self._impact(),
            remediation=self._remediation(),
            tags=["internet_facing"],
            evidence=Evidence(request="", response=json.dumps(
                self.evidence, indent=2, default=str),
                extra={"change_kind": self.kind}),
            fingerprint=self.fingerprint(),
        )

    def _impact(self) -> str:
        return {
            "host_added": "An asset that is not on the inventory exists and "
                          "resolves. Either it is forgotten or it is "
                          "unmonitored; both are how breaches start.",
            "host_removed": "The host stopped resolving. Confirm this was "
                            "intended -- it may be a decommissioning, or a DNS "
                            "misconfiguration hiding live infrastructure.",
            "port_added": "A new network service is reachable. Any service "
                          "added to an internet-facing host is immediately "
                          "attacked if it is not needed.",
            "port_removed": "A service was removed. Verify it was retired "
                            "rather than moved.",
            "service_changed": "The software answering on this port changed. "
                               "A downgrade or a replacement on a production "
                               "port is worth confirming was intended.",
            "cert_changed": "The certificate changed. A new certificate can "
                            "mean a new deployment, a moved service, or a "
                            "misissued certificate for one of your names.",
            "host_resolved": "A hostname that did not resolve now does. "
                             "Subdomain takeover becomes possible when a "
                             "dangling record starts resolving again.",
            "host_unresolved": "A previously resolvable hostname stopped "
                               "resolving.",
        }.get(self.kind, "Surface changed.")

    def _remediation(self) -> str:
        return {
            "host_added": "Add it to the asset inventory or remove it. An "
                          "unregistered internet-facing host is unmanaged.",
            "host_removed": "Confirm the decommission and remove the DNS "
                            "record rather than leaving it dangling.",
            "port_added": "Confirm the service is required. If not, close the "
                          "port and remove the underlying resource.",
            "port_removed": "Update the inventory.",
            "service_changed": "Confirm the change was deployed deliberately "
                               "and check the version for known issues.",
            "cert_changed": "Confirm the new certificate corresponds to a "
                            "deployment you made.",
            "host_resolved": "Remove the DNS record if the resource is gone. "
                             "A dangling CNAME to a deprovisioned SaaS "
                             "provider is a subdomain takeover waiting to "
                             "happen.",
            "host_unresolved": "No action if intended; investigate if not.",
        }.get(self.kind, "Review the change.")


def diff_snapshots(previous: Optional[Snapshot], current: Snapshot) -> list[Change]:
    """
    Compare two snapshots.

    ``previous`` being ``None`` is a first run: every host is reported as
    added, which is correct (from nothing, everything is new) but is labelled
    in the summary so nobody mistakes a baseline for a breach.
    """
    changes: list[Change] = []
    if previous is None:
        for host in current.hosts:
            changes.append(Change(
                kind="host_added", subject=host.hostname,
                detail=f"New host observed: {host.hostname} "
                       f"({', '.join(host.addresses) or 'no address'})",
                severity=_host_severity(host),
                significance="First observation: this run established the "
                             "baseline, so everything is 'new' by definition.",
                evidence={"ports": sorted(host.ports()), "source": host.source}))
        return changes

    old = previous.host_map()
    new = current.host_map()

    for key, host in new.items():
        if key not in old:
            changes.append(Change(
                kind="host_added", subject=host.hostname,
                detail=f"New host: {host.hostname} on "
                       f"{', '.join(str(p) for p in sorted(host.ports())) or 'no open ports'}",
                severity=_host_severity(host),
                significance="A host appeared that was not in the previous "
                             "snapshot.",
                evidence={"ports": sorted(host.ports()),
                          "services": sorted(host.service_keys()),
                          "source": host.source}))
            continue
        changes += _diff_host(old[key], host)

    for key, host in old.items():
        if key not in new:
            changes.append(Change(
                kind="host_removed", subject=host.hostname,
                detail=f"Host no longer observed: {host.hostname}",
                severity=Severity.LOW,
                significance="The host disappeared between snapshots.",
                evidence={"previously_seen_ports": sorted(host.ports())}))
    return changes


def _diff_host(before: Host, after: Host) -> list[Change]:
    changes: list[Change] = []
    old_ports, new_ports = before.ports(), after.ports()

    if not before.addresses and after.addresses:
        changes.append(Change(
            kind="host_resolved", subject=after.hostname,
            detail=f"{after.hostname} now resolves to "
                   f"{', '.join(after.addresses)}",
            severity=Severity.HIGH,
            significance="A hostname that previously did not resolve now "
                         "does. If the underlying resource was deleted, this "
                         "is the classic subdomain-takeover setup.",
            evidence={"addresses": after.addresses}))
    elif before.addresses and not after.addresses:
        changes.append(Change(
            kind="host_unresolved", subject=after.hostname,
            detail=f"{after.hostname} no longer resolves",
            severity=Severity.INFO,
            significance="Previously resolvable hostname stopped resolving.",
            evidence={"previously": before.addresses}))

    for port in sorted(new_ports - old_ports):
        service = next(s for s in after.services if s.port == port)
        name, why = SENSITIVE_PORTS.get(port, (service.service, ""))
        severity = _port_severity(port)
        changes.append(Change(
            kind="port_added", subject=f"{after.hostname}:{port}",
            detail=f"New port {port} open on {after.hostname} ({name})",
            severity=severity,
            significance=why or f"A previously closed port is now serving "
                                 f"{name}. Internet-facing services are "
                                 f"discovered and attacked within minutes.",
            evidence={"service": service.service, "banner": service.banner,
                      "tls": service.tls}))

    for port in sorted(old_ports - new_ports):
        changes.append(Change(
            kind="port_removed", subject=f"{after.hostname}:{port}",
            detail=f"Port {port} no longer open on {after.hostname}",
            severity=Severity.INFO,
            significance="A service was removed.",
            evidence={}))

    for key in sorted(after.service_keys() & before.service_keys()):
        old_service = next(s for s in before.services if s.key() == key)
        new_service = next(s for s in after.services if s.key() == key)
        if old_service.service != new_service.service:
            changes.append(Change(
                kind="service_changed", subject=f"{after.hostname}:{key}",
                detail=f"{after.hostname} port {key.split('/')[1]} now answers "
                       f"as {new_service.service} (was {old_service.service})",
                severity=Severity.MEDIUM,
                significance="The software on this port changed.",
                evidence={"was": old_service.service,
                          "now": new_service.service}))

    for fingerprint in after.cert_fingerprints() - before.cert_fingerprints():
        service = next(s for s in after.services
                       if s.cert_fingerprint == fingerprint)
        changes.append(Change(
            kind="cert_changed", subject=f"{after.hostname}:{service.port}",
            detail=f"New certificate on {after.hostname}:{service.port} "
                   f"({service.cert_subject})",
            severity=Severity.MEDIUM,
            significance="The certificate presented on this endpoint changed. "
                         "A new certificate can mean a new deployment, a "
                         "moved service, or a misissued certificate for one of "
                         "your names.",
            evidence={"subject": service.cert_subject,
                      "issuer": service.cert_issuer,
                      "expires": service.cert_expires,
                      "fingerprint": fingerprint}))
    return changes


def _host_severity(host: Host) -> Severity:
    if DEV_HINTS.search(host.hostname):
        return Severity.HIGH      # dev/test hosts on a production domain
    sensitive = host.ports() & set(SENSITIVE_PORTS)
    if sensitive:
        return Severity.MEDIUM
    if ADMIN_HINTS.search(host.hostname):
        return Severity.MEDIUM
    return Severity.LOW


def _port_severity(port: int) -> Severity:
    """
    Grade a newly-opened port.

    443 is graded MEDIUM rather than dropped to INFO: it was missing from both
    explicit lists, which made the single most common web port score lower than
    an obscure one. That is the kind of bug that only shows up when the grading
    table is tested exhaustively rather than spot-checked.
    """
    if port in {21, 23, 445, 6379, 9200, 27017, 3389, 5900, 1521, 1433,
                3306, 5432}:
        return Severity.HIGH      # plaintext admin or unauthenticated data stores
    if port in {22, 25, 143, 443, 587, 993, 995, 5000, 9000, 8080, 8443,
                3000, 5601}:
        return Severity.MEDIUM
    if port in {80, 8000, 8888}:
        return Severity.LOW
    return Severity.INFO


# -- snapshot building ---------------------------------------------------

@dataclass
class ScanConfig:
    use_ct: bool = True
    probe: bool = False
    ports: Optional[list[int]] = None
    port_scope: str = ""
    max_hosts: int = PROBE_LIMITS["max_hosts"]
    inventory_path: Optional[str] = None
    hostnames: list[str] = field(default_factory=list)


def take_snapshot(domain: str, config: Optional[ScanConfig] = None,
                  log=print) -> Snapshot:
    """Observe the surface once. Probing is opt-in."""
    config = config or ScanConfig()
    snapshot = Snapshot(scope=domain, sources=[])
    seen: dict[str, Host] = {}

    def absorb(host: Host) -> None:
        key = host.key()
        if key in seen:
            # Merge: a host found by two sources is one host.
            for service in host.services:
                if service.key() not in seen[key].service_keys():
                    seen[key].services.append(service)
        else:
            seen[key] = host

    if config.inventory_path:
        inventory = load_inventory(config.inventory_path)
        for host in inventory:
            host.source = "inventory"
            absorb(host)
        snapshot.sources.append("inventory")
        log(f"  {len(inventory)} host(s) from inventory")

    if config.use_ct:
        for host in from_ct_log(domain, log=log):
            absorb(host)
        snapshot.sources.append("ct")

    for hostname in config.hostnames:
        absorb(Host(hostname=hostname, source="declared"))

    if config.probe:
        targets = list(seen)
        if len(targets) > config.max_hosts:
            log(f"  WARNING: {len(targets)} hosts exceeds max_hosts="
                f"{config.max_hosts}; probing the first {config.max_hosts}")
            targets = targets[: config.max_hosts]
        log(f"probing {len(targets)} host(s)...")
        for hostname in targets:
            absorb(probe_host(hostname, config.ports, config.port_scope,
                              log=log))
        snapshot.sources.append("probe")

    snapshot.hosts = list(seen.values())
    totals = snapshot.totals()
    log(f"  snapshot: {totals['hosts']} host(s), "
        f"{totals['open_ports']} open port(s) from {snapshot.sources}")
    return snapshot


def changes_to_findings(changes: list[Change], scope: str) -> list[Finding]:
    return [c.to_finding(scope) for c in changes]


def summarize(changes: list[Change]) -> dict:
    counts: dict[str, int] = {}
    for change in changes:
        counts[change.kind] = counts.get(change.kind, 0) + 1
    by_severity = {s.value: 0 for s in Severity}
    for change in changes:
        by_severity[change.severity.value] += 1
    urgent = [c for c in changes
              if c.severity.rank <= Severity.HIGH.rank]
    return {
        "total": len(changes),
        "by_kind": counts,
        "by_severity": by_severity,
        "urgent": len(urgent),
        "baseline": len(changes) > 0
        and all("First observation" in c.significance for c in changes),
    }