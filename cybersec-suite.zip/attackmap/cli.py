#!/usr/bin/env python
"""
AttackMap command line.

    # baseline
    python -m attackmap.cli example.com --baseline

    # later: diff against the stored baseline
    python -m attackmap.cli example.com

Snapshots are written next to each other so the diff survives a restart, which
the web UI's in-memory baseline does not.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from attackmap.engine import (  # noqa: E402
    PRODUCT, ScanConfig, Snapshot, changes_to_findings, diff_snapshots,
    summarize, take_snapshot)
from core.report import report_html, report_json  # noqa: E402
from core.risk import prioritise  # noqa: E402
from core.storage import Store  # noqa: E402

COLOURS = {
    "critical": "\033[41;97m", "high": "\033[43;30m", "medium": "\033[43;30m",
    "low": "\033[46;30m", "info": "\033[100;30m", "reset": "\033[0m",
    "dim": "\033[2m", "bold": "\033[1m",
}


def colour(text: str, name: str, on: bool) -> str:
    return f"{COLOURS.get(name,'')}{text}{COLOURS['reset']}" if on else text


def snapshot_path(directory: Path, domain: str) -> Path:
    return directory / f"{domain.replace('.', '_')}.json"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="attackmap")
    parser.add_argument("domain")
    parser.add_argument("--baseline", metavar="PATH",
                        help="compare against this snapshot file instead of "
                             "the stored one")
    parser.add_argument("--save-as", metavar="PATH",
                        help="write this snapshot to PATH")
    parser.add_argument("--inventory", metavar="PATH")
    parser.add_argument("--no-ct", action="store_true",
                        help="skip certificate transparency lookup")
    parser.add_argument("--probe", action="store_true",
                        help="actively probe hosts; requires --port-scope")
    parser.add_argument("--port-scope", default="",
                        help="ports you are authorized to probe, e.g. 22,80,443")
    parser.add_argument("--yes", action="store_true",
                        help="confirm authorization for active probing")
    parser.add_argument("--fail-on-changes", type=int, default=None,
                        metavar="N",
                        help="exit 1 if more than N changes are found")
    parser.add_argument("--json", metavar="PATH")
    parser.add_argument("--html", metavar="PATH")
    parser.add_argument("--no-color", action="store_true")
    args = parser.parse_args(argv)
    colour_on = not args.no_color and sys.stdout.isatty()

    if args.probe:
        if not args.port_scope:
            parser.error("--probe requires --port-scope. Probing without a "
                         "declared port list means opening sockets to a "
                         "default port set you have not agreed to.")
        if not args.yes:
            print(f"about to actively probe {args.domain} on ports "
                  f"{args.port_scope}")
            print("re-run with --yes to confirm you are authorized")
            return 2

    directory = Path("snapshots")
    directory.mkdir(exist_ok=True)
    current_file = snapshot_path(directory, args.domain)

    config = ScanConfig(use_ct=not args.no_ct, probe=args.probe,
                        inventory_path=args.inventory,
                        port_scope=args.port_scope)
    print(colour(f"snapshotting {args.domain}...", "bold", colour_on))
    snapshot = take_snapshot(args.domain, config,
                             log=lambda m: print(colour(m, "dim", colour_on)))

    baseline_file = Path(args.baseline) if args.baseline else (
        current_file if current_file.exists() else None)
    previous = None
    if baseline_file and baseline_file.exists():
        previous = Snapshot.from_json(baseline_file.read_text(encoding="utf-8"))
        print(f"comparing against {baseline_file}")
    else:
        print(colour("no baseline found: this run establishes one, so every "
                     "host is reported as new", "dim", colour_on))

    changes = diff_snapshots(previous, snapshot)
    summary = summarize(changes)

    print()
    print(colour(f"  {summary['total']} change(s), {summary['urgent']} urgent",
                 "bold", colour_on))
    for kind, count in sorted(summary["by_kind"].items()):
        print(f"  {colour(kind, 'dim', colour_on):<28} {count}")

    scored = prioritise(changes_to_findings(changes, args.domain))
    if scored:
        print()
        for item in scored:
            tag = colour(f" {item.severity.value.upper():<8}",
                         item.severity.value, colour_on)
            print(f"  {tag} {item.score:>5}  {item.finding.title}")
            if item.finding.evidence.extra.get("change_kind"):
                print(f"  {'':8} {colour(item.finding.evidence.extra['change_kind'], 'dim', colour_on)}")
    print()

    totals = snapshot.totals()
    print(f"  surface: {totals['hosts']} host(s), "
          f"{totals['open_ports']} open port(s), "
          f"{totals['tls_endpoints']} TLS")

    if args.save_as:
        Path(args.save_as).write_text(snapshot.to_json(), encoding="utf-8")
        print(f"  snapshot -> {args.save_as}")
    else:
        current_file.write_text(snapshot.to_json(), encoding="utf-8")
        print(f"  snapshot -> {current_file}")

    try:
        store = Store()
        target_id = store.add_target(args.domain, "domain", args.domain,
                                     authorized=True)
        scan_id = store.start_scan(target_id, PRODUCT)
        store.record_scan(scan_id, target_id, PRODUCT,
                          changes_to_findings(changes, args.domain))
        store.finish_scan(scan_id, "completed", summary)
        print(f"  recorded as scan #{scan_id}")
    except Exception as exc:
        print(f"  could not record snapshot: {exc}")

    meta = {"target": args.domain, "product": "attackmap",
            "changes": summary["total"], "urgent": summary["urgent"]}
    findings = changes_to_findings(changes, args.domain)
    if args.json:
        Path(args.json).write_text(
            report_json(findings, args.domain, "attackmap", meta),
            encoding="utf-8")
        print(f"  JSON report -> {args.json}")
    if args.html:
        Path(args.html).write_text(
            report_html(findings, args.domain, "attackmap", meta,
                        title="AttackMap Change Report"),
            encoding="utf-8-sig")
        print(f"  HTML report -> {args.html}")

    if args.fail_on_changes is not None and summary["total"] > args.fail_on_changes:
        print(colour(f"  {summary['total']} changes exceeds the limit of "
                     f"{args.fail_on_changes}", "bold", colour_on))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())