"""
AttackMap web interface: snapshots, change timeline, diff view.

The dashboard leads with *changes*, not with inventory. An inventory screen is
static and gets ignored after the first week; a "what is different from last
time" screen is the reason anyone keeps the tool open.
"""

from __future__ import annotations

import html

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from core.auth import Role
from core.report import report_html, report_json, report_pdf, severity_chart
from core.risk import prioritise, risk_summary
from core.web import require_role_at

from .engine import (
    PRODUCT, Change, ScanConfig, Snapshot, changes_to_findings, diff_snapshots,
    summarize, take_snapshot)

router = APIRouter()

# Latest snapshot per target, held in memory for the UI. Snapshots are also
# persisted as findings, so a restart loses the diff baseline but not the
# history -- stated in the UI rather than hidden.
SNAPSHOTS: dict[str, Snapshot] = {}


def _store(request: Request):
    return request.app.state.store


def _e(value) -> str:
    return html.escape(str(value), quote=True)


@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    render = request.app.state.render
    store = _store(request)
    rows = []
    overall: dict[str, int] = {}

    for target in store.list_targets():
        if target["kind"] != "domain":
            continue
        stats = store.stats(target["id"], PRODUCT)
        changes = store.latest_findings(target_id=target["id"], product=PRODUCT)
        rows.append({
            "target": target,
            "stats": stats,
            "change_count": len(changes),
            "last": store.previous_scan(target["id"], PRODUCT),
            "snapshot": SNAPSHOTS.get(target["locator"]),
        })
        for sev, count in stats["by_severity"].items():
            overall[sev] = overall.get(sev, 0) + count

    return render(request, "attackmap_dashboard.html", "attackmap",
                  page="dashboard", rows=rows, severity_counts=overall,
                  chart=severity_chart(overall))


@router.get("/target/{target_id}", response_class=HTMLResponse)
async def target_detail(request: Request, target_id: int):
    render = request.app.state.render
    store = _store(request)
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)

    changes = store.latest_findings(target_id, PRODUCT)
    stats = store.stats(target_id, PRODUCT)
    scans = store.list_scans(target_id, PRODUCT, limit=40)
    snapshot = SNAPSHOTS.get(target["locator"])

    by_kind: dict[str, int] = {}
    for change in changes:
        by_kind[change.evidence.extra.get("change_kind", "other")] = \
            by_kind.get(change.evidence.extra.get("change_kind", "other"), 0) + 1

    timeline = []
    for row in reversed(scans):
        timeline.append({
            "when": (row["finished_at"] or row["started_at"])[:16].replace("T", " "),
            "changes": (row["summary"] or {}).get("total", 0),
            "urgent": (row["summary"] or {}).get("urgent", 0),
            "status": row["status"],
        })

    hosts = sorted(snapshot.hosts, key=lambda h: h.hostname) if snapshot else []

    return render(request, "attackmap_target.html", "attackmap", page="target",
                  target=target, changes=changes, stats=stats,
                  severity_counts=stats["by_severity"],
                  chart=severity_chart(stats["by_severity"]), by_kind=by_kind,
                  timeline=timeline, hosts=hosts, snapshot=snapshot,
                  summary=risk_summary(prioritise(changes)))


@router.get("/target/{target_id}/report", response_class=HTMLResponse)
async def report(request: Request, target_id: int, fmt: str = "html",
                 user=Depends(require_role_at(Role.VIEWER))):
    store = _store(request)
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)
    findings = store.latest_findings(target_id, PRODUCT)
    meta = {"target": target["locator"], "product": PRODUCT,
            "changes": len(findings)}
    if fmt == "pdf":
        pdf = report_pdf(findings, target["locator"], PRODUCT, meta)
        safe_product = "".join(c for c in PRODUCT.lower() if c.isalnum() or c in "-_") or "security"
        return Response(pdf, media_type="application/pdf", headers={
            "Content-Disposition": f'attachment; filename="{safe_product}-report-{target_id}.pdf"',
            "X-Content-Type-Options": "nosniff",
        })
    if fmt == "json":
        return HTMLResponse(
            report_json(findings, target["locator"], PRODUCT, meta),
            media_type="application/json")
    return HTMLResponse(
        report_html(findings, target["locator"], PRODUCT, meta,
                    title="AttackMap Change Report"))


@router.post("/snapshot")
async def make_snapshot(request: Request, domain: str = Form(...),
                        use_ct: str = Form("yes"),
                        probe: str = Form(""),
                        inventory: str = Form(""),
                        port_scope: str = Form(""),
                        user=Depends(require_role_at(Role.ANALYST))):
    store = _store(request)
    domain = domain.strip().lower().rstrip(".")
    if not domain:
        return HTMLResponse("<h1>Domain required</h1>", status_code=400)

    if probe and not port_scope.strip():
        return HTMLResponse(
            "<h1>Port scope required</h1>"
            "<p>Active probing without a declared port scope means this tool "
            "will open sockets to whatever port list it defaults to. Declare "
            "the ports you are authorized to probe, for example "
            "<span class='mono'>22,80,443</span> or <span class='mono'>80-443"
            "</span>, and re-run.</p>"
            "<p><a class='btn' href='/attackmap/'>back</a></p>",
            status_code=400)

    config = ScanConfig(use_ct=use_ct == "yes", probe=bool(probe),
                        inventory_path=inventory.strip() or None,
                        port_scope=port_scope.strip())
    try:
        snapshot = take_snapshot(domain, config)
    except FileNotFoundError:
        return HTMLResponse(
            f"<h1>Inventory not found</h1><p>{_e(inventory)}</p>"
            f"<p><a class='btn' href='/attackmap/'>back</a></p>", status_code=400)
    except Exception as exc:
        return HTMLResponse(f"<h1>Snapshot failed</h1><p>{_e(exc)}</p>",
                            status_code=500)

    previous = SNAPSHOTS.get(domain)
    changes = diff_snapshots(previous, snapshot)
    summary = summarize(changes)
    SNAPSHOTS[domain] = snapshot

    target_id = store.add_target(domain, "domain", domain, authorized=True)
    scan_id = store.start_scan(target_id, PRODUCT)
    findings = changes_to_findings(changes, domain)
    store.record_scan(scan_id, target_id, PRODUCT, findings)
    store.finish_scan(scan_id, "completed", {**summary,
                                             "total_changes": len(changes)})

    return RedirectResponse(f"/attackmap/target/{target_id}", status_code=303)


@router.get("/api/targets")
async def api_targets(request: Request):
    store = _store(request)
    return {"targets": [
        {"id": t["id"], "domain": t["locator"],
         "stats": store.stats(t["id"], PRODUCT)}
        for t in store.list_targets() if t["kind"] == "domain"]}


@router.post("/api/snapshot")
async def api_snapshot(request: Request, domain: str, use_ct: bool = True,
                       probe: bool = False, port_scope: str = "",
                       user=Depends(require_role_at(Role.ANALYST))):
    if probe and not port_scope:
        return {"error": "active probing requires an explicit port_scope; "
                         "see the dashboard form for the rationale"}
    store = _store(request)
    domain = domain.strip().lower().rstrip(".")
    config = ScanConfig(use_ct=use_ct, probe=probe, port_scope=port_scope)
    try:
        snapshot = take_snapshot(domain, config)
    except Exception as exc:
        return {"error": str(exc)}
    changes = diff_snapshots(SNAPSHOTS.get(domain), snapshot)
    summary = summarize(changes)
    SNAPSHOTS[domain] = snapshot

    target_id = store.add_target(domain, "domain", domain, authorized=True)
    scan_id = store.start_scan(target_id, PRODUCT)
    store.record_scan(scan_id, target_id, PRODUCT,
                      changes_to_findings(changes, domain))
    store.finish_scan(scan_id, "completed", summary)
    return {"domain": domain, "summary": summary, "totals": snapshot.totals(),
            "changes": [{"kind": c.kind, "subject": c.subject,
                         "detail": c.detail,
                         "severity": c.severity.value} for c in changes]}


@router.get("/api/targets/{target_id}/changes")
async def api_changes(request: Request, target_id: int):
    store = _store(request)
    findings = store.latest_findings(target_id, PRODUCT)
    return {"changes": [f.to_dict() for f in findings]}