"""
Unified server for all five products.

    python server.py                      # everything on 127.0.0.1:8000
    python server.py --bootstrap-admin    # first run: create an admin user
    python server.py --products autopentest fixproof

Products are loaded by import path and any that fails to import are reported
and skipped rather than taking the whole server down -- five products sharing
one process is convenient for a demo and fragile for exactly this reason.
"""

from __future__ import annotations

import argparse
import importlib
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from fastapi import FastAPI, Request  # noqa: E402

from core.auth import AuthStore, bootstrap  # noqa: E402
from core.storage import Store  # noqa: E402
from core.web import build_app  # noqa: E402

PRODUCT_MODULES = {
    "autopentest": "autopentest.web:router",
    "apishield": "apishield.web:router",
    "attackmap": "attackmap.web:router",
    "cloudpath": "cloudpath.web:router",
    "fixproof": "fixproof.web:router",
}

PRODUCT_BLURB = {
    "autopentest": ("Web application testing",
                    "Crawls and tests a web app: headers, reflected input, "
                    "SQL injection and path traversal, each confirmed with "
                    "evidence before it is reported."),
    "apishield": ("API authorization testing",
                  "Tests REST APIs for BOLA and broken function-level "
                  "authorization by replaying requests as multiple identities."),
    "attackmap": ("Attack surface monitoring",
                  "Tracks how an external attack surface changes over time and "
                  "alerts on new hosts, ports and services."),
    "cloudpath": ("Cloud misconfiguration analysis",
                  "Evaluates cloud configuration for misconfigurations and "
                  "graphs the reachable attack paths between them."),
    "fixproof": ("Security regression testing",
                 "Turns recorded findings into permanent regression tests and "
                 "fails when one comes back."),
}

# Display names. str.capitalize() would render "Autopentest" and "Cloudpath",
# which is wrong for product names and looks like a bug in the navigation.
PRODUCT_NAMES = {
    "autopentest": "AutoPentest",
    "apishield": "APIShield",
    "attackmap": "AttackMap",
    "cloudpath": "CloudPath",
    "fixproof": "FixProof",
}

DATA_DIR = Path(os.getenv("SUITE_DATA_DIR", str(Path(__file__).resolve().parent / "data"))).resolve()


def create_app(products: list[str] | None = None,
               do_bootstrap: bool = False) -> FastAPI:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    store = Store(DATA_DIR / "suite.db")
    auth = AuthStore(DATA_DIR / "auth.db")

    wanted = products or list(PRODUCT_MODULES)
    nav = [("/", "Overview", "index")]
    loaded: dict[str, str] = {}
    skipped: dict[str, str] = {}

    app = build_app("cybersec-suite",
                    "Five authorized security testing tools in one interface.",
                    store=store, auth=auth, nav_products=nav)

    for name in wanted:
        if name not in PRODUCT_MODULES:
            skipped[name] = "unknown product"
            continue
        module_path, attr = PRODUCT_MODULES[name].split(":")
        try:
            module = importlib.import_module(module_path)
            app.include_router(getattr(module, attr), prefix=f"/{name}",
                               tags=[name])
            nav.append((f"/{name}", PRODUCT_NAMES.get(name, name), name))
            loaded[name] = "ok"
        except Exception as exc:
            skipped[name] = f"{type(exc).__name__}: {exc}"
            print(f"[warn] {name} failed to load: {skipped[name]}")

    # The nav list is built as products load, so hand it over afterwards.
    app.state.templates_obj.env.globals["nav"] = nav
    app.state.nav = nav
    app.state.loaded = loaded
    app.state.skipped = skipped

    if do_bootstrap:
        bootstrap(auth)

    _register_index(app, store, loaded, skipped)
    return app


def _register_index(app: FastAPI, store: Store, loaded: dict, skipped: dict):
    """
    The suite overview: which products loaded, and what has been scanned.

    ``Request`` is imported at module scope on purpose. With
    ``from __future__ import annotations`` the annotations are strings, and
    FastAPI resolves them against the module globals -- a function-local import
    is invisible there, so ``request: Request`` silently degraded to a required
    *query parameter* and every page returned 422.
    """
    from fastapi.responses import HTMLResponse

    @app.get("/", response_class=HTMLResponse)
    async def index(request: Request):
        render = request.app.state.render
        rows = []
        for key, name, _ in request.app.state.nav:
            if key == "/":
                continue
            title, blurb = PRODUCT_BLURB.get(key, (name, ""))
            targets = [t for t in store.list_targets()]
            rows.append({
                "key": key, "name": name, "title": title, "blurb": blurb,
                "status": loaded.get(key),
                "error": skipped.get(key),
                "targets": len([t for t in targets
                                if _kind_for(key) in (t["kind"], None)]),
            })

        totals = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for target in store.list_targets():
            for product in PRODUCT_MODULES:
                if not _kind_matches(product, target["kind"]):
                    continue
                stats = store.stats(target["id"], product)
                for sev, count in stats["by_severity"].items():
                    totals[sev] = totals.get(sev, 0) + count

        return render(request, "index.html", "index", page="index",
                      rows=rows, totals=totals, products=PRODUCT_BLURB,
                      nav=request.app.state.nav)

    @app.get("/health")
    async def health():
        return {"status": "ok", "products_loaded": sorted(loaded),
                "products_skipped": skipped}


def _kind_for(product: str) -> str:
    return {"autopentest": "web", "apishield": "api", "attackmap": "domain",
            "cloudpath": "cloud", "fixproof": "web"}.get(product, "")


def _kind_matches(product: str, kind: str) -> bool:
    return _kind_for(product) == kind


def main() -> int:
    parser = argparse.ArgumentParser(prog="cybersec-suite")
    parser.add_argument("--host", default="127.0.0.1",
                        help="default loopback only; see the auth README "
                             "before binding anywhere else")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--products", nargs="*", default=None,
                        choices=sorted(PRODUCT_MODULES))
    parser.add_argument("--bootstrap-admin", action="store_true")
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()

    app = create_app(args.products, args.bootstrap_admin)
    print()
    print(f"  cybersec-suite on http://{args.host}:{args.port}")
    print(f"  loaded:    {', '.join(sorted(app.state.loaded)) or 'none'}")
    if app.state.skipped:
        print(f"  skipped:   {app.state.skipped}")
    print("  sign in at /login (create an admin with --bootstrap-admin)")
    print()

    import uvicorn
    uvicorn.run(app, host=args.host, port=args.port, reload=args.reload,
                log_level="info")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())