@echo off
REM cybersec-suite launcher -- finds Python and starts the server.
setlocal
set "PY="
where python >nul 2>&1 && set "PY=python"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PY (
  echo Could not find Python. Install Python 3.10+ and re-run.
  exit /b 1
)
cd /d "%~dp0"
if "%~1"=="lab" (
  %PY% lab\app.py
) else if "%~1"=="test" (
  %PY% -m pytest tests\ -q
) else if "%~1"=="demo" (
  %PY% tests\demo_fixproof_cycle.py
) else (
  %PY% server.py %*
)
endlocal