"""
CloudPath web interface: point it at a config directory, read the attack graph.

The graph is the headline. A flat table of misconfigurations tells an operator
they have eleven problems; a path saying "internet -> open security group ->
customer database" tells them which one to fix first.
"""

from __future__ import annotations

import html
from pathlib import Path

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from core.auth import Role
from core.report import report_html, report_json, report_pdf, severity_chart
from core.risk import prioritise, risk_summary
from core.web import require_role_at

from .engine import PRODUCT, ScanConfig, analyse

router = APIRouter()

# Latest analysis per target path, kept in memory for the graph view.
RESULTS: dict[str, object] = {}

SAMPLES = Path(__file__).parent / "samples"


def _store(request: Request):
    return request.app.state.store


def _e(value) -> str:
    return html.escape(str(value), quote=True)


@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    render = request.app.state.render
    store = _store(request)
    rows = []
    overall: dict[str, int] = {}

    for target in store.list_targets():
        if target["kind"] != "cloud":
            continue
        stats = store.stats(target["id"], PRODUCT)
        rows.append({"target": target, "stats": stats,
                     "scan": store.previous_scan(target["id"], PRODUCT)})
        for sev, count in stats["by_severity"].items():
            overall[sev] = overall.get(sev, 0) + count

    return render(request, "cloudpath_dashboard.html", "cloudpath",
                  page="dashboard", rows=rows, severity_counts=overall,
                  chart=severity_chart(overall),
                  samples_available=SAMPLES.exists(),
                  sample_vulnerable=str(SAMPLES / "vulnerable"),
                  sample_hardened=str(SAMPLES / "hardened"))


@router.get("/target/{target_id}", response_class=HTMLResponse)
async def target_detail(request: Request, target_id: int):
    render = request.app.state.render
    store = _store(request)
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)

    findings = store.latest_findings(target_id, PRODUCT)
    scored = prioritise(findings)
    stats = store.stats(target_id, PRODUCT)
    result = RESULTS.get(target["locator"])
    last = store.previous_scan(target["id"], PRODUCT)

    by_rule: dict[str, int] = {}
    for finding in findings:
        rule = finding.detector.replace("cloudpath:", "")
        by_rule[rule] = by_rule.get(rule, 0) + 1

    # node id -> readable label, so the template can render a path without
    # needing the whole asset list.
    result_assets = {}
    if result is not None:
        result_assets = {a.id: a.label() for a in result.assets}
        for node in set(n for p in result.paths for n in p.nodes):
            result_assets.setdefault(node, node)

    summary_json = last.get("summary") if last else None
    if summary_json and result is not None:
        # The stored summary is JSON round-tripped; the live result is richer.
        summary_json = {**(summary_json or {}), **result.summary()}

    return render(request, "cloudpath_target.html", "cloudpath", page="target",
                  target=target, scored=scored, stats=stats,
                  summary=risk_summary(scored), by_rule=by_rule,
                  severity_counts=stats["by_severity"],
                  chart=severity_chart(stats["by_severity"]),
                  result=result, result_assets=result_assets,
                  summary_json=summary_json,
                  notes=(last.get("summary") or {}).get("notes") if last else None)


@router.get("/target/{target_id}/report", response_class=HTMLResponse)
async def report(request: Request, target_id: int, fmt: str = "html",
                 user=Depends(require_role_at(Role.VIEWER))):
    store = _store(request)
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)
    findings = store.latest_findings(target_id, PRODUCT)
    meta = {"target": target["locator"], "product": PRODUCT}
    if fmt == "pdf":
        pdf = report_pdf(findings, target["locator"], PRODUCT, meta)
        safe_product = "".join(c for c in PRODUCT.lower() if c.isalnum() or c in "-_") or "security"
        return Response(pdf, media_type="application/pdf", headers={
            "Content-Disposition": f'attachment; filename="{safe_product}-report-{target_id}.pdf"',
            "X-Content-Type-Options": "nosniff",
        })
    if fmt == "json":
        return HTMLResponse(
            report_json(findings, target["locator"], PRODUCT, meta),
            media_type="application/json")
    return HTMLResponse(report_html(findings, target["locator"], PRODUCT, meta,
                                    title="CloudPath Report"))


@router.post("/analyse")
async def run_analysis(request: Request, config_path: str = Form(...),
                       confirm: str = Form(""),
                       user=Depends(require_role_at(Role.ANALYST))):
    store = _store(request)
    path = Path(config_path.strip())

    if not path.exists():
        return HTMLResponse(
            f"<h1>Path not found</h1><p class='mono'>{_e(str(path))}</p>"
            f"<p><a class='btn' href='/cloudpath/'>back</a></p>", status_code=400)

    if confirm != "yes":
        return HTMLResponse(
            f"<h1>Confirm</h1><p>CloudPath will read every recognised "
            f"configuration file under<br><span class='mono'>"
            f"{_e(str(path))}</span></p>"
            f"<p class='muted'>No cloud account is contacted and no credentials "
            f"are used. Confirm the path is yours.</p>"
            f"<form method='post' action='/cloudpath/analyse'>"
            f"<input type='hidden' name='config_path' value='{_e(str(path))}'>"
            f"<label><input type='checkbox' name='confirm' value='yes' checked "
            f"style='width:auto'> This is configuration I am authorized to read"
            f"</label><p><button class='btn primary'>Analyse</button></p></form>",
            status_code=400)

    key = str(path.resolve())
    try:
        result = analyse(key, ScanConfig(), log=lambda *a: None)
    except Exception as exc:
        return HTMLResponse(f"<h1>Analysis failed</h1><p>{_e(exc)}</p>"
                            f"<p><a class='btn' href='/cloudpath/'>back</a></p>",
                            status_code=500)

    RESULTS[key] = result
    target_id = store.add_target(key, "cloud", key, authorized=True)
    scan_id = store.start_scan(target_id, PRODUCT)
    store.record_scan(scan_id, target_id, PRODUCT, result.findings)
    summary = result.summary()
    summary["notes"] = result.notes[:40]
    store.finish_scan(scan_id, "completed", summary)

    return RedirectResponse(f"/cloudpath/target/{target_id}", status_code=303)


@router.get("/api/targets")
async def api_targets(request: Request):
    store = _store(request)
    return {"targets": [
        {"id": t["id"], "path": t["locator"],
         "stats": store.stats(t["id"], PRODUCT)}
        for t in store.list_targets() if t["kind"] == "cloud"]}


@router.post("/api/analyse")
async def api_analyse(request: Request, config_path: str,
                      user=Depends(require_role_at(Role.ANALYST))):
    path = Path(config_path)
    if not path.exists():
        return {"error": f"path not found: {config_path}"}
    key = str(path.resolve())
    try:
        result = analyse(key, ScanConfig(), log=lambda *a: None)
    except Exception as exc:
        return {"error": str(exc)}
    RESULTS[key] = result

    store = _store(request)
    target_id = store.add_target(key, "cloud", key, authorized=True)
    scan_id = store.start_scan(target_id, PRODUCT)
    store.record_scan(scan_id, target_id, PRODUCT, result.findings)
    summary = result.summary()
    summary["notes"] = result.notes[:40]
    store.finish_scan(scan_id, "completed", summary)

    return {
        "target_id": target_id,
        "summary": result.summary(),
        "paths": [{"nodes": p.nodes, "hops": p.hops, "score": round(p.score, 1)}
                  for p in result.paths],
        "findings": [{"title": f.title, "severity": f.severity.value,
                      "rule": f.detector.replace("cloudpath:", ""),
                      "location": f.location} for f in result.findings],
        "notes": result.notes,
    }