"""
CloudPath engine: find cloud misconfigurations, then work out which ones are
actually reachable.

Two things separate this from a configuration linter, and both are the point of
the product:

1. **Attack paths.** A misconfiguration that nothing can reach is a much smaller
   problem than the same misconfiguration reachable from the internet in two
   hops. This tool builds a graph of assets and edges and reports *paths* --
   "internet -> security group -> RDS with root login -> customer database" --
   rather than a flat list. Severity is computed from the path, not from the
   misconfiguration in isolation.

2. **Honest parsing.** Infrastructure-as-code is read, not guessed: Terraform
   HCL, Kubernetes manifests, Docker Compose and cloudformation-ish JSON are
   all parsed into one asset graph. Where something cannot be understood, it is
   reported as unparsed rather than silently assumed safe.

Inputs: .tf files, Kubernetes YAML, docker-compose YAML, or a plain JSON
inventory. No cloud account is contacted and no credentials are used -- this is
purely static analysis of configuration you already have, which is both safer
and the only version that works in CI.

Not implemented: live cloud API calls, drift detection against a running
account, or automatic remediation. See the README.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import networkx as nx
import yaml

from core.models import Evidence, Finding, Severity, dedupe, utcnow
from core.risk import prioritise, risk_summary

PRODUCT = "cloudpath"

# -- asset model ---------------------------------------------------------

ASSET_TYPES = {
    "internet": "The public internet, the graph's entry point.",
    "security_group": "A firewall rule set. Edges from here reach anything the "
                      "rules allow.",
    "storage": "Object storage: S3 buckets, GCS buckets, blobs.",
    "database": "Managed databases: RDS, Cloud SQL, Cosmos.",
    "compute": "Virtual machines, containers, serverless functions.",
    "identity": "IAM users, roles, service accounts.",
    "secret": "Secrets managers, vaults, key stores.",
    "load_balancer": "Ingress points for traffic.",
    "queue": "Message queues and topics.",
}

# Assets holding the crown jewels. Reaching one of these is what matters.
CROWN_JEWELS = {"database", "secret", "identity"}

# What an attacker can do on reaching each type. Used to weight paths.
IMPACT = {
    "internet": 0,
    "load_balancer": 1,
    "security_group": 2,
    "compute": 5,
    "storage": 8,
    "database": 10,
    "secret": 10,
    "identity": 9,
    "queue": 3,
}


@dataclass
class Asset:
    """One thing in the environment."""
    id: str
    kind: str
    name: str = ""
    provider: str = ""
    properties: dict[str, Any] = field(default_factory=dict)
    source_file: str = ""
    source_line: int = 0

    @property
    def is_public(self) -> bool:
        """
        Whether the internet can reach this.

        Not just an explicit ``public = true``. A security group with
        ``cidr_blocks = ["0.0.0.0/0"]`` is reachable from the internet just as
        certainly as one flagged public, and treating only the latter as public
        meant the graph never connected the internet to the database behind the
        open group -- hiding the flagship attack path the whole sample exists to
        demonstrate.
        """
        if self.properties.get("public"):
            return True
        if self.kind == "security_group":
            return _is_open_cidr(self.properties.get("cidr_blocks")) or \
                bool(self.properties.get("open"))
        return False

    @property
    def is_sensitive(self) -> bool:
        return self.kind in CROWN_JEWELS

    def label(self) -> str:
        return f"{self.kind}:{self.name or self.id}"


@dataclass
class Relation:
    """A directed edge: source can reach or is permitted to reach target."""
    source: str
    target: str
    kind: str = "allows"        # allows | runs_on | contains | grants | trusts
    note: str = ""
    public: bool = False


@dataclass
class AttackPath:
    """
    A route from the internet to something that matters.

    Named ``AttackPath`` rather than ``Path`` because a module-level ``class
    Path`` shadows ``pathlib.Path`` for the whole file: ``Path(path)`` then
    constructed this dataclass instead and failed with a nonsensical
    "missing 1 required positional argument: edges".
    """
    nodes: list[str]
    edges: list[Relation]
    score: float = 0.0

    @property
    def hops(self) -> int:
        return len(self.edges)

    def describe(self, assets: dict[str, Asset]) -> str:
        return " -> ".join(assets[n].label() for n in self.nodes if n in assets)


# -- misconfiguration rules ---------------------------------------------

@dataclass
class Rule:
    """One misconfiguration check."""
    id: str
    title: str
    kind: str
    severity: Severity
    why: str
    fix: str
    cwe: str = ""
    references: list[str] = field(default_factory=list)


RULES = [
    Rule("SG_INGRESS_OPEN", "Security group allows all inbound traffic",
         "security_group", Severity.CRITICAL,
         "0.0.0.0/0 on any port makes the resource reachable from anywhere on "
         "the internet. Most cloud breaches start with a rule exactly like this "
         "that someone meant to be temporary.",
         "Scope the CIDR to known source ranges. If the rule is temporary, put "
         "an expiry on the change so it cannot silently become permanent.",
         "CWE-284"),
    Rule("S3_PUBLIC", "Storage bucket is publicly readable",
         "storage", Severity.CRITICAL,
         "A public bucket exposes every object in it to the internet. Buckets "
         "are public by default in the console and private in code, so this is "
         "routinely shipped by accident.",
         "Remove the public ACL or the public-access-block override. Grant "
         "access through IAM roles instead.",
         "CWE-732"),
    Rule("RDS_PUBLIC", "Database has a public IP address",
         "database", Severity.CRITICAL,
         "A publicly-addressed database is exposed to the whole internet. "
         "Combined with default credentials or an open security group this is "
         "direct data breach territory.",
         "Move the database into a private subnet and reach it through a "
         "bastion or a VPN.",
         "CWE-668"),
    Rule("IAM_WILDCARD", "IAM policy grants wildcard permissions",
         "identity", Severity.HIGH,
         "An Action of \"*\" or a Resource of \"*\" is equivalent to giving away "
         "the account. Broad actions such as iam:*PassRole or s3:* are close "
         "to as bad.",
         "Scope the action to the specific verbs needed and the resource to "
         "specific ARNs. Review with a policy simulator.",
         "CWE-732"),
    Rule("SECRET_UNENCRYPTED", "Secret store is not encrypted",
         "secret", Severity.HIGH,
         "Unencrypted secrets are readable by anything that can reach the "
         "store, and are trivially recoverable from a snapshot or backup.",
         "Enable encryption at rest with a customer-managed key, and restrict "
         "who can decrypt.",
         "CWE-311"),
    Rule("ADMIN_SSH_OPEN", "Administrative port open to the internet",
         "security_group", Severity.HIGH,
         "SSH, RDP or the database admin port reachable from anywhere invites "
         "credential stuffing against infrastructure that has no rate limiting.",
         "Restrict to a VPN or bastion range, and require key or MFA "
         "authentication.",
         "CWE-284"),
    Rule("STORAGE_NO_VERSIONING", "Storage bucket has no versioning",
         "storage", Severity.LOW,
         "Without versioning a single overwrite or a ransomware script "
         "destroys the previous state permanently.",
         "Enable versioning and add a lifecycle policy for non-current "
         "versions.",
         "CWE-693"),
    Rule("PLAINTEXT_LOGGING", "Logging captures request bodies or secrets",
         "compute", Severity.MEDIUM,
         "Logging payloads puts credentials and personal data into a log "
         "store that usually has far weaker access controls than the service "
         "itself.",
         "Redact sensitive fields before logging, or log structured metadata "
         "only.",
         "CWE-532"),
    Rule("UNENCRYPTED_VOLUME", "Block storage is not encrypted",
         "compute", Severity.MEDIUM,
         "An unencrypted volume exposes its contents from a snapshot, a "
         "detached disk or a lost instance.",
         "Encrypt the volume at creation. Existing volumes need a snapshot and "
         "a copy to migrate.",
         "CWE-311"),
    Rule("MISSING_TLS", "Service endpoint does not require TLS",
         "load_balancer", Severity.MEDIUM,
         "Traffic over plain HTTP exposes credentials and session tokens to "
         "anything on the path.",
         "Redirect to HTTPS and set a modern TLS policy.",
         "CWE-319"),
    Rule("PRIVILEGED_CONTAINER", "Container runs privileged",
         "compute", Severity.HIGH,
         "A privileged container shares the host kernel and can escape the "
         "container boundary, reaching every other workload and any secret "
         "mounted anywhere on the node. It also disables most runtime "
         "protections.",
         "Drop the privileged flag and grant only the specific capabilities "
         "the workload needs. Most workloads that ask for privileged do not "
         "need it.",
         "CWE-250"),
]

RULES_BY_ID = {r.id: r for r in RULES}


# -- parsing ------------------------------------------------------------

def parse_file(path: Path) -> tuple[list[Asset], list[Relation], list[str]]:
    """
    Parse one configuration file into assets and relations.

    Returns a list of notes about anything unparsed. Silently ignoring an
    unrecognised resource is the single worst behaviour for a security tool:
    the operator concludes the resource was checked and clean.
    """
    text = path.read_text(encoding="utf-8", errors="replace")
    name = path.name
    if name.endswith((".tf", ".tfvars")):
        return _parse_terraform(text, name)
    if name.endswith((".yaml", ".yml")):
        lowered = text.lower()
        if "kind:" in lowered and ("deployment" in lowered or "pod" in lowered
                                   or "service" in lowered or "ingress" in lowered):
            return _parse_kubernetes(text, name)
        if "version:" in lowered or "services:" in lowered:
            return _parse_compose(text, name)
        return _parse_kubernetes(text, name)      # generic YAML, best effort
    if name.endswith(".json"):
        return _parse_json(text, name)
    return [], [], [f"{name}: unrecognised file type, not analysed"]


def _parse_terraform(text: str, name: str) -> tuple[list[Asset], list[Relation], list[str]]:
    """
    Terraform HCL, read with a purpose-built scanner rather than a real parser.

    A full HCL parser is not available and pulling one in for this would be a
    dependency the rest of the suite does not need. The scanner extracts
    resource blocks and their attributes, which is enough for the rules above.

    Its limitation is stated in the notes it returns: anything more elaborate
    than literal attributes and simple interpolation is reported as unparsed.
    """
    assets: list[Asset] = []
    relations: list[Relation] = []
    notes: list[str] = []

    blocks = list(re.finditer(
        r'resource\s+"([^"]+)"\s+"([^"]+)"\s*\{', text))
    for index, match in enumerate(blocks):
        # Terraform syntax is resource "<TYPE>" "<NAME>". Reading these the
        # other way round made every block look like an unknown type, so an
        # entire .tf file parsed to zero assets while the report showed only
        # "not analysed" notes.
        resource_type, resource_name = match.group(1), match.group(2)
        provider = resource_type.split("_", 1)[0]
        body_start = match.end()
        body_end = blocks[index + 1].start() if index + 1 < len(blocks) else len(text)
        body = text[body_start:body_end]

        line = text[: match.start()].count("\n") + 1
        kind = _terraform_kind(resource_type)
        if kind is None:
            notes.append(f"{name}:{line}: resource type {resource_type!r} not "
                         f"mapped to an asset kind, not analysed")
            continue

        properties = _terraform_attributes(body)
        if any("join(" in str(v) for v in properties.values()):
            notes.append(f"{name}:{line}: {resource_type}.{resource_name} uses "
                         f"an expression this scanner cannot evaluate")

        asset_id = f"tf:{resource_type}.{resource_name}"
        assets.append(Asset(id=asset_id, kind=kind,
                            name=resource_name, provider=provider,
                            properties=properties, source_file=name,
                            source_line=line))

        relations += _terraform_relations(asset_id, properties, body, name, line)

    return assets, relations, notes


TERRAFORM_KINDS = {
    "aws_s3_bucket": "storage",
    "aws_db_instance": "database",
    "aws_rds_cluster": "database",
    "google_storage_bucket": "storage",
    "google_sql_database_instance": "database",
    "azurerm_storage_account": "storage",
    "aws_instance": "compute",
    "aws_security_group": "security_group",
    "aws_security_group_rule": "security_group",
    "google_compute_firewall": "security_group",
    "aws_iam_policy": "identity",
    "aws_iam_role": "identity",
    "aws_iam_user": "identity",
    "google_service_account": "identity",
    "aws_secretsmanager_secret": "secret",
    "aws_ssm_parameter": "secret",
    "azurerm_key_vault": "secret",
    "aws_lb": "load_balancer",
    "aws_lb_listener": "load_balancer",
    "aws_elb": "load_balancer",
    "aws_alb": "load_balancer",
    "aws_sqs_queue": "queue",
    "aws_sns_topic": "queue",
    "google_cloud_run_service": "compute",
}


def _terraform_kind(resource_type: str) -> Optional[str]:
    if resource_type in TERRAFORM_KINDS:
        return TERRAFORM_KINDS[resource_type]
    for needle, kind in (("bucket", "storage"), ("db_instance", "database"),
                         ("security_group", "security_group"),
                         ("firewall", "security_group"),
                         ("iam_", "identity"), ("secretsmanager", "secret"),
                         ("key_vault", "secret"), ("instance", "compute")):
        if needle in resource_type:
            return kind
    return None


def _terraform_attributes(body: str) -> dict[str, Any]:
    """Extract simple scalar attributes from an HCL block body."""
    properties: dict[str, Any] = {}
    for match in re.finditer(
            r'^\s*([A-Za-z_][\w-]*)\s*=\s*("([^"]*)"|true|false|[\d.]+|\[[^\]]*\])',
            body, re.M):
        key = match.group(1)
        raw = match.group(2)
        if raw.startswith('"'):
            properties[key] = match.group(3)
        elif raw in ("true", "false"):
            properties[key] = raw == "true"
        elif raw.startswith("["):
            properties[key] = raw
        else:
            try:
                properties[key] = float(raw)
            except ValueError:
                properties[key] = raw
    return properties


def normalise_reference(value: Any) -> str:
    """
    Turn a Terraform interpolation into the asset id this module assigns.

    ``"${aws_security_group.app_sg.id}"`` has to become
    ``tf:aws_security_group.app_sg`` or the edge lands on a dangling node and
    the attack path through the security group to the database is never found.

    The reference has *three* dot-separated segments -- type, name, attribute --
    so a two-segment pattern kept the trailing ``.id`` and every relation
    pointed at ``tf:aws_security_group.app_sg.id``, which is not an asset.
    The attribute suffix is dropped deliberately.
    """
    text = str(value).strip().strip('"').strip("'")
    # The ``$`` is optional: Terraform accepts both "${aws_x.y.id}" and the
    # bare "aws_x.y.id" inside a list attribute.
    match = re.match(r"^\$?\{?([\w-]+)\.([\w-]+)(?:\.[\w-]+)?\}?$", text)
    if not match:
        return text
    return f"tf:{match.group(1)}.{match.group(2)}"


def _terraform_relations(asset_id: str, properties: dict, body: str,
                         name: str, line: int) -> list[Relation]:
    """
    Relations implied by a Terraform resource's placement.

    Direction matters: the resource *is placed in* a security group, but traffic
    flows from the group to the resource. Emitting ``resource -> group`` left
    every database unreachable in the graph even with an open group attached,
    which is the one path this tool exists to find.
    """
    relations: list[Relation] = []
    groups = properties.get("vpc_security_group_ids") or \
        properties.get("security_groups") or properties.get("security_group_ids")
    if groups:
        for group in _split_refs(groups):
            relations.append(Relation(group, asset_id, "allows",
                                      "allows traffic to this resource"))
    vpc = properties.get("vpc_id")
    if vpc:
        relations.append(Relation(normalise_reference(vpc), asset_id, "allows",
                                  "the network hosting this resource"))
    subnet = properties.get("subnet_id")
    if subnet:
        relations.append(Relation(normalise_reference(subnet), asset_id, "allows",
                                  "the subnet hosting this resource"))
    return relations


def _split_refs(value: Any) -> list[str]:
    """Split a list-valued attribute that may hold several references."""
    text = str(value).strip()
    if text.startswith("["):
        text = text[1:-1]
    parts = [p for p in text.split(",") if p.strip()]
    return [normalise_reference(p) for p in parts]


def _parse_kubernetes(text: str, name: str) -> tuple[list[Asset], list[Relation], list[str]]:
    """Kubernetes manifests."""
    assets: list[Asset] = []
    relations: list[Relation] = []
    notes: list[str] = []

    try:
        documents = [d for d in yaml.safe_load_all(text) if d]
    except yaml.YAMLError as exc:
        return [], [], [f"{name}: YAML parse error, file not analysed: {exc}"]

    for document in documents:
        if not isinstance(document, dict):
            notes.append(f"{name}: document is not a mapping, skipped")
            continue
        kind = str(document.get("kind", "")).lower()
        metadata = document.get("metadata") or {}
        resource_name = metadata.get("name", "unnamed")
        namespace = metadata.get("namespace", "default")

        if kind in ("deployment", "statefulset", "daemonset", "pod", "replicaset"):
            asset_kind = "compute"
        elif kind == "service":
            asset_kind = "load_balancer"
        elif kind == "ingress":
            asset_kind = "load_balancer"
        elif kind == "secret":
            asset_kind = "secret"
        elif kind == "serviceaccount":
            asset_kind = "identity"
        elif kind == "persistentvolumeclaim":
            asset_kind = "storage"
        elif kind in ("configmap",):
            asset_kind = "storage"
        else:
            notes.append(f"{name}: Kubernetes kind {kind!r} not mapped, not analysed")
            continue

        asset_id = f"k8s:{namespace}/{kind}/{resource_name}"
        spec = document.get("spec") or {}
        properties: dict[str, Any] = {
            "namespace": namespace,
        }
        if kind == "service":
            properties["type"] = spec.get("type", "ClusterIP")
            if spec.get("type") == "LoadBalancer":
                properties["public"] = True
        if kind == "ingress":
            properties["public"] = True
            tls = spec.get("tls")
            properties["tls"] = bool(tls)
        if kind == "serviceaccount":
            properties["automount_token"] = spec.get(
                "automountServiceAccountToken", True)
        if kind == "secret":
            properties["type_hint"] = document.get("type", "Opaque")
        pod_spec = (spec.get("template", {}).get("spec")
                    if kind in ("deployment", "statefulset", "daemonset") else spec)
        if isinstance(pod_spec, dict):
            sa = pod_spec.get("serviceAccountName")
            if sa:
                properties["service_account"] = sa
            for volume in pod_spec.get("volumes") or []:
                if isinstance(volume, dict) and "secret" in volume:
                    secret_name = (volume["secret"].get("secretName")
                                   if isinstance(volume["secret"], dict) else None)
                    if secret_name:
                        relations.append(Relation(
                            asset_id, f"k8s:{namespace}/secret/{secret_name}",
                            "grants",
                            "mounts this secret into the pod"))

        assets.append(Asset(id=asset_id, kind=asset_kind, name=resource_name,
                            provider="kubernetes", properties=properties,
                            source_file=name))

    # Service -> workload links by label selector.
    for asset in list(assets):
        if asset.kind != "load_balancer":
            continue
        for document in documents:
            if not isinstance(document, dict):
                continue
            if str(document.get("kind", "")).lower() != "deployment":
                continue
            selector = ((document.get("spec") or {}).get("selector") or {})
            labels = (document.get("spec") or {}).get("template", {}).get(
                "metadata", {}).get("labels", {})
            if labels and selector.get("matchLabels") and \
                    labels == selector["matchLabels"]:
                workload = document.get("metadata", {}).get("name", "unnamed")
                namespace = document.get("metadata", {}).get("namespace", "default")
                relations.append(Relation(
                    asset.id, f"k8s:{namespace}/deployment/{workload}",
                    "routes_to", "service selects this workload"))
    return assets, relations, notes


def _parse_compose(text: str, name: str) -> tuple[list[Asset], list[Relation], list[str]]:
    """Docker Compose."""
    try:
        document = yaml.safe_load(text) or {}
    except yaml.YAMLError as exc:
        return [], [], [f"{name}: YAML parse error: {exc}"]

    services = document.get("services") or {}
    if not isinstance(services, dict):
        return [], [], [f"{name}: no services mapping"]

    assets: list[Asset] = []
    relations: list[Relation] = []
    notes: list[str] = []
    for service_name, config in services.items():
        if not isinstance(config, dict):
            continue
        ports = config.get("ports") or []
        published = []
        for mapping in ports if isinstance(ports, list) else []:
            text_port = str(mapping)
            published.append(text_port.split(":")[0] if ":" in text_port
                             else text_port)
        properties: dict[str, Any] = {
            "image": config.get("image", ""),
            "published_ports": published,
            "privileged": bool(config.get("privileged")),
        }
        if published:
            properties["public"] = any(
                port.split("-")[0] in ("0.0.0.0", "") or True for port in published)
        # A database or cache image is a data store regardless of intent.
        image = str(config.get("image", "")).lower()
        if any(marker in image for marker in ("postgres", "mysql", "mariadb",
                                              "mongo", "redis", "cassandra")):
            properties["is_database"] = True
        if any(marker in image for marker in ("vault", "consul")):
            properties["is_secret"] = True

        asset_id = f"compose:{service_name}"
        assets.append(Asset(id=asset_id,
                            kind="database" if properties.get("is_database")
                            else "secret" if properties.get("is_secret")
                            else "compute",
                            name=service_name, provider="docker-compose",
                            properties=properties, source_file=name))

        for dependency in (config.get("depends_on") or []):
            relations.append(Relation(asset_id, f"compose:{dependency}",
                                      "depends_on", "waits for another service"))
        for mount in (config.get("volumes") or []):
            if str(mount).startswith("/") or ":" in str(mount):
                relations.append(Relation(asset_id, f"compose:host-fs:{mount}",
                                          "contains", "bind-mounted path"))

    # The host is internet-reachable if any published port exists.
    if any(a.properties.get("published_ports") for a in assets):
        assets.append(Asset(id="compose:host", kind="internet",
                            name="docker host", provider="docker-compose",
                            properties={}, source_file=name))
        for asset in assets:
            if asset.properties.get("published_ports") and asset.kind != "internet":
                relations.append(Relation("compose:host", asset.id, "allows",
                                          "published port on the docker host"))
    return assets, relations, notes


def _parse_json(text: str, name: str) -> tuple[list[Asset], list[Relation], list[str]]:
    """A JSON asset inventory produced by this tool, or a plain list of assets."""
    try:
        document = json.loads(text)
    except json.JSONDecodeError as exc:
        return [], [], [f"{name}: JSON parse error: {exc}"]

    if isinstance(document, dict) and "assets" in document:
        assets = [Asset(id=a["id"], kind=a.get("kind", "compute"),
                        name=a.get("name", ""), provider=a.get("provider", ""),
                        properties=a.get("properties", {}), source_file=name)
                  for a in document["assets"]]
        relations = [Relation(r["source"], r["target"], r.get("kind", "allows"),
                              r.get("note", ""))
                     for r in document.get("relations", [])]
        return assets, relations, []

    if isinstance(document, list):
        assets = []
        for item in document:
            if not isinstance(item, dict) or "id" not in item:
                continue
            assets.append(Asset(id=item["id"], kind=item.get("kind", "compute"),
                                name=item.get("name", ""),
                                provider=item.get("provider", ""),
                                properties=item.get("properties", {}),
                                source_file=name))
        return assets, [], []

    return [], [], [f"{name}: JSON shape not recognised, not analysed"]


def load_directory(path: str | Path) -> tuple[list[Asset], list[Relation], list[str]]:
    """Parse every recognised config file under a path."""
    root = Path(path)
    assets: list[Asset] = []
    relations: list[Relation] = []
    notes: list[str] = []
    files = [root] if root.is_file() else sorted(root.rglob("*"))
    for candidate in files:
        if not candidate.is_file() or candidate.suffix not in (
                ".tf", ".tfvars", ".yaml", ".yml", ".json"):
            continue
        if any(part in (".terraform", "node_modules", ".git")
               for part in candidate.parts):
            continue
        a, r, n = parse_file(candidate)
        assets += a
        relations += r
        notes += n
    return assets, relations, notes


# -- rules --------------------------------------------------------------

def evaluate_assets(assets: list[Asset],
                    unverified: Optional[list[str]] = None) -> list[Finding]:
    """
    Run every rule over every asset.

    Rules are pure functions of the asset's properties. Keeping them declarative
    means adding a cloud provider does not mean auditing every check.

    ``unverified`` collects things that could not be determined from the config
    -- chiefly encryption settings that are absent rather than explicitly off.
    Those are reported as unknown, never as vulnerabilities: a scanner that
    reports "probably insecure" for every setting it cannot see is a scanner
    whose output gets ignored.
    """
    findings: list[Finding] = []
    unverified = unverified if unverified is not None else []

    for asset in assets:
        props = asset.properties

        if asset.kind == "security_group":
            if _is_open_cidr(props.get("cidr_blocks")) or props.get("open"):
                findings.append(_finding(asset, RULES_BY_ID["SG_INGRESS_OPEN"],
                                        evidence=_describe(asset)))
            admin_ports = {"22", "3389", "5432", "3306", "27017", "6379"}
            published = {str(p).split("-")[0] for p in
                         (props.get("from_ports") or props.get("ports") or [])}
            if published & admin_ports:
                findings.append(
                    _finding(asset, RULES_BY_ID["ADMIN_SSH_OPEN"],
                             evidence=_describe(asset)))

        if asset.kind == "storage":
            acl = str(props.get("acl", "")).lower()
            # Buckets default to private, so a public ACL has to be set on
            # purpose -- which makes it one of the most reliably shipped
            # accidental exposures in cloud.
            if "public" in acl:
                findings.append(
                    _finding(asset, RULES_BY_ID["S3_PUBLIC"],
                             evidence=_describe(asset) +
                             f"\nacl is {acl!r}, which grants world access",
                             severity=Severity.CRITICAL))
            if asset.is_public and "public" not in acl:
                findings.append(_finding(asset, RULES_BY_ID["S3_PUBLIC"],
                                        evidence=_describe(asset)))
            if props.get("public_access_block") in (False, "false"):
                findings.append(_finding(asset, RULES_BY_ID["S3_PUBLIC"],
                                        evidence=_describe(asset) +
                                        "\npublic access block is disabled",
                                        severity=Severity.CRITICAL))
            if not props.get("versioning", True):
                findings.append(_finding(asset, RULES_BY_ID["STORAGE_NO_VERSIONING"],
                                        evidence=_describe(asset)))
            if props.get("encrypted") is False:
                findings.append(_finding(asset, RULES_BY_ID["STORAGE_NO_VERSIONING"],
                                        evidence=_describe(asset),
                                        severity=Severity.MEDIUM))

        if asset.kind == "database":
            if asset.is_public or props.get("publicly_accessible") is True:
                findings.append(_finding(asset, RULES_BY_ID["RDS_PUBLIC"],
                                        evidence=_describe(asset)))
            if props.get("encrypted") is False:
                findings.append(_finding(asset, RULES_BY_ID["UNENCRYPTED_VOLUME"],
                                        evidence=_describe(asset)))
            for key in ("username", "master_username", "admin_user"):
                if props.get(key) in ("root", "admin", "postgres", "mysql"):
                    findings.append(
                        _finding(asset, RULES_BY_ID["RDS_PUBLIC"],
                                 evidence=f"{key}={props[key]!r}: a well-known "
                                          f"admin account name on a database",
                                 severity=Severity.HIGH))

        if asset.kind == "identity":
            # The policy is usually wrapped in jsonencode({...}) spanning many
            # lines, so reading props["policy"] alone sees only the text
            # "jsonencode({" and misses the wildcard inside. Scan every
            # captured attribute as well as the policy text.
            policy = json.dumps(props.get("policy") or props.get("policy_json")
                               or props.get("policy_document") or "")
            haystack = policy + " " + " ".join(str(v) for v in props.values())
            if re.search(r'"\*"', haystack):
                findings.append(_finding(asset, RULES_BY_ID["IAM_WILDCARD"],
                                        evidence=_describe(asset)))
            for broad in ("iam:*", "s3:*", "*:*", "iam:PassRole",
                          "sts:AssumeRole"):
                if broad in haystack:
                    findings.append(
                        _finding(asset, RULES_BY_ID["IAM_WILDCARD"],
                                 evidence=f"policy contains broad action {broad}",
                                 severity=Severity.CRITICAL
                                 if broad in ("iam:*", "s3:*", "*:*")
                                 else Severity.HIGH))
            if props.get("password") or props.get("access_key"):
                findings.append(
                    _finding(asset, RULES_BY_ID["IAM_WILDCARD"],
                             evidence="long-lived credential material in the "
                                      "resource definition",
                             severity=Severity.CRITICAL))

        if asset.kind == "secret":
            # Only an *explicit* statement of no encryption is a finding. An
            # absent attribute means "not stated in this file", which is not
            # the same as "unencrypted" -- treating it as equivalent produced a
            # false positive against a hardened config that relies on the
            # provider default. Absent encryption is recorded as a note instead.
            if props.get("encrypted") is False or props.get("encryption") is False:
                findings.append(_finding(asset, RULES_BY_ID["SECRET_UNENCRYPTED"],
                                        evidence=_describe(asset)))
            elif props.get("encrypted") is None and props.get("encryption") is None:
                unverified.append(
                    f"{asset.label()}: encryption is not stated in "
                    f"{asset.source_file}, so it could not be verified")

        if asset.kind == "compute":
            if props.get("privileged"):
                findings.append(
                    _finding(asset, RULES_BY_ID["PRIVILEGED_CONTAINER"],
                             severity=Severity.HIGH,
                             evidence="privileged container: full host access"))
            if props.get("encrypted") is False or props.get("root_block_device") is False:
                findings.append(_finding(asset, RULES_BY_ID["UNENCRYPTED_VOLUME"],
                                        evidence=_describe(asset)))
            if props.get("log_bodies") or props.get("log_payloads"):
                findings.append(_finding(asset, RULES_BY_ID["PLAINTEXT_LOGGING"],
                                        evidence=_describe(asset)))
            if props.get("host_network"):
                findings.append(
                    _finding(asset, RULES_BY_ID["SG_INGRESS_OPEN"],
                             severity=Severity.HIGH,
                             evidence="host networking: the pod shares the "
                                      "node's interfaces, so every cluster "
                                      "node becomes reachable"))

        if asset.kind == "load_balancer":
            if props.get("public") and not props.get("tls", True):
                findings.append(_finding(asset, RULES_BY_ID["MISSING_TLS"],
                                        evidence=_describe(asset)))

    return dedupe(findings)


def _is_open_cidr(cidrs: Any) -> bool:
    if not cidrs:
        return False
    text = str(cidrs)
    return "0.0.0.0/0" in text or "::/0" in text or '"*"' in text


def _describe(asset: Asset) -> str:
    lines = [f"{asset.label()} ({asset.id})",
             f"file: {asset.source_file}:{asset.source_line}",
             f"provider: {asset.provider or 'unknown'}"]
    for key, value in sorted(asset.properties.items()):
        lines.append(f"  {key}: {value}")
    return "\n".join(lines)


def _finding(asset: Asset, rule: Rule, evidence: str = "",
             severity: Optional[Severity] = None) -> Finding:
    return Finding(
        title=f"{rule.title} ({asset.label()})",
        severity=severity or rule.severity,
        category="A05:2021 Security Misconfiguration",
        target=asset.source_file or asset.id,
        location=asset.label(),
        detector=f"cloudpath:{rule.id}",
        product=PRODUCT,
        description=rule.why,
        impact=rule.why,
        remediation=rule.fix,
        confidence=1.0 if evidence else 0.7,
        tags=["internet_facing"] if asset.is_public else ["cloud_config"],
        evidence=Evidence(
            request=f"configuration: {asset.source_file}:{asset.source_line}",
            response=evidence or _describe(asset),
            extra={"rule": rule.id, "asset_kind": asset.kind,
                   "cwe": rule.cwe}),
        references=[r for r in rule.references] or
                   ([f"https://cwe.mitre.org/data/definitions/{rule.cwe.split('-')[1]}.html"]
                    if rule.cwe else []),
    )


# -- attack paths --------------------------------------------------------

def build_graph(assets: list[Asset], relations: list[Relation]) -> nx.DiGraph:
    """The asset graph, plus the implicit edges the config implies."""
    graph = nx.DiGraph()
    for asset in assets:
        graph.add_node(asset.id, kind=asset.kind, name=asset.name or asset.id,
                       public=asset.is_public, sensitive=asset.is_sensitive)

    for relation in relations:
        if relation.source in graph and relation.target in graph:
            graph.add_edge(relation.source, relation.target,
                           kind=relation.kind, note=relation.note)
            continue
        # References to assets defined elsewhere are common in IaC. Add a
        # placeholder rather than dropping the edge, because dropping it would
        # hide a real path.
        for node in (relation.source, relation.target):
            if node not in graph:
                graph.add_node(node, kind="unknown", name=node, public=False,
                               sensitive=False, placeholder=True)
        graph.add_edge(relation.source, relation.target, kind=relation.kind,
                       note=relation.note)

    for asset in assets:
        if asset.is_public and asset.kind not in ("internet",):
            graph.add_node("internet", kind="internet", name="the internet",
                           public=True, sensitive=False)
            graph.add_edge("internet", asset.id, kind="allows",
                           note="publicly reachable")

    return graph


def find_attack_paths(graph: nx.DiGraph, assets: dict[str, Asset],
                      max_depth: int = 6, limit: int = 40) -> list[AttackPath]:
    """
    Enumerate routes from the internet to sensitive assets.

    Depth-limited and cycle-free. Unbounded enumeration on a real cloud graph
    produces an exponential number of paths, and nobody reads path 4000.
    """
    if "internet" not in graph:
        return []

    targets = [n for n, data in graph.nodes(data=True)
               if data.get("sensitive") and data.get("kind") != "identity"]
    targets += [n for n, data in graph.nodes(data=True)
                if data.get("kind") == "identity" and data.get("public")]

    paths: list[AttackPath] = []
    for target in sorted(set(targets)):
        try:
            simple = nx.all_simple_paths(graph, "internet", target,
                                         cutoff=max_depth)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            continue
        for nodes in simple:
            edges = [Relation(source=nodes[i], target=nodes[i + 1],
                              kind=graph[nodes[i]][nodes[i + 1]].get("kind", "allows"),
                              note=graph[nodes[i]][nodes[i + 1]].get("note", ""))
                     for i in range(len(nodes) - 1)]
            final_kind = graph.nodes[target].get("kind", "unknown")
            path = AttackPath(nodes=nodes, edges=edges)
            path.score = IMPACT.get(final_kind, 3) + (10 - len(edges))
            paths.append(path)
            if len(paths) >= limit:
                return sorted(paths, key=lambda p: -p.score)

    return sorted(paths, key=lambda p: -p.score)


def paths_to_findings(paths: list[AttackPath], graph: nx.DiGraph,
                      assets: dict[str, Asset]) -> list[Finding]:
    """
    Turn a reachable path into a finding whose severity reflects reachability.

    This is where the product earns its name: the same open security group is
    MEDIUM on its own and CRITICAL when there is a path from the internet to a
    database through it.
    """
    findings: list[Finding] = []
    for path in paths:
        final = path.nodes[-1]
        asset = assets.get(final)
        if asset is None:
            continue
        # Include nodes the graph synthesised ("internet") so the chain always
        # reads from the entry point. Dropping it made a one-hop path render as
        # a bare asset name with no indication of where the attacker starts.
        steps = " -> ".join(
            assets[n].label() if n in assets else n.replace("_", " ")
            for n in path.nodes)
        findings.append(Finding(
            title=f"Internet-reachable path to {asset.label()} "
                  f"in {path.hops} hop(s)",
            severity=Severity.CRITICAL if asset.kind in ("database", "secret")
            else Severity.HIGH,
            category="A04:2021 Insecure Design",
            target=asset.source_file or asset.id,
            location=asset.label(),
            detector="cloudpath:attack_path",
            product=PRODUCT,
            description=f"An attacker starting from the public internet can "
                        f"reach this asset in {path.hops} hop(s): {steps}.",
            impact=f"Direct compromise of {asset.kind} data through a chain of "
                   f"permitted relationships. Each hop is individually "
                   f"defensible; the chain is not.",
            remediation="Break the chain at its weakest link: the public "
                        "entry point, the permissive relationship, or the "
                        "sensitive resource itself. Adding a single deny rule "
                        "or removing one public edge is usually enough.",
            tags=["internet_facing", "confirmed_by_probe", "data_returned"],
            evidence=Evidence(
                request="graph traversal from 'internet'",
                response=steps,
                extra={"hops": path.hops, "score": round(path.score, 1),
                       "path": path.nodes}),
        ))
    return findings


# -- the analysis --------------------------------------------------------

@dataclass
class ScanConfig:
    max_path_depth: int = 6
    max_paths: int = 40


@dataclass
class ScanResult:
    findings: list[Finding]
    paths: list[AttackPath]
    assets: list[Asset]
    relations: list[Relation]
    notes: list[str]
    started_at: str
    duration_s: float

    def summary(self) -> dict:
        scored = prioritise(self.findings)
        by_kind: dict[str, int] = {}
        for asset in self.assets:
            by_kind[asset.kind] = by_kind.get(asset.kind, 0) + 1
        reachable = {p.nodes[-1] for p in self.paths}
        return {
            **risk_summary(scored),
            "assets": len(self.assets),
            "relations": len(self.relations),
            "assets_by_kind": by_kind,
            "attack_paths": len(self.paths),
            "reachable_sensitive": len(reachable),
            "unparsed_notes": len(self.notes),
            "duration_s": round(self.duration_s, 1),
        }


def analyse(path: str | Path, config: Optional[ScanConfig] = None,
            log=print) -> ScanResult:
    """Full CloudPath analysis of a configuration directory."""
    config = config or ScanConfig()
    started = time.perf_counter()
    started_at = utcnow()

    assets, relations, notes = load_directory(path)
    log(f"  parsed {len(assets)} asset(s), {len(relations)} relation(s)")
    if notes:
        log(f"  {len(notes)} note(s) about what was NOT parsed")

    log("evaluating configuration rules...")
    unverified: list[str] = []
    rule_findings = evaluate_assets(assets, unverified)
    notes = notes + unverified
    if unverified:
        log(f"  {len(unverified)} setting(s) could not be verified from config")

    log("building the attack graph...")
    graph = build_graph(assets, relations)
    log(f"  {graph.number_of_nodes()} node(s), {graph.number_of_edges()} edge(s)")

    index = {a.id: a for a in assets}
    log(f"tracing paths (max depth {config.max_path_depth})...")
    paths = find_attack_paths(graph, index, config.max_path_depth,
                              config.max_paths)
    log(f"  {len(paths)} internet-reachable path(s) to sensitive assets")

    path_findings = paths_to_findings(paths, graph, index)
    findings = dedupe(rule_findings + path_findings)

    duration = time.perf_counter() - started
    log(f"done in {duration:.1f}s: {len(findings)} finding(s), "
        f"{len(paths)} attack path(s)")
    return ScanResult(findings=findings, paths=paths, assets=assets,
                      relations=relations, notes=notes, started_at=started_at,
                      duration_s=duration)