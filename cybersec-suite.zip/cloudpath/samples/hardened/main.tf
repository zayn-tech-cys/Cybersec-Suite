# Hardened counterpart to ../vulnerable/. Used by the test suite as a negative
# control: CloudPath must report nothing here.
#
# Every mistake made in the vulnerable sample is corrected here -- open CIDRs
# scoped, buckets private and encrypted and versioned, the database private and
# encrypted, wildcard IAM replaced with named actions, the secret store
# encrypted, and no privileged containers or host networking.

provider "aws" {
  region = "eu-west-1"
}

resource "aws_security_group" "app_sg" {
  name = "app-sg"

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }
}

resource "aws_instance" "app_server" {
  ami           = "ami-0abcdef1234567890"
  instance_type = "t3.medium"
  vpc_security_group_ids = ["${aws_security_group.app_sg.id}"]

  root_block_device {
    encrypted = true
  }

  tags = {
    Name = "app-server"
  }
}

resource "aws_s3_bucket" "customer_uploads" {
  bucket = "acme-customer-uploads"

  acl       = "private"
  encrypted = true

  versioning {
    enabled = true
  }
}

resource "aws_db_instance" "customers" {
  identifier     = "customers-db"
  engine         = "postgres"
  instance_class = "db.t3.medium"

  publicly_accessible = false
  encrypted           = true
  username            = "app_service"

  vpc_security_group_ids = ["${aws_security_group.app_sg.id}"]
}

resource "aws_iam_policy" "developer" {
  name = "developer-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:PutObject"]
        Resource = "arn:aws:s3:::acme-customer-uploads/*"
      }
    ]
  })
}

resource "aws_secretsmanager_secret" "db_password" {
  name = "customers-db-password"

  kms_key_id = "arn:aws:kms:eu-west-1:123456789012:key/example"
}