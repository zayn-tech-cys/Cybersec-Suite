# Vulnerable example Terraform. Not real infrastructure, and not applied.
#
# Every misconfiguration here is deliberate so CloudPath has something to find.
# The "attack chain" this file encodes is the point of the demo:
#
#   internet -> open security group -> app server -> secrets manager
#   internet -> open security group -> RDS holding customer data
#
# Each hop is individually the sort of thing that ships by accident, and the
# combination is a total compromise.

provider "aws" {
  region = "eu-west-1"
}

# CRITICAL: open to the whole internet.
resource "aws_security_group" "app_sg" {
  name = "app-sg"

  ingress {
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "app_server" {
  ami           = "ami-0abcdef1234567890"
  instance_type = "t3.medium"
  vpc_security_group_ids = ["${aws_security_group.app_sg.id}"]

  root_block_device {
    encrypted = false
  }

  tags = {
    Name = "app-server"
  }
}

# CRITICAL: publicly readable bucket.
resource "aws_s3_bucket" "public_assets" {
  bucket = "acme-public-assets"

  acl    = "public-read"
  versioning {
    enabled = false
  }
}

resource "aws_s3_bucket" "customer_uploads" {
  bucket = "acme-customer-uploads"

  acl       = "private"
  encrypted = true

  versioning {
    enabled = true
  }
}

# CRITICAL: database on a public IP, open admin account, unencrypted.
resource "aws_db_instance" "customers" {
  identifier     = "customers-db"
  engine         = "postgres"
  instance_class = "db.t3.medium"

  publicly_accessible = true
  encrypted           = false
  username            = "root"
  password            = "placeholder-not-a-real-password"

  vpc_security_group_ids = ["${aws_security_group.app_sg.id}"]

  tags = {
    Name = "customers-db"
  }
}

# HIGH: wildcard permissions are equivalent to giving away the account.
resource "aws_iam_policy" "developer" {
  name = "developer-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "*"
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role" "app_role" {
  name = "app-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

# HIGH: unencrypted secret store.
resource "aws_secretsmanager_secret" "db_password" {
  name = "customers-db-password"
}