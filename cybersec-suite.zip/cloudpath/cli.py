#!/usr/bin/env python
"""
CloudPath command line.

    python -m cloudpath.cli ./infra
    python -m cloudpath.cli ./infra --json report.json --fail-on critical

Reads configuration only. No cloud account is contacted and no credentials are
used, which is what makes it safe to run in CI against your whole repository.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cloudpath.engine import (  # noqa: E402
    PRODUCT, ScanConfig, analyse, build_graph, find_attack_paths)
from core.models import Severity  # noqa: E402
from core.report import report_html, report_json  # noqa: E402
from core.risk import gate, prioritise  # noqa: E402
from core.storage import Store  # noqa: E402

COLOURS = {
    "critical": "\033[41;97m", "high": "\033[43;30m", "medium": "\033[43;30m",
    "low": "\033[46;30m", "info": "\033[100;30m", "reset": "\033[0m",
    "dim": "\033[2m", "bold": "\033[1m", "path": "\033[36m",
}


def colour(text: str, name: str, on: bool) -> str:
    return f"{COLOURS.get(name,'')}{text}{COLOURS['reset']}" if on else text


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cloudpath")
    parser.add_argument("path", help="config directory or file")
    parser.add_argument("--max-depth", type=int, default=6,
                        help="maximum attack path length")
    parser.add_argument("--fail-on", default="critical",
                        choices=["critical", "high", "medium", "low", "info",
                                 "none"])
    parser.add_argument("--json", metavar="PATH")
    parser.add_argument("--html", metavar="PATH")
    parser.add_argument("--no-color", action="store_true")
    parser.add_argument("--no-store", action="store_true")
    parser.add_argument("--show-graph", action="store_true",
                        help="print every attack path found")
    args = parser.parse_args(argv)
    colour_on = not args.no_color and sys.stdout.isatty()

    target = Path(args.path)
    if not target.exists():
        print(f"error: no such path: {target}", file=sys.stderr)
        return 2

    print(colour(f"analysing {target}...", "bold", colour_on))
    result = analyse(target, ScanConfig(max_path_depth=args.max_depth),
                     log=lambda m: print(colour(m, "dim", colour_on)))

    summary = result.summary()
    print()
    print(colour(f"  {summary['assets']} asset(s), {summary['relations']} "
                 f"relation(s), {summary['attack_paths']} attack path(s)",
                 "bold", colour_on))
    print(f"  {summary['total']} finding(s), {summary['actionable']} actionable")

    index = {a.id: a for a in result.assets}
    if args.show_graph and result.paths:
        print()
        print(colour("  ATTACK PATHS", "bold", colour_on))
        for path in result.paths[:15]:
            chain = " -> ".join(index[n].label() if n in index else n
                               for n in path.nodes)
            print(f"  {colour(f'{path.hops}h', 'dim', colour_on):>4}  {chain}")
    elif result.paths:
        print(f"  shortest reachable crown jewel: "
              f"{result.paths[0].hops} hop(s) "
              f"(use --show-graph for all)")

    scored = prioritise(result.findings)
    if scored:
        print()
        for item in scored:
            tag = colour(f" {item.severity.value.upper():<8}",
                         item.severity.value, colour_on)
            print(f"  {tag} {item.score:>5}  {item.finding.title}")

    if result.notes:
        print()
        print(colour(f"  NOT parsed or NOT verified ({len(result.notes)}):",
                     "bold", colour_on))
        for note in result.notes[:8]:
            print(f"    - {colour(note[:92], 'dim', colour_on)}")
        if len(result.notes) > 8:
            print(f"    ... and {len(result.notes) - 8} more")

    if not args.no_store:
        try:
            store = Store()
            key = str(target.resolve())
            target_id = store.add_target(key, "cloud", key, authorized=True)
            scan_id = store.start_scan(target_id, "cloudpath")
            diff = store.record_scan(scan_id, target_id, "cloudpath",
                                     result.findings)
            payload = {**summary, "notes": result.notes[:40]}
            store.finish_scan(scan_id, "completed", payload)
            print()
            print(f"  recorded as scan #{scan_id} ({diff['new']} new, "
                  f"{diff['recurring']} regressed)")
        except Exception as exc:
            print(f"  could not record: {exc}")

    meta = {"target": str(target), "product": "cloudpath",
            "assets": summary["assets"], "attack paths": summary["attack_paths"]}
    if args.json:
        Path(args.json).write_text(
            report_json(result.findings, str(target), "cloudpath", meta),
            encoding="utf-8")
        print(f"  JSON report -> {args.json}")
    if args.html:
        Path(args.html).write_text(
            report_html(result.findings, str(target), "cloudpath", meta,
                        title="CloudPath Report"),
            encoding="utf-8-sig")
        print(f"  HTML report -> {args.html}")

    if args.fail_on != "none":
        level = Severity(args.fail_on)
        passed, reasons = gate(result.findings, level)
        print()
        if passed:
            print(colour(f"  GATE PASSED: no findings at {level.value} or worse",
                         "bold", colour_on))
            return 0
        print(colour(f"  GATE FAILED: {len(reasons)} finding(s) at {level.value}"
                     f" or worse", "bold", colour_on))
        for reason in reasons[:10]:
            print(f"    - {reason}")
        if len(reasons) > 10:
            print(f"    ... and {len(reasons) - 10} more")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())