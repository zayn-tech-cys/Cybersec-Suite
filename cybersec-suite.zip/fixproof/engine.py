"""
FixProof engine: turn fixed vulnerabilities into permanent regression tests.

The problem this solves is specific and under-served. A team fixes a bug, marks
the ticket closed, and moves on. Six months later a refactor reintroduces it,
nobody notices, and the bug ships. The knowledge that "this was broken here once"
existed in a chat message and a closed ticket, and is now gone.

So FixProof does two things:

1. **Lifts every historical finding into a durable test.** A fixed finding does
   not stop existing -- it becomes a regression test that must keep passing.
2. **Runs the whole suite on demand and fails on regressions**, with a gate
   suitable for CI.

Design decisions worth stating:

* **Re-verification re-runs the original product's engine**, rather than
  reimplementing each check. A fix that satisfies a bespoke re-check but not
  the real scanner is not a fix, and a tool that reported it as one would be
  actively misleading.
* **A first run is a baseline, not a pass.** Claiming "no regressions" before
  anything has been fixed once would mark every currently-open vulnerability as
  expected behaviour.
* **Flaky tests are reported separately from regressions.** A test alternating
  between pass and fail is a broken test; calling that a regression sends
  people chasing a bug that is not there.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from typing import Optional

from core.models import Finding, Severity, Status, utcnow
from core.risk import gate
from core.storage import Store

PRODUCT = "fixproof"


@dataclass
class RegressionTest:
    """
    A durable assertion that one vulnerability stays fixed.

    ``detector`` plus ``product`` is what makes it re-checkable: the executor
    re-runs that product's engine and asks whether a finding with this
    fingerprint came back.
    """
    fingerprint: str
    product: str
    detector: str
    title: str
    severity: Severity
    target: str
    location: str = ""
    origin_scan: Optional[int] = None
    created_at: str = field(default_factory=utcnow)
    # A test that has never passed is "expected to fail right now"; it becomes a
    # real assertion only once a fix is observed.
    armed: bool = False
    first_passed: Optional[str] = None
    last_result: str = "unknown"      # pass | fail | pending
    last_checked: Optional[str] = None
    run_count: int = 0
    fail_count: int = 0
    regression_count: int = 0
    recent_results: list[str] = field(default_factory=list)
    notes: str = ""

    def key(self) -> str:
        return f"{self.product}|{self.fingerprint}"

    def to_dict(self) -> dict:
        data = asdict(self)
        data["severity"] = self.severity.value
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "RegressionTest":
        data = dict(data)
        data["severity"] = Severity(data.get("severity", "info"))
        return cls(**data)

    @property
    def is_flaky(self) -> bool:
        """
        Alternating results over recent history.

        Requires at least four results containing both a pass and a failure,
        *and* that the last two disagree. Requiring the last two to agree is
        what distinguishes a still-flapping check from one that has settled:
        pass, fail, pass, fail, pass, pass has been unstable, but its two most
        recent runs agree, so calling it flaky now would send someone chasing a
        problem that stopped happening.
        """
        recent = self.recent_results[-4:]
        if len(recent) < 4:
            return False
        if "pass" not in recent or "fail" not in recent:
            return False
        return recent[-1] != recent[-2]

    @property
    def stability(self) -> float:
        if not self.run_count:
            return 0.0
        return round(1.0 - (self.fail_count / self.run_count), 3)


@dataclass
class CheckResult:
    test: RegressionTest
    outcome: str            # pass | fail | pending | error | flaky
    detail: str = ""
    duration_s: float = 0.0

    @property
    def is_regression(self) -> bool:
        return self.outcome == "fail"


@dataclass
class RunResult:
    """One execution of the whole suite."""
    started_at: str
    duration_s: float
    baseline: bool
    results: list[CheckResult]
    skipped: list[tuple[str, str]] = field(default_factory=list)

    def summary(self) -> dict:
        outcomes: dict[str, int] = {}
        for result in self.results:
            outcomes[result.outcome] = outcomes.get(result.outcome, 0) + 1
        regressions = [r for r in self.results if r.is_regression]
        flaky = [r for r in self.results if r.outcome == "flaky"]
        return {
            **outcomes,
            "checked": len(self.results),
            "regressions": len(regressions),
            "flaky": len(flaky),
            "baseline": self.baseline,
            "skipped": len(self.skipped),
        }


# -- test generation -----------------------------------------------------

def tests_from_findings(findings: list[Finding], product: str,
                        target: str, origin_scan: Optional[int] = None
                        ) -> list[RegressionTest]:
    """
    Lift recorded findings into regression tests.

    Every finding becomes a test, including ones still open. An open finding
    produces a *disarmed* test: it is tracked, and the first run where it stops
    appearing arms it. That way the moment a fix lands, the test starts guarding
    without anyone having to notice and configure it.
    """
    tests: list[RegressionTest] = []
    for finding in findings:
        if finding.status is Status.ACCEPTED:
            continue          # risk-accepted is not going to be "fixed"
        tests.append(RegressionTest(
            fingerprint=finding.fingerprint,
            product=product,
            detector=finding.detector or finding.category,
            title=finding.title,
            severity=finding.severity,
            target=target,
            location=finding.location,
            origin_scan=origin_scan,
            armed=finding.status in (Status.FIXED, Status.RECURRED),
            first_passed=(utcnow() if finding.status is Status.FIXED else None),
            notes=("armed from a previously fixed finding" if
                   finding.status is Status.FIXED else
                   "still open; will arm once a fix is observed"),
        ))
    return tests


# -- persistence ---------------------------------------------------------

class ProofStore:
    """Regression tests and their run history."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS proofs (
        fingerprint  TEXT NOT NULL,
        product      TEXT NOT NULL,
        detector     TEXT NOT NULL,
        title        TEXT NOT NULL,
        severity     TEXT NOT NULL,
        target       TEXT NOT NULL,
        location     TEXT DEFAULT '',
        origin_scan  INTEGER,
        created_at   TEXT NOT NULL,
        armed        INTEGER NOT NULL DEFAULT 0,
        first_passed TEXT,
        last_result  TEXT DEFAULT 'unknown',
        last_checked TEXT,
        run_count    INTEGER NOT NULL DEFAULT 0,
        fail_count   INTEGER NOT NULL DEFAULT 0,
        regression_count INTEGER NOT NULL DEFAULT 0,
        recent       TEXT NOT NULL DEFAULT '[]',
        notes        TEXT DEFAULT '',
        PRIMARY KEY (product, fingerprint)
    );
    CREATE INDEX IF NOT EXISTS proofs_target ON proofs(target);
    CREATE INDEX IF NOT EXISTS proofs_armed ON proofs(armed, last_result);

    CREATE TABLE IF NOT EXISTS proof_runs (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        target      TEXT NOT NULL,
        started_at  TEXT NOT NULL,
        finished_at TEXT,
        baseline    INTEGER NOT NULL DEFAULT 0,
        summary     TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS proof_runs_target ON proof_runs(target, id DESC);
    """

    def __init__(self, path=None) -> None:
        self.store = Store(path)
        with self.store.connect() as conn:
            conn.executescript(self.SCHEMA)

    def upsert(self, test: RegressionTest) -> None:
        """
        Insert or merge a test, preserving history.

        Merging rather than overwriting matters: regenerating the test list
        from a fresh scan must not reset ``run_count`` and make a test that has
        regressed four times look brand new.
        """
        with self.store.connect() as conn:
            # Every column read below must be selected here. ``last_checked``
            # was used without being listed, so any re-import raised
            # IndexError: No item with that key.
            existing = conn.execute(
                "SELECT run_count, fail_count, regression_count, armed, "
                "first_passed, recent, last_result, last_checked "
                "FROM proofs WHERE product = ? AND fingerprint = ?",
                (test.product, test.fingerprint)).fetchone()
            if existing is not None:
                # A test that was disarmed must not be re-armed by regeneration
                # while the finding is still open.
                test.run_count = existing["run_count"]
                test.fail_count = existing["fail_count"]
                test.regression_count = existing["regression_count"]
                test.armed = bool(existing["armed"]) or test.armed
                test.first_passed = existing["first_passed"] or test.first_passed
                test.recent_results = json.loads(existing["recent"] or "[]")
                test.last_result = existing["last_result"]
                test.last_checked = existing["last_checked"]

            conn.execute(
                "INSERT INTO proofs(fingerprint, product, detector, title, "
                "severity, target, location, origin_scan, created_at, armed, "
                "first_passed, last_result, last_checked, run_count, fail_count, "
                "regression_count, recent, notes) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(product, fingerprint) DO UPDATE SET "
                "title=excluded.title, severity=excluded.severity, "
                "target=excluded.target, location=excluded.location, "
                "armed=excluded.armed, notes=excluded.notes",
                (test.fingerprint, test.product, test.detector, test.title,
                 test.severity.value, test.target, test.location,
                 test.origin_scan, test.created_at, int(test.armed),
                 test.first_passed, test.last_result, test.last_checked,
                 test.run_count, test.fail_count, test.regression_count,
                 json.dumps(test.recent_results[-20:]), test.notes))

    def list_tests(self, target: Optional[str] = None) -> list[RegressionTest]:
        """
        Read tests back.

        The ``recent`` column is stored as JSON under a name that does not match
        the dataclass field, so it is renamed on the way out rather than
        splattered through the construction. Unknown columns are dropped so a
        schema addition cannot break the whole listing.
        """
        query = "SELECT * FROM proofs"
        args: tuple = ()
        if target:
            query += " WHERE target = ?"
            args = (target,)
        query += " ORDER BY armed DESC, severity DESC, title"
        known = set(RegressionTest.__dataclass_fields__)
        out: list[RegressionTest] = []
        with self.store.connect() as conn:
            for row in conn.execute(query, args).fetchall():
                data = dict(row)
                data["recent_results"] = json.loads(data.pop("recent") or "[]")
                data["armed"] = bool(data["armed"])
                out.append(RegressionTest.from_dict(
                    {k: v for k, v in data.items() if k in known}))
        return out

    def save_results(self, run: RunResult, target: str) -> int:
        with self.store.connect() as conn:
            cursor = conn.execute(
                "INSERT INTO proof_runs(target, started_at, finished_at, "
                "baseline, summary) VALUES (?, ?, ?, ?, ?)",
                (target, run.started_at, utcnow(), int(run.baseline),
                 json.dumps(run.summary(), default=str)))
            run_id = int(cursor.lastrowid)
            for result in run.results:
                test = result.test
                history = (test.recent_results + [result.outcome])[-20:]
                conn.execute(
                    "UPDATE proofs SET last_result = ?, last_checked = ?, "
                    "run_count = run_count + 1, "
                    "fail_count = fail_count + ?, "
                    "regression_count = regression_count + ?, "
                    "recent = ?, armed = ? WHERE product = ? AND fingerprint = ?",
                    (result.outcome, utcnow(), 1 if result.is_regression else 0,
                     1 if result.is_regression else 0, json.dumps(history),
                     int(test.armed), test.product, test.fingerprint))
        return run_id

    def run_history(self, target: str, limit: int = 25) -> list[dict]:
        with self.store.connect() as conn:
            rows = conn.execute(
                "SELECT id, started_at, finished_at, baseline, summary "
                "FROM proof_runs WHERE target = ? ORDER BY id DESC LIMIT ?",
                (target, limit)).fetchall()
        out = []
        for row in rows:
            data = dict(row)
            data["summary"] = json.loads(data["summary"] or "{}")
            data["baseline"] = bool(data["baseline"])
            out.append(data)
        return out

    def stats(self, target: Optional[str] = None) -> dict:
        tests = self.list_tests(target)
        armed = [t for t in tests if t.armed]
        failing = [t for t in armed if t.last_result == "fail"]
        flaky = [t for t in tests if t.is_flaky]
        ever_regressed = [t for t in tests if t.regression_count]
        return {
            "total": len(tests),
            "armed": len(armed),
            "disarmed": len(tests) - len(armed),
            "failing": len(failing),
            "flaky": len(flaky),
            "ever_regressed": len(ever_regressed),
            "passing": len(armed) - len(failing) - len(
                [t for t in armed if t.is_flaky]),
            "worst_repeat_offender": max(
                tests, key=lambda t: t.regression_count,
                default=None),
        }


# -- execution -----------------------------------------------------------

@dataclass
class RunConfig:
    products: list[str] = field(default_factory=lambda: [
        "autopentest", "apishield", "attackmap", "cloudpath"])
    rate_per_second: float = 10.0
    max_regressions: int = 0


def run_suite(store: ProofStore, target: str, config: Optional[RunConfig] = None,
              identities=None, log=print) -> RunResult:
    """
    Re-run every product's engine and check whether any known finding returned.

    This is the honest implementation: each check re-runs the real scanner.
    The cost is that a suite run costs one scan per product, which is why the
    rate limiter and the per-product scope all still apply.
    """
    config = config or RunConfig()
    started = time.perf_counter()
    started_at = utcnow()

    tests = store.list_tests(target)
    if not tests:
        return RunResult(started_at=started_at,
                         duration_s=time.perf_counter() - started,
                         baseline=True, results=[],
                         skipped=[(target, "no regression tests registered")])

    baseline = not any(t.armed for t in tests)
    if baseline:
        log("  no test has ever passed: this run establishes a baseline, so "
            "nothing can regress yet")

    # Which products actually need re-running: only those with tests present.
    needed = {t.product for t in tests} & set(config.products)
    log(f"  {len(tests)} test(s) across {len(needed)} product(s): "
        f"{', '.join(sorted(needed))}")

    current: dict[str, dict[str, Severity]] = {}
    errors: dict[str, str] = {}
    for product in sorted(needed):
        log(f"  re-running {product}...")
        try:
            findings = _rerun_product(product, target, config, identities,
                                      log=log)
            current[product] = {f.fingerprint: f.severity for f in findings}
            log(f"    {len(findings)} finding(s) in the current scan")
        except Exception as exc:
            errors[product] = f"{type(exc).__name__}: {exc}"
            log(f"    FAILED to re-run: {exc}")

    results: list[CheckResult] = []
    skipped: list[tuple[str, str]] = []
    for test in tests:
        if test.product in errors:
            skipped.append((test.fingerprint, errors[test.product]))
            continue
        start = time.perf_counter()
        now_severity = current.get(test.product, {}).get(test.fingerprint)
        duration = time.perf_counter() - start

        if now_severity is None:
            if not test.armed:
                outcome = "pending"
                detail = ("not present, and this test has no recorded passing "
                          "run yet, so it is now armed and guarding this finding")
            else:
                outcome = "pass"
                detail = f"{test.title} stayed fixed"
        elif now_severity.rank < test.severity.rank:
            # Severity.rank is 0 for CRITICAL and 4 for INFO, so a SMALLER rank
            # is a MORE severe finding. Comparing with ">" here treated every
            # downgrade as an escalation and every escalation as a fix.
            outcome = "fail"
            detail = (f"{test.title} is present again in the current "
                      f"{test.product} scan, escalated to {now_severity.value}")
            if not test.armed:
                detail += " (test was still disarmed: the vulnerability has " \
                          "never been observed fixed)"
        elif now_severity.rank > test.severity.rank:
            # Downgraded, not gone. Treating this as a regression is wrong: a
            # scanner that reports escaped output at INFO has recorded a real
            # improvement, and a partial fix should not fail a build forever.
            outcome = "pass"
            detail = (f"{test.title} is still reported but downgraded from "
                       f"{test.severity.value} to {now_severity.value}; the "
                       f"exploitable form is gone")
        else:
            outcome = "fail"
            detail = (f"{test.title} is present again in the current "
                      f"{test.product} scan at the same severity")
            if not test.armed:
                # A disarmed test is tracking a vulnerability nobody has fixed
                # yet. Its continued presence is the expected state, not a
                # regression -- reporting it as one makes every suite run
                # "fail" from the moment it is created, which is how a gate
                # gets switched off.
                outcome = "pending"
                detail = (f"still present and unfixed, as expected for a "
                          f"test with no recorded passing run")

        if outcome == "fail" and test.is_flaky:
            outcome = "flaky"
            detail = "recent results alternate; this is an unreliable check, " \
                     "not a confirmed regression"

        results.append(CheckResult(test=test, outcome=outcome,
                                   detail=detail, duration_s=duration))

    duration = time.perf_counter() - started
    log(f"done in {duration:.1f}s: {len(results)} check(s), "
        f"{sum(1 for r in results if r.is_regression)} regression(s)")
    return RunResult(started_at=started_at, duration_s=duration,
                     baseline=baseline, results=results, skipped=skipped)


def _rerun_product(product: str, target: str, config: RunConfig,
                   identities=None, log=print) -> list[Finding]:
    """Re-run one product's engine against its target."""
    if product == "autopentest":
        from autopentest.engine import ScanConfig, scan
        return scan(target, authorized=True,
                    config=ScanConfig(rate_per_second=config.rate_per_second),
                    log=lambda *a: None).findings

    if product == "apishield":
        from apishield.engine import ANONYMOUS, ScanConfig, scan
        ids = identities or [ANONYMOUS]
        return scan(target, ids, authorized=True,
                    config=ScanConfig(rate_per_second=config.rate_per_second),
                    log=lambda *a: None).findings

    if product == "attackmap":
        from attackmap.engine import ScanConfig, Snapshot, diff_snapshots, \
            take_snapshot
        snapshot = take_snapshot(target, ScanConfig(use_ct=True, probe=False),
                                 log=lambda *a: None)
        # AttackMap findings describe *changes*, so a regression here means a
        # change recurred. Without the stored baseline we cannot tell, and that
        # is reported rather than assumed.
        from pathlib import Path
        baseline_file = Path("snapshots") / f"{target.replace('.', '_')}.json"
        previous = (Snapshot.from_json(baseline_file.read_text(encoding="utf-8"))
                    if baseline_file.exists() else None)
        from attackmap.engine import changes_to_findings
        return changes_to_findings(diff_snapshots(previous, snapshot), target)

    if product == "cloudpath":
        from cloudpath.engine import analyse
        return analyse(target, log=lambda *a: None).findings

    raise ValueError(f"no re-run strategy for product {product!r}")


def gate_run(run: RunResult, max_regressions: int = 0) -> tuple[bool, list[str]]:
    """
    CI gate.

    Disarmed (pending) tests do not fail the build -- they are tracking a
    vulnerability nobody has fixed yet, and failing CI on pre-existing debt
    trains people to ignore the gate.
    """
    regressions = [r for r in run.results if r.is_regression]
    flaky = [r for r in run.results if r.outcome == "flaky"]
    reasons = [f"[{r.test.severity.value}] {r.test.title} "
               f"({r.test.product} @ {r.test.location or r.test.target})"
               for r in regressions]
    reasons += [f"[flaky] {r.test.title} -- recent results alternate" for r in flaky]
    passed = len(regressions) <= max_regressions and not flaky
    return passed, reasons