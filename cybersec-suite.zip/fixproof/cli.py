#!/usr/bin/env python
"""
FixProof command line -- the CI entry point.

    # register tests from everything already scanned
    python -m fixproof.cli import

    # run the suite; exit 1 on any regression
    python -m fixproof.cli run http://localhost:8000

Designed for a pipeline: the exit code is the contract, and the output is
written to a JUnit-style XML file if asked, because most CI systems read that
rather than scraping stdout.
"""

from __future__ import annotations

import argparse
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.storage import Store  # noqa: E402
from fixproof.engine import (  # noqa: E402
    PRODUCT, ProofStore, RunConfig, gate_run, run_suite, tests_from_findings)

PRODUCTS = ("autopentest", "apishield", "attackmap", "cloudpath")

COLOURS = {
    "critical": "\033[41;97m", "high": "\033[43;30m", "medium": "\033[43;30m",
    "low": "\033[46;30m", "reset": "\033[0m", "dim": "\033[2m",
    "bold": "\033[1m", "red": "\033[91m", "green": "\033[92m",
}


def colour(text: str, name: str, on: bool) -> str:
    return f"{COLOURS.get(name,'')}{text}{COLOURS['reset']}" if on else text


def junit_xml(results, suite_name: str = "fixproof") -> str:
    """
    JUnit XML so CI dashboards show individual tests.

    Each regression test becomes a testcase. A test that failed is a failure,
    an unreliable one is an error -- deliberately distinct, because they mean
    different things and lumping them together loses that.
    """
    counts = {"pass": 0, "fail": 0, "flaky": 0, "pending": 0}
    for result in results:
        counts[result.outcome] = counts.get(result.outcome, 0) + 1

    suite = ET.Element("testsuite", {
        "name": suite_name,
        "tests": str(len(results)),
        "failures": str(counts.get("fail", 0)),
        "errors": str(counts.get("flaky", 0)),
        "skipped": str(counts.get("pending", 0)),
    })
    for result in results:
        case = ET.SubElement(suite, "testcase", {
            "name": f"{result.test.product}:{result.test.fingerprint[:8]}",
            "classname": result.test.product,
        })
        if result.outcome == "fail":
            failure = ET.SubElement(case, "failure", {
                "message": f"regression: {result.test.title}",
                "type": "SecurityRegression"})
            failure.text = result.detail
        elif result.outcome == "flaky":
            error = ET.SubElement(case, "error", {
                "message": "unreliable check", "type": "FlakyCheck"})
            error.text = result.detail
        elif result.outcome == "pending":
            ET.SubElement(case, "skipped", {"message": result.detail})
    return ET.tostring(suite, encoding="unicode")


def do_import(proofs: ProofStore, store: Store, product: str | None,
              target_locator: str | None, log) -> tuple[int, int]:
    total = armed = 0
    for target in store.list_targets():
        if target_locator and target["locator"] != target_locator:
            continue
        for name in (PRODUCTS if not product else [product]):
            findings = store.latest_findings(target["id"], name)
            if not findings:
                continue
            previous = store.previous_scan(target["id"], name)
            for test in tests_from_findings(
                    findings, name, target["locator"],
                    previous["id"] if previous else None):
                proofs.upsert(test)
                total += 1
                armed += int(test.armed)
            log(f"  {target['locator']} [{name}]: {len(findings)} finding(s)")
    return total, armed


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="fixproof")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--no-color", action="store_true",
                        help="disable ANSI colour")
    sub = parser.add_subparsers(dest="command", required=True)

    imp = sub.add_parser("import", parents=[common], help="turn recorded findings into tests")
    imp.add_argument("--product", choices=PRODUCTS, default=None)
    imp.add_argument("--target", default=None,
                     help="only import for this target locator")

    run = sub.add_parser("run", parents=[common], help="run the regression suite")
    run.add_argument("target")
    run.add_argument("--rate", type=float, default=10.0)
    run.add_argument("--max-regressions", type=int, default=0)
    run.add_argument("--junit", metavar="PATH",
                     help="write JUnit XML for CI dashboards")
    run.add_argument("--yes", action="store_true",
                     help="confirm authorization to re-scan the target")

    lst = sub.add_parser("list", parents=[common], help="show registered tests")

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--no-color", action="store_true",
                        help="disable ANSI colour")
    args = parser.parse_args(argv)
    colour_on = not args.no_color and sys.stdout.isatty()

    store = Store()
    proofs = ProofStore(store.path)

    if args.command == "import":
        print(colour("importing recorded findings as regression tests...",
                     "bold", colour_on))
        total, armed = do_import(proofs, store, args.product, args.target,
                                 lambda m: print(colour(m, "dim", colour_on)))
        print()
        print(f"  {total} test(s) registered, {armed} armed "
              f"(previously fixed findings guard immediately)")
        print("  disarmed tests arm themselves the first time their finding "
              "stops appearing")
        return 0

    if args.command == "list":
        for target in store.list_targets():
            tests = proofs.list_tests(target["locator"])
            if not tests:
                continue
            stats = proofs.stats(target["locator"])
            print()
            print(colour(f"  {target['locator']}", "bold", colour_on))
            print(f"    {stats['armed']} armed, {stats['failing']} failing, "
                  f"{stats['flaky']} unreliable, "
                  f"{stats['ever_regressed']} ever regressed")
            for test in tests:
                marker = {"pass": "PASS", "fail": "FAIL"}.get(
                    test.last_result, "....")
                print(f"    [{marker}] {test.severity.value:<8} "
                      f"{test.title[:64]}"
                      + (f"  (x{test.regression_count})"
                         if test.regression_count else ""))
        return 0

    # run
    if not args.yes:
        print(f"about to re-scan {args.target} to verify regression tests")
        print("re-run with --yes to confirm you are authorized")
        return 2

    target_row = store.find_target("web", args.target.rstrip("/"))
    if target_row is None:
        target_row = next((t for t in store.list_targets()
                           if t["locator"] == args.target), None)

    tests = proofs.list_tests(args.target)
    if not tests:
        print(f"no regression tests registered for {args.target}")
        print("run 'python -m fixproof.cli import' first")
        return 2

    print(colour(f"running {len(tests)} regression test(s) against "
                 f"{args.target}...", "bold", colour_on))
    result = run_suite(proofs, args.target,
                       RunConfig(rate_per_second=args.rate),
                       log=lambda m: print(colour(m, "dim", colour_on)))
    proofs.save_results(result, args.target)

    summary = result.summary()
    print()
    print(colour(f"  {summary['checked']} checked, {summary.get('pass', 0)} "
                 f"passed, {summary.get('pending', 0)} pending, "
                 f"{summary['regressions']} regressed, {summary['flaky']} "
                 f"unreliable", "bold", colour_on))

    if result.baseline:
        print()
        print(colour("  BASELINE: nothing has been observed fixed yet, so "
                     "nothing can regress. Fix something and re-import.",
                     "dim", colour_on))

    for item in result.results:
        if item.outcome == "fail":
            print(colour(f"  REGRESSED  {item.test.title}", "red", colour_on))
            print(f"            {colour(item.detail, 'dim', colour_on)}")
        elif item.outcome == "flaky":
            print(colour(f"  UNRELIABLE {item.test.title}", "high", colour_on))
            print(f"            recent: {item.test.recent_results[-4:]}")

    if result.skipped:
        print()
        print(colour(f"  {len(result.skipped)} test(s) could not be run -- "
                     f"their state is UNKNOWN, not passing:", "high",
                     colour_on))
        for _, reason in result.skipped[:2]:
            print(f"    {reason}")

    if args.junit:
        Path(args.junit).write_text(junit_xml(result.results, args.target),
                                    encoding="utf-8")
        print(f"  JUnit XML -> {args.junit}")

    passed, reasons = gate_run(result, args.max_regressions)
    print()
    if passed:
        print(colour("  PASS: no regressions", "green", colour_on))
        return 0
    print(colour(f"  FAIL: {len(reasons)} problem(s)", "red", colour_on))
    for reason in reasons[:10]:
        print(f"    - {reason}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())