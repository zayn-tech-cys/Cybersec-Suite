"""
FixProof web interface: register tests, run the suite, read regressions.

The central screen is deliberately not a dashboard of green ticks. It is a
ledger: which vulnerabilities were once fixed, which have come back, and how
many times each one has slipped.
"""

from __future__ import annotations

import html

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from core.auth import Role
from core.models import Severity
from core.report import report_html, report_json, report_pdf, severity_chart
from core.web import require_role_at

from .engine import (
    PRODUCT, CheckResult, ProofStore, RegressionTest, RunConfig, RunResult,
    gate_run, run_suite, tests_from_findings)

router = APIRouter()

# Most recent run per target, kept in memory for the results page.
LAST_RUNS: dict[str, RunResult] = {}
IDENTITIES = None      # populated by the caller when APIShield tests exist


def _proofs(request: Request) -> ProofStore:
    store = getattr(request.app.state, "_fixproof_store", None)
    if store is None:
        store = ProofStore(request.app.state.store.path)
        request.app.state._fixproof_store = store
    return store


def _e(value) -> str:
    return html.escape(str(value), quote=True)


@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    render = request.app.state.render
    proofs = _proofs(request)
    store = request.app.state.store

    rows = []
    for target in store.list_targets():
        tests = proofs.list_tests(target["locator"])
        if not tests:
            continue
        stats = proofs.stats(target["locator"])
        rows.append({"target": target, "stats": stats, "count": len(tests),
                     "tests": tests})

    totals = proofs.stats()
    return render(request, "fixproof_dashboard.html", "fixproof",
                  page="dashboard", rows=rows, totals=totals,
                  severity_counts=_severity_breakdown(
                      [t for row in rows for t in row["tests"]]),
                  chart=severity_chart(_severity_breakdown(
                      [t for row in rows for t in row["tests"]])))


def _severity_breakdown(tests: list[RegressionTest]) -> dict[str, int]:
    counts = {s.value: 0 for s in Severity}
    for test in tests:
        counts[test.severity.value] += 1
    return counts


@router.get("/target/{target_id}", response_class=HTMLResponse)
async def target_detail(request: Request, target_id: int):
    render = request.app.state.render
    store = request.app.state.store
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)

    proofs = _proofs(request)
    locator = target["locator"]
    tests = proofs.list_tests(locator)
    stats = proofs.stats(locator)
    history = proofs.run_history(locator)
    run = LAST_RUNS.get(locator)
    outcomes = {r.test.fingerprint: r for r in run.results} if run else {}

    counts = _severity_breakdown(tests)
    return render(request, "fixproof_target.html", "fixproof", page="target",
                  target=target, tests=tests, stats=stats, history=history,
                  outcomes=outcomes, run=run,
                  run_summary=run.summary() if run else None,
                  severity_counts=counts, chart=severity_chart(counts))


@router.get("/target/{target_id}/report", response_class=HTMLResponse)
async def report(request: Request, target_id: int, fmt: str = "html",
                 user=Depends(require_role_at(Role.VIEWER))):
    store = request.app.state.store
    target = store.get_target(target_id)
    proofs = _proofs(request)
    if target is None:
        return HTMLResponse("target not found", status_code=404)
    tests = proofs.list_tests(target["locator"])

    # Regression tests are findings, so the shared report renderer works.
    from core.models import Evidence, Finding

    def as_finding(t) -> "Finding":
        return Finding(
            title=t.title, severity=t.severity,
            category="Security regression test",
            target=t.target, location=t.location,
            detector=f"fixproof:{t.product}",
            description=t.notes,
            impact="this vulnerability was previously fixed; its return is a "
                   "regression",
            remediation="Re-apply the fix. Check the recorded history for when "
                        "it last passed.",
            tags=["regression"] if t.last_result == "fail" else [],
            evidence=Evidence(response=(
                f"last result: {t.last_result}\n"
                f"runs: {t.run_count}, failures: {t.fail_count}, "
                f"regressions: {t.regression_count}\n"
                f"recent: {', '.join(t.recent_results[-8:]) or 'none'}\n"
                f"armed: {t.armed}\n"
                f"first passed: {t.first_passed or 'never'}")),
            fingerprint=t.fingerprint)

    findings = [as_finding(t) for t in tests]
    meta = {"target": target["locator"], "product": "fixproof",
            "tests": len(tests), "armed": stats_of(proofs, target["locator"])}

    if fmt == "pdf":
        pdf = report_pdf(findings, target["locator"], PRODUCT, meta)
        safe_product = "".join(c for c in PRODUCT.lower() if c.isalnum() or c in "-_") or "security"
        return Response(pdf, media_type="application/pdf", headers={
            "Content-Disposition": f'attachment; filename="{safe_product}-report-{target_id}.pdf"',
            "X-Content-Type-Options": "nosniff",
        })
    if fmt == "json":
        return HTMLResponse(
            report_json(findings, target["locator"], "fixproof", meta),
            media_type="application/json")
    return HTMLResponse(
        report_html(findings, target["locator"], "fixproof", meta,
                    title="FixProof Regression Report"))


def stats_of(proofs: ProofStore, locator: str) -> int:
    return proofs.stats(locator)["armed"]


# -- registering tests ---------------------------------------------------

@router.post("/import/{target_id}")
async def import_tests(request: Request, target_id: int,
                       products: str = Form("autopentest,apishield"),
                       user=Depends(require_role_at(Role.ANALYST))):
    """
    Lift every recorded finding from the other products into regression tests.

    This is the whole onboarding step: point FixProof at a target that has
    already been scanned and it picks up the history that already exists.
    """
    store = request.app.state.store
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)

    proofs = _proofs(request)
    wanted = [p.strip() for p in products.split(",") if p.strip()]
    created = 0
    armed = 0

    for product in wanted:
        findings = store.latest_findings(target_id, product)
        previous = store.previous_scan(target_id, product)
        origin = previous["id"] if previous else None
        tests = tests_from_findings(findings, product, target["locator"],
                                    origin)
        for test in tests:
            proofs.upsert(test)
            created += 1
            if test.armed:
                armed += 1

    request.app.state.auth.audit(
        user.username, "fixproof.import",
        f"target={target_id} tests={created} armed={armed}")
    return RedirectResponse(f"/fixproof/target/{target_id}", status_code=303)


@router.post("/import-all")
async def import_all(request: Request,
                     user=Depends(require_role_at(Role.ANALYST))):
    """Import from every target that already has recorded findings."""
    store = request.app.state.store
    proofs = _proofs(request)
    total = armed = 0
    for target in store.list_targets():
        for product in ("autopentest", "apishield", "attackmap", "cloudpath"):
            findings = store.latest_findings(target["id"], product)
            if not findings:
                continue
            previous = store.previous_scan(target["id"], product)
            for test in tests_from_findings(
                    findings, product, target["locator"],
                    previous["id"] if previous else None):
                proofs.upsert(test)
                total += 1
                armed += int(test.armed)
    return HTMLResponse(
        f"<h1>Imported</h1><p>{total} test(s) registered, {armed} already "
        f"armed from previously fixed findings.</p>"
        f"<p><a class='btn' href='/fixproof/'>back</a></p>")


# -- running the suite ---------------------------------------------------

@router.post("/run/{target_id}")
async def run(request: Request, target_id: int,
              user=Depends(require_role_at(Role.ANALYST))):
    store = request.app.state.store
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)

    proofs = _proofs(request)
    locator = target["locator"]
    if not proofs.list_tests(locator):
        return HTMLResponse(
            "<h1>No regression tests</h1>"
            "<p>This target has no recorded findings to turn into tests. Run a "
            "scan with AutoPentest or APIShield first, then import here.</p>"
            f"<p><a class='btn' href='/fixproof/target/{target_id}'>back</a></p>",
            status_code=400)

    try:
        result = run_suite(proofs, locator, RunConfig(rate_per_second=10.0),
                           identities=IDENTITIES, log=lambda *a: None)
    except Exception as exc:
        return HTMLResponse(f"<h1>Suite run failed</h1><p>{_e(exc)}</p>"
                            f"<p><a class='btn' href='/fixproof/target/{target_id}'>"
                            f"back</a></p>", status_code=500)

    proofs.save_results(result, locator)
    LAST_RUNS[locator] = result
    passed, reasons = gate_run(result)
    request.app.state.auth.audit(
        user.username, "fixproof.run",
        f"target={target_id} regressions={len(reasons)}")
    return RedirectResponse(
        f"/fixproof/target/{target_id}?gate={'pass' if passed else 'fail'}",
        status_code=303)


# -- JSON API ------------------------------------------------------------

@router.get("/api/targets")
async def api_targets(request: Request):
    store = request.app.state.store
    proofs = _proofs(request)
    out = []
    for target in store.list_targets():
        tests = proofs.list_tests(target["locator"])
        if tests:
            out.append({"id": target["id"], "target": target["locator"],
                        "stats": proofs.stats(target["locator"])})
    return {"targets": out, "totals": proofs.stats()}


@router.get("/api/targets/{target_id}/tests")
async def api_tests(request: Request, target_id: int):
    store = request.app.state.store
    target = store.get_target(target_id)
    if target is None:
        return {"error": "target not found"}
    proofs = _proofs(request)
    tests = proofs.list_tests(target["locator"])
    return {"target": target["locator"],
            "stats": proofs.stats(target["locator"]),
            "tests": [{**t.to_dict(),
                       "severity": t.severity.value,
                       "flaky": t.is_flaky,
                       "stability": t.stability} for t in tests]}


@router.post("/api/targets/{target_id}/import")
async def api_import(request: Request, target_id: int,
                     product: str = "autopentest",
                     user=Depends(require_role_at(Role.ANALYST))):
    store = request.app.state.store
    target = store.get_target(target_id)
    if target is None:
        return {"error": "target not found"}
    proofs = _proofs(request)
    findings = store.latest_findings(target_id, product)
    if not findings:
        return {"error": f"no {product} findings recorded for this target"}
    previous = store.previous_scan(target_id, product)
    tests = tests_from_findings(findings, product, target["locator"],
                                previous["id"] if previous else None)
    for test in tests:
        proofs.upsert(test)
    return {"imported": len(tests),
            "armed": sum(1 for t in tests if t.armed),
            "stats": proofs.stats(target["locator"])}


@router.post("/api/targets/{target_id}/run")
async def api_run(request: Request, target_id: int,
                  user=Depends(require_role_at(Role.ANALYST))):
    """
    CI entry point. Exits non-zero semantics are expressed in the JSON because
    the CLI is the thing wired into a pipeline.
    """
    store = request.app.state.store
    target = store.get_target(target_id)
    if target is None:
        return {"error": "target not found"}
    proofs = _proofs(request)
    locator = target["locator"]
    if not proofs.list_tests(locator):
        return {"error": "no regression tests registered; import first"}

    result = run_suite(proofs, locator, RunConfig(rate_per_second=10.0),
                       identities=IDENTITIES, log=lambda *a: None)
    proofs.save_results(result, locator)
    LAST_RUNS[locator] = result
    passed, reasons = gate_run(result)
    return {
        "passed": passed,
        "baseline": result.baseline,
        "summary": result.summary(),
        "regressions": [{"title": r.test.title, "severity": r.test.severity.value,
                         "product": r.test.product, "location": r.test.location,
                         "regression_count": r.test.regression_count}
                        for r in result.results if r.is_regression],
        "flaky": [{"title": r.test.title,
                   "recent": r.test.recent_results[-4:]}
                  for r in result.results if r.outcome == "flaky"],
        "skipped": [{"fingerprint": fp, "reason": why}
                    for fp, why in result.skipped],
    }