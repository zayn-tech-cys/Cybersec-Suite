# CyberSec Suite

**A local-first cybersecurity assessment workspace with five focused tools, role-based accounts, unified findings, and regression tracking.**

CyberSec Suite is designed for university labs, authorized internal assessments, and security-engineering demonstrations. It is not a substitute for a professional penetration test or a production SaaS security platform.

## Modules

| Module | Purpose | Main capabilities |
|---|---|---|
| **AutoPentest** | Web application testing | Same-origin crawling, security-header checks, reflected input, SQL injection and path-traversal checks with evidence-based confirmation |
| **APIShield** | REST API authorization checks | Tests for broken object-level and function-level authorization using operator-supplied identities |
| **AttackMap** | Attack-surface change monitoring | Scoped port probing, service/banner observations, certificate-transparency discovery and snapshot diffs |
| **CloudPath** | Infrastructure-as-code review | Analyzes Terraform, Kubernetes and Docker Compose configuration for risky settings and possible attack paths |
| **FixProof** | Security regression testing | Converts recorded findings into checks and reruns relevant engines to spot recurring issues |

The five tools share a common finding model, risk prioritization, SQLite storage, audit trail, login system, report renderer, and target-scope enforcement.

## What's improved in this version

- Refreshed responsive dark dashboard and clearer module status indicators.
- **PDF report downloads** alongside HTML and JSON exports for all five tools. Reports include a summary, severity counts, findings, remediation advice, and selected evidence.
- **User administration page** at `/admin/users`, available to admins, to create viewer, analyst, and admin accounts.
- Login throttling for repeated attempts from the same source address, plus security response headers.
- Disabled accounts are rejected even when they still possess a previously issued signed cookie.
- Configurable persistent data directory via `SUITE_DATA_DIR`.
- Docker image and Compose setup, non-root container user, dropped Linux capabilities, read-only root filesystem, persistent data volume, and loopback-only host port by default.
- Added regression tests for PDF output, login throttling, security headers, disabled accounts, and admin-only access.

## Quick start (Windows, macOS, or Linux)

Use Python 3.12 or newer. In a terminal opened in the project directory:

```bash
python -m venv .venv
```

Activate the environment:

```powershell
# Windows PowerShell
.venv\Scripts\Activate.ps1
```

```bash
# macOS / Linux
source .venv/bin/activate
```

Install dependencies and start the server:

```bash
python -m pip install -r requirements.txt
python server.py --bootstrap-admin
```

Open **http://127.0.0.1:8000**. On first run, the terminal prints a generated `admin` password once; save it in a password manager. If an admin account already exists, the bootstrap command does not reset its password.

To start the deliberately vulnerable practice lab, open a second terminal and run:

```bash
python lab/app.py
```

The lab binds to `127.0.0.1:8000` by default; change one of the ports if it conflicts with the suite server. Never expose the intentionally vulnerable lab to a public or untrusted network.

### Windows shortcut

The included `run.cmd` is available as a Windows launcher. If dependency installation or launch fails, follow the explicit commands above so the error is visible.

## Docker deployment

Docker Compose publishes the application on `127.0.0.1:8001` by default, keeping it off public network interfaces:

```bash
docker compose up --build -d
docker compose logs -f cybersec-suite
```

The first startup prints the generated admin password in the container logs. Read and save it:

```bash
docker compose logs cybersec-suite
```

Open **http://127.0.0.1:8001**. The named `cybersec-data` volume persists SQLite databases and the session-signing secret across restarts. Back up that volume securely. Stop the service with `docker compose down`; this preserves the volume. To intentionally remove persistent data as well, `docker compose down -v` deletes it.

For HTTPS behind a trusted reverse proxy, configure TLS at the proxy and set `SUITE_COOKIE_SECURE=1`. Do not publish the app directly to the internet without a proper identity-aware proxy, CSRF protection, centralized rate limiting, secure secret management, and deployment-specific security review.

### Configuration

| Variable | Default | Purpose |
|---|---|---|
| `SUITE_DATA_DIR` | `./data` beside `server.py` | Location for SQLite databases and signing secret |
| `SUITE_COOKIE_SECURE` | `0` | Set to `1` when requests use HTTPS; enables the cookie `Secure` flag |

Copy `.env.example` as a reference. The Python server does not automatically load `.env`; export variables in your shell or configure them in Docker Compose/systemd.

## Roles and accounts

- **Viewer** — read dashboards and reports; cannot start scans.
- **Analyst** — run scans and manage targets.
- **Admin** — analyst permissions plus account creation and administration.

Create accounts from **Users** in the top navigation while signed in as an admin. Use individual accounts and grant the least privilege needed. Passwords are stored as PBKDF2-HMAC-SHA256 hashes; the session cookie is HTTP-only and SameSite=Lax. The built-in login throttle is per-process and per-source address, so it is not a substitute for a shared limiter in a multi-worker deployment.

## Report downloads

Open a target page and choose **HTML report**, **JSON**, or **Download PDF**. PDF files are generated locally and do not require a third-party service. Findings include risk prioritization, but the risk score is an internal triage value, not an official CVSS calculation. Review evidence and verify findings before making decisions.

## CLI examples

```bash
# AutoPentest (authorized web app)
python -m autopentest.cli http://127.0.0.1:8000 --yes --fail-on high
python -m autopentest.cli http://127.0.0.1:8000 --yes --json report.json --html report.html

# APIShield (identities are supplied by the operator)
python -m apishield.cli http://127.0.0.1:8000 --yes \
  --identity alice:1:user:1 --identity bob:2:user:1 --identity root:9:admin:3

# AttackMap (explicit port scope is required)
python -m attackmap.cli example.com --show-graph

# CloudPath (local infrastructure configuration files)
python -m cloudpath.cli ./infra --show-graph

# FixProof
python -m fixproof.cli import
python -m fixproof.cli run http://127.0.0.1:8000 --yes --junit results.xml
```

Each command's `--help` output documents its options. Scan only assets you own or have explicit permission to assess. APIShield's mass-assignment probes may write sentinel values unless `--no-writes` is selected; prefer staging environments.

## Tests

```bash
python -m pytest tests/ -q
python tests/demo_fixproof_cycle.py
```

The suite includes vulnerable targets and negative controls based on correctly secured examples. Passing tests indicate expected behavior for those test cases, not complete vulnerability coverage or production certification.

## Security boundaries and known limitations

- Network access from web scanners is centralized in `core/httpclient.py`, which checks target authorization and redirect scope. AttackMap requires explicit port scope, and scan rates are limited.
- The lab intentionally contains vulnerable routes. Keep it loopback-only.
- Scans are synchronous; long-running scans can occupy a worker. There is no job queue, live progress stream, or cancellation system.
- SQLite is intended for a local/small-team install. There is no SaaS multi-tenancy, billing, or organization isolation.
- Sessions are signed cookies with a 12-hour lifetime. Disabled accounts are rejected, but logout clears the browser cookie rather than revoking a stolen token immediately. Use an identity-aware proxy and centralized session management for shared deployments.
- Login throttling is in-memory per process; it resets on restart and is not shared across workers. There is no MFA, password-reset workflow, or external identity provider.
- AutoPentest does not use a real browser and therefore does not cover DOM-based XSS or complex authenticated flows. It is depth-limited and same-origin.
- APIShield does not handle OAuth token acquisition, GraphQL, WebSockets, or request signing. BOLA probes inspect a bounded number of object identifiers.
- AttackMap does not perform UDP sweeps or subdomain brute force. Web UI snapshots are in memory; CLI snapshots can be persisted. Certificate-transparency discovery needs network access.
- CloudPath uses a purpose-built Terraform scanner rather than a full HCL parser, does not query live cloud APIs, and caps attack-path enumeration. Unsupported syntax is not proof of safety.
- FixProof reruns relevant checks and can be slow. Flakiness detection is heuristic; disarmed checks can remain pending until explicitly rearmed.

## Repository layout

```text
core/            Shared auth, storage, risk, reports, HTTP client, UI shell
lab/             Deliberately vulnerable local practice target
autopentest/      Web application scanner
apishield/        REST API authorization tester
attackmap/        Attack surface change monitor
cloudpath/        Infrastructure-as-code analyzer and sample configs
fixproof/         Regression test lifecycle
core/templates/   Dashboard, target, login, and admin templates
tests/            Engine tests and upgrade regression tests
server.py         Unified application entry point
Dockerfile        Container image
compose.yaml      Local-first Compose deployment
```

## Disclaimer

CyberSec Suite is provided for education, research, and authorized security testing. You are responsible for obtaining written permission, defining scope, and complying with applicable laws and policies.
