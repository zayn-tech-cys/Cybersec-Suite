"""
APIShield tests.

Same structure as the AutoPentest tests and for the same reason: most of the
value is in the **negative controls**. Authorization testing is unusually prone
to false positives -- "a user could read this" is true of almost every endpoint
in existence -- and this suite contains a correctly-secured twin of the lab so
that a scanner which flags everything fails here.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from apishield.engine import (  # noqa: E402
    ANONYMOUS, Endpoint, Identity, ScanConfig, _candidate_ids, _is_privileged_endpoint,
    _object_owner, _should_require_auth, check_bfla, check_bfla as _bfla,
    check_bola, check_excessive_exposure, check_mass_assignment,
    check_method_confusion, check_unbounded_collection, load_openapi,
    parse_openapi, sample_objects, scan)
from core.httpclient import Exchange, RateLimiter, SafeClient, Scope  # noqa: E402


# -- fixtures ------------------------------------------------------------

@pytest.fixture(scope="module")
def server():
    """Vulnerable lab plus a correctly-secured twin, each on a real socket."""
    import socket
    import threading
    import time
    import uvicorn

    tmp = Path(__file__).parent / "_apishield_tmp"
    tmp.mkdir(exist_ok=True)

    import lab.app as lab_app
    lab_app.DB_PATH = str(tmp / "lab.db")
    lab_app.init_db()

    secure = FastAPI()

    # Ownership is enforced: /api/orders/{id} only returns your own orders.
    ORDERS = {1001: "alice", 1002: "bob", 1003: "alice"}
    USERS = {"1": "alice", "2": "bob", "9": "root"}

    def caller(request: Request) -> str:
        uid = request.headers.get("x-user-id")
        return USERS.get(uid or "", "")

    @secure.get("/api/orders/{order_id}")
    async def get_order(order_id: int, request: Request):
        me = caller(request)
        if not me:
            return JSONResponse({"error": "unauthenticated"}, status_code=401)
        if ORDERS.get(order_id) != me:
            # 404 rather than 403: do not confirm the object exists.
            return JSONResponse({"error": "not found"}, status_code=404)
        return JSONResponse({"id": order_id, "owner": me, "item": "thing"})

    @secure.get("/api/users/{user_id}")
    async def get_user(user_id: int, request: Request):
        me = caller(request)
        if not me:
            return JSONResponse({"error": "unauthenticated"}, status_code=401)
        if user_id == 9 and me != "root":
            return JSONResponse({"error": "forbidden"}, status_code=403)
        if me != USERS.get(str(user_id), ""):
            return JSONResponse({"error": "not found"}, status_code=404)
        # No internal_note: nothing extra is exposed.
        return JSONResponse({"id": user_id, "username": me})

    @secure.patch("/api/users/{user_id}")
    async def patch_user(user_id: int, request: Request):
        me = caller(request)
        if not me:
            return JSONResponse({"error": "unauthenticated"}, status_code=401)
        if me != USERS.get(str(user_id), ""):
            return JSONResponse({"error": "not found"}, status_code=404)
        body = await request.json()
        # Allow-list: unknown fields are rejected, not stored.
        allowed = {"email"}
        if set(body) - allowed:
            return JSONResponse({"error": "unknown fields"}, status_code=400)
        return JSONResponse({"id": user_id, "username": me,
                             "email": body.get("email", "")})

    @secure.get("/api/admin")
    async def admin(request: Request):
        if caller(request) != "root":
            return JSONResponse({"error": "forbidden"}, status_code=403)
        return JSONResponse({"admin": True})

    @secure.api_route("/api/admin", methods=["POST", "DELETE"])
    async def admin_write(request: Request):
        if caller(request) != "root":
            return JSONResponse({"error": "forbidden"}, status_code=403)
        return JSONResponse({"ok": True})

    @secure.get("/api/orders")
    async def list_orders(request: Request):
        me = caller(request)
        if not me:
            return JSONResponse({"error": "unauthenticated"}, status_code=401)
        mine = [{"id": k, "owner": v} for k, v in ORDERS.items() if v == me]
        # Paginated: a limit is enforced.
        return JSONResponse({"items": mine[:20], "limit": 20, "total": len(mine)})

    @secure.get("/")
    async def index():
        from fastapi.responses import HTMLResponse
        return HTMLResponse("<html><body>public page</body></html>")

    def serve(app_obj):
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        config = uvicorn.Config(app_obj, log_level="error", lifespan="on")
        instance = uvicorn.Server(config)
        thread = threading.Thread(
            target=instance.run, kwargs={"sockets": [sock]}, daemon=True)
        thread.start()
        deadline = time.monotonic() + 10
        while not instance.started and time.monotonic() < deadline:
            if not thread.is_alive():
                raise RuntimeError("server exited during startup")
            time.sleep(0.02)
        if not instance.started:
            raise RuntimeError("server did not start")
        return f"http://127.0.0.1:{port}", instance, thread

    vuln_url, vuln_server, vuln_thread = serve(lab_app.app)
    sec_url, sec_server, sec_thread = serve(secure)
    yield {"vulnerable": vuln_url, "secure": sec_url}
    for instance, thread in ((vuln_server, vuln_thread), (sec_server, sec_thread)):
        instance.should_exit = True
        thread.join(timeout=10)


@pytest.fixture(scope="module")
def identities():
    return [
        Identity("alice", {"x-user-id": "1"}, role="user", privilege=1),
        Identity("bob", {"x-user-id": "2"}, role="user", privilege=1),
        Identity("root", {"x-user-id": "9"}, role="admin", privilege=3),
    ]


@pytest.fixture(scope="module")
def vuln_scan(server, identities):
    return scan(server["vulnerable"], identities, authorized=True,
                config=ScanConfig(rate_per_second=60), log=lambda *a: None)


@pytest.fixture(scope="module")
def secure_scan(server, identities):
    return scan(server["secure"], identities, authorized=True,
                config=ScanConfig(rate_per_second=60), log=lambda *a: None)


def detectors(scan_result, name):
    return [f for f in scan_result.findings if f.detector == name]


# -- spec parsing --------------------------------------------------------

def test_parse_openapi_extracts_methods_and_path_params():
    document = {
        "paths": {
            "/users/{id}": {
                "get": {"summary": "Get a user"},
                "patch": {"summary": "Update a user"},
            },
            "/health": {"get": {}},
        }
    }
    endpoints = parse_openapi(document)
    keys = {e.key() for e in endpoints}
    assert keys == {"GET /users/{id}", "PATCH /users/{id}", "GET /health"}


def test_endpoint_concrete_fills_path_parameters():
    endpoint = Endpoint("GET", "/api/orders/{order_id}",
                        parameters={"order_id": "7"})
    assert endpoint.concrete("http://h").endswith("/api/orders/7")


def test_endpoint_concrete_substitutes_unfilled_params():
    """An unfilled {id} would 404 and teach us nothing."""
    endpoint = Endpoint("GET", "/a/{x}/b/{y}")
    url = endpoint.concrete("http://h", {"x": "1"})
    assert url.endswith("/a/1/b/1")


def test_required_role_inferred_from_admin_naming():
    document = {"paths": {
        "/admin/wipe": {"delete": {"summary": "wipe everything"}},
        "/orders": {"get": {"summary": "list orders"}}}}
    endpoints = {e.key(): e for e in parse_openapi(document)}
    assert endpoints["DELETE /admin/wipe"].required_role == "admin"
    assert endpoints["GET /orders"].required_role == "user"


# -- the bugs that produced false positives ------------------------------

def test_public_page_is_not_privileged():
    """BFLA must never consider a public page administrative.

    Comparing "admin gets 200" against "user gets 200" on an endpoint that
    ignores credentials flagged /, /search and /download as critical privilege
    escalations. On a public page both identities necessarily succeed.
    """
    for path in ("/", "/search", "/download", "/health", "/api/orders"):
        if path == "/api/orders":
            continue        # an API collection, handled separately
        assert not _is_privileged_endpoint(
            Endpoint("GET", path)), f"{path} treated as privileged"


def test_admin_path_is_privileged():
    assert _is_privileged_endpoint(Endpoint("GET", "/api/admin"))
    assert _is_privileged_endpoint(Endpoint("POST", "/admin/users"))
    assert _is_privileged_endpoint(
        Endpoint("DELETE", "/api/admin", required_role="admin"))


def test_public_paths_not_expected_to_require_auth():
    for path in ("/login", "/health", "/", "/docs", "/openapi.json"):
        assert not _should_require_auth(Endpoint("GET", path)), path


def test_non_api_paths_not_expected_to_require_auth():
    """A public web page returning 200 to everyone is not a finding."""
    for path in ("/", "/search", "/download", "/about"):
        assert not _should_require_auth(Endpoint("GET", path)), path


def test_api_data_paths_expected_to_require_auth():
    for path in ("/api/users/{id}", "/api/orders", "/api/admin",
                 "/api/account/settings", "/api/invoices"):
        assert _should_require_auth(Endpoint("GET", path)), path


def test_bola_skips_endpoints_without_path_parameters():
    """/api/me has no object id, so it cannot be a BOLA target."""
    with pytest.MonkeyPatch.context():
        endpoint = Endpoint("GET", "/api/me")
        assert endpoint.path_params == []


def test_candidate_ids_do_not_reuse_ids_from_another_collection():
    """
    Order ids are 1001..1004; user ids are 1,2,9. Falling through to
    __any__ probed user_id=1001, got 404, and the endpoint read as clean --
    a missed BOLA reported as a pass.
    """
    samples = {"__any__": ["1001", "1002"], "id": ["1001"], "order_id": ["1001"]}
    assert _candidate_ids("order_id", samples) == ["1001"]
    user_ids = _candidate_ids("user_id", samples)
    assert "1001" not in user_ids[:3]
    assert "1" in user_ids


def test_object_owner_matches_known_identity_only():
    ids = [Identity("alice", {"x-user-id": "1"}),
           Identity("bob", {"x-user-id": "2"})]
    assert _object_owner('{"owner": "bob"}', ids) == "bob"
    assert _object_owner('{"owner": "carol"}', ids) is None
    assert _object_owner('{"username": "alice"}', ids) == "alice"


def test_object_owner_handles_nested_payload():
    ids = [Identity("alice", {}), Identity("bob", {})]
    assert _object_owner('{"data": {"owner": "alice"}}', ids) == "alice"


# -- detection on the vulnerable lab ------------------------------------

def test_detects_bola_on_orders(vuln_scan):
    findings = detectors(vuln_scan, "bola")
    assert findings, "the lab's /api/orders/{id} has no ownership check"
    orders = [f for f in findings if "orders" in f.location]
    assert orders
    assert orders[0].evidence.extra["proof"] == "ownership-mismatch"


def test_detects_bola_on_users(vuln_scan):
    users = [f for f in detectors(vuln_scan, "bola") if "users" in f.location]
    assert users, "the lab's /api/users/{id} returns any user's record"


def test_bola_merges_into_one_finding_per_endpoint(vuln_scan):
    """Three exposed ids are one broken endpoint, not three criticals."""
    for finding in detectors(vuln_scan, "bola"):
        assert finding.metadata["affected_ids"], finding.title


def test_detects_bfla_on_admin(vuln_scan):
    findings = [f for f in detectors(vuln_scan, "bfla") if "admin" in f.location]
    assert findings
    assert findings[0].severity.value == "critical"


def test_no_bfla_on_non_admin_endpoints(vuln_scan):
    for finding in detectors(vuln_scan, "bfla"):
        assert "admin" in finding.location or _is_privileged_endpoint(
            Endpoint("GET", finding.location))


def test_detects_mass_assignment(vuln_scan):
    findings = detectors(vuln_scan, "mass_assignment")
    assert findings
    assert findings[0].severity.value == "high"


def test_detects_excessive_exposure(vuln_scan):
    findings = detectors(vuln_scan, "exposure")
    assert findings
    assert any("internal_note" in " ".join(f.evidence.extra["leaked_fields"])
               for f in findings)


def test_detects_cors_with_credentials(vuln_scan):
    findings = detectors(vuln_scan, "cors")
    assert findings, "the lab reflects any origin with credentials allowed"
    assert findings[0].evidence.extra["allow_credentials"] == "true"


def test_detects_method_confusion(vuln_scan):
    findings = detectors(vuln_scan, "methods")
    assert findings
    assert "DELETE" in findings[0].title


def test_detects_unauthenticated_admin_access(vuln_scan):
    findings = [f for f in detectors(vuln_scan, "no_auth")
                if "admin" in f.location]
    assert findings


def test_no_missing_auth_on_public_pages(vuln_scan):
    for finding in detectors(vuln_scan, "no_auth"):
        assert finding.location.startswith("/api/"), \
            f"missing-auth reported on non-API path {finding.location}"


# -- negative controls: secure twin --------------------------------------

def test_secure_api_has_no_bola(secure_scan):
    assert detectors(secure_scan, "bola") == [], \
        "false BOLA: " + ", ".join(f.title for f in detectors(secure_scan, "bola"))


def test_secure_api_has_no_bfla(secure_scan):
    assert detectors(secure_scan, "bfla") == [], \
        "false BFLA: " + ", ".join(f.title for f in detectors(secure_scan, "bfla"))


def test_secure_api_has_no_mass_assignment(secure_scan):
    assert detectors(secure_scan, "mass_assignment") == [], \
        "false mass assignment: " + ", ".join(
            f.title for f in detectors(secure_scan, "mass_assignment"))


def test_secure_api_has_no_excessive_exposure(secure_scan):
    assert detectors(secure_scan, "exposure") == [], \
        "false exposure: " + ", ".join(
            f.title for f in detectors(secure_scan, "exposure"))


def test_secure_api_reports_nothing_medium_or_worse(secure_scan):
    from core.risk import prioritise
    scored = prioritise(secure_scan.findings)
    serious = [s for s in scored if s.severity.rank <= 2]
    assert not serious, "false positives: " + ", ".join(
        s.finding.title for s in serious)


# -- coverage honesty ----------------------------------------------------

def test_single_identity_run_reports_bola_not_evaluated(server):
    result = scan(server["vulnerable"],
                  [Identity("alice", {"x-user-id": "1"}, privilege=1)],
                  authorized=True, config=ScanConfig(rate_per_second=60),
                  log=lambda *a: None)
    assert "not evaluated" in result.coverage
    assert "2+ authenticated identities" in result.coverage


def test_anonymous_only_run_warns(server):
    result = scan(server["vulnerable"], [ANONYMOUS], authorized=True,
                  config=ScanConfig(rate_per_second=60), log=lambda *a: None)
    assert result.coverage


def test_every_finding_has_evidence(vuln_scan):
    for finding in vuln_scan.findings:
        assert finding.evidence.request or finding.evidence.response, \
            f"{finding.detector} produced a finding with no evidence"


# -- unit tests for individual checks ------------------------------------

def test_unbounded_collection_respects_threshold():
    def body(n):
        return json.dumps({"items": [{"id": i} for i in range(n)]})

    endpoint = Endpoint("GET", "/api/things")
    assert check_unbounded_collection(
        Exchange("GET", "http://h/api/things", status_code=200,
                 response_text=body(5)), endpoint, "http://h") == []
    findings = check_unbounded_collection(
        Exchange("GET", "http://h/api/things", status_code=200,
                 response_text=body(500)), endpoint, "http://h")
    assert len(findings) == 1
    assert "500" in findings[0].title


def test_exposure_ignores_bodies_that_are_not_json():
    endpoint = Endpoint("GET", "/api/things")
    assert check_excessive_exposure(
        Exchange("GET", "http://h", status_code=200, response_text="<html>"),
        endpoint, "http://h") == []


def test_bfla_requires_both_an_admin_and_a_non_admin(server):
    only_users = [Identity("alice", {"x-user-id": "1"}, privilege=1),
                  Identity("bob", {"x-user-id": "2"}, privilege=1)]
    with SafeClient(Scope(server["vulnerable"], authorized=True),
                    rate=RateLimiter(60)) as client:
        assert check_bfla(client, Endpoint("GET", "/api/admin"),
                          server["vulnerable"], only_users) == []


def test_bola_requires_two_identities(server):
    single = [Identity("alice", {"x-user-id": "1"}, privilege=1)]
    with SafeClient(Scope(server["vulnerable"], authorized=True),
                    rate=RateLimiter(60)) as client:
        assert check_bola(client, Endpoint("GET", "/api/orders/{order_id}"),
                          server["vulnerable"], single,
                          {"order_id": ["1001"]}) == []


def test_method_confusion_ignores_endpoints_that_already_accept_writes():
    """A DELETE-able resource is not confused about which verbs it accepts."""
    from fastapi import FastAPI as _F, Request as _R
    from fastapi.responses import JSONResponse as _J
    app = _F()

    @app.api_route("/api/doc/{id}", methods=["DELETE"])
    async def remove(id: int, request: _R):
        return _J({"deleted": True})

    import socket
    import threading
    import time
    import uvicorn
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    instance = uvicorn.Server(
        uvicorn.Config(app, log_level="error", lifespan="on"))
    thread = threading.Thread(target=instance.run, kwargs={"sockets": [sock]},
                              daemon=True)
    thread.start()
    deadline = time.monotonic() + 10
    while not instance.started and time.monotonic() < deadline:
        time.sleep(0.02)
    try:
        base = f"http://127.0.0.1:{port}"
        with SafeClient(Scope(base, authorized=True), rate=RateLimiter(60)) as c:
            assert check_method_confusion(c, Endpoint("DELETE", "/api/doc/{id}"),
                                          base) == []
    finally:
        instance.should_exit = True
        thread.join(timeout=10)


def test_sample_objects_indexes_several_ways(server):
    with SafeClient(Scope(server["vulnerable"], authorized=True),
                    rate=RateLimiter(60)) as client:
        samples = sample_objects(client, server["vulnerable"], [])
    assert "__any__" in samples
    assert "order_id" in samples, "singular of the collection must be indexed"
    assert samples["order_id"]