"""
CloudPath tests.

Two halves:

* **Detection** against the bundled vulnerable sample, which must find every
  deliberately planted misconfiguration and, critically, must trace the
  multi-hop paths -- a config linter that finds the open security group but
  does not connect it to the database behind it has missed the actual problem.
* **Negative control** against the hardened sample, which must come back clean.
  Cloud configuration rules are full of "absent means vulnerable" mistakes, and
  without this half the suite would be self-congratulating.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cloudpath.engine import (  # noqa: E402
    RULES_BY_ID, Asset, Relation, ScanConfig, _is_open_cidr, _split_refs,
    _terraform_kind, analyse, build_graph, evaluate_assets,
    find_attack_paths, load_directory, normalise_reference, parse_file,
    paths_to_findings)
from core.models import Severity  # noqa: E402

SAMPLES = Path(__file__).resolve().parents[1] / "cloudpath" / "samples"
VULNERABLE = SAMPLES / "vulnerable"
HARDENED = SAMPLES / "hardened"


@pytest.fixture(scope="module")
def vuln():
    return analyse(VULNERABLE, log=lambda *a: None)


@pytest.fixture(scope="module")
def hardened():
    return analyse(HARDENED, log=lambda *a: None)


def rules_fired(result):
    return {f.detector.replace("cloudpath:", "") for f in result.findings}


# -- detection on the vulnerable sample ---------------------------------

def test_parses_all_three_file_types(vuln):
    providers = {a.provider for a in vuln.assets}
    assert "aws" in providers, "terraform was not parsed"
    assert "kubernetes" in providers, "k8s yaml was not parsed"
    assert "docker-compose" in providers, "compose was not parsed"


def test_finds_open_security_group(vuln):
    assert "SG_INGRESS_OPEN" in rules_fired(vuln)


def test_finds_public_bucket(vuln):
    findings = [f for f in vuln.findings if f.detector.endswith("S3_PUBLIC")]
    assert findings
    assert any("public_assets" in f.title for f in findings)


def test_finds_public_database(vuln):
    assert "RDS_PUBLIC" in rules_fired(vuln)


def test_finds_iam_wildcard(vuln):
    """The wildcard lives inside jsonencode({...}); reading props['policy']
    alone sees only "jsonencode({" and misses it."""
    findings = [f for f in vuln.findings if f.detector.endswith("IAM_WILDCARD")]
    assert findings


def test_finds_unencrypted_volume(vuln):
    assert "UNENCRYPTED_VOLUME" in rules_fired(vuln)


def test_finds_missing_tls_on_ingress(vuln):
    assert "MISSING_TLS" in rules_fired(vuln)


def test_every_finding_carries_evidence(vuln):
    for finding in vuln.findings:
        assert finding.evidence.request or finding.evidence.response, \
            f"{finding.detector} produced a finding with no evidence"


def test_every_finding_has_a_remediation(vuln):
    for finding in vuln.findings:
        assert finding.remediation, finding.title


# -- attack paths: the reason this product exists ------------------------

def test_finds_attack_paths(vuln):
    assert vuln.summary()["attack_paths"] > 0


def test_traces_path_through_open_security_group_to_database(vuln):
    """
    internet -> open security group -> customer database.

    This is the flagship path. If the security group is not marked public, or
    the Terraform reference does not resolve to the group, the graph never
    connects and this path silently disappears.
    """
    index = {a.id: a for a in vuln.assets}
    graph = build_graph(vuln.assets, vuln.relations)
    paths = find_attack_paths(graph, index)
    chains = [p.describe(index) for p in paths]
    assert any("app_sg" in c and "customers" in c for c in chains), \
        f"open-sg -> database path missing. Found: {chains}"


def test_traces_path_from_load_balancer_to_mounted_secret(vuln):
    """The Kubernetes chain: LoadBalancer -> deployment -> mounted secret."""
    index = {a.id: a for a in vuln.assets}
    graph = build_graph(vuln.assets, vuln.relations)
    chains = [p.describe(index)
              for p in find_attack_paths(graph, index)]
    assert any("payments-api" in c and "payments-db-creds" in c
               for c in chains), f"k8s chain missing: {chains}"


def test_paths_are_ordered_worst_first(vuln):
    index = {a.id: a for a in vuln.assets}
    graph = build_graph(vuln.assets, vuln.relations)
    paths = find_attack_paths(graph, index)
    assert paths, "no paths to order"
    assert paths[0].score >= paths[-1].score


def test_shortest_path_is_found(vuln):
    index = {a.id: a for a in vuln.assets}
    graph = build_graph(vuln.assets, vuln.relations)
    paths = find_attack_paths(graph, index)
    assert min(p.hops for p in paths) == 1, "a directly exposed database exists"


def test_paths_become_findings_with_reachability_severity(vuln):
    findings = [f for f in vuln.findings
                if f.detector == "cloudpath:attack_path"]
    assert findings
    for finding in findings:
        assert finding.severity in (Severity.CRITICAL, Severity.HIGH)
        assert "->" in finding.evidence.response, \
            "an attack-path finding must show the chain"


def test_depth_limit_is_respected():
    import networkx as nx
    graph = nx.DiGraph()
    graph.add_node("internet", kind="internet", sensitive=False)
    for i in range(12):
        graph.add_node(f"n{i}", kind="database", sensitive=True)
        graph.add_edge("internet" if i == 0 else f"n{i-1}", f"n{i}",
                       kind="allows")
    assert find_attack_paths(graph, {}, max_depth=3, limit=50)


# -- negative control: the hardened sample ------------------------------

def test_hardened_sample_has_no_findings(hardened):
    assert hardened.findings == [], "false positives on the hardened config: " \
        + ", ".join(f.title for f in hardened.findings)


def test_hardened_sample_has_no_attack_paths(hardened):
    assert hardened.paths == [], "a path was found in a properly scoped config"


def test_hardened_sample_still_parses(hardened):
    """Clean because it was analysed, not because nothing was read."""
    assert hardened.summary()["assets"] >= 5


def test_hardened_records_unverified_rather_than_inventing_findings(hardened):
    """Absent encryption is unknown, not vulnerable."""
    for finding in hardened.findings:
        assert "not stated in" not in finding.evidence.response


# -- parser units -------------------------------------------------------

@pytest.mark.parametrize("ref,expected", [
    ("${aws_security_group.app_sg.id}", "tf:aws_security_group.app_sg"),
    ("aws_instance.web.id", "tf:aws_instance.web"),
    ('"${aws_s3_bucket.data.name}"', "tf:aws_s3_bucket.data"),
    ("vpc-12345", "vpc-12345"),
])
def test_reference_normalisation(ref, expected):
    assert normalise_reference(ref) == expected


def test_reference_normalisation_drops_the_attribute_suffix():
    """Keeping .id pointed every edge at a node that does not exist."""
    assert normalise_reference("${aws_db_instance.main.id}") == \
        "tf:aws_db_instance.main"


def test_split_refs_handles_a_single_element_list():
    assert _split_refs('["${aws_security_group.app_sg.id}"]') == \
        ["tf:aws_security_group.app_sg"]


@pytest.mark.parametrize("cidr,open_", [
    ("[\"0.0.0.0/0\"]", True),
    ("[\"::/0\"]", True),
    ("[\"10.0.0.0/8\"]", False),
    ("[\"1.2.3.4/32\"]", False),
    (None, False),
    ("", False),
])
def test_open_cidr_detection(cidr, open_):
    assert _is_open_cidr(cidr) is open_


@pytest.mark.parametrize("resource_type,kind", [
    ("aws_s3_bucket", "storage"),
    ("aws_db_instance", "database"),
    ("aws_security_group", "security_group"),
    ("aws_iam_policy", "identity"),
    ("aws_secretsmanager_secret", "secret"),
    ("aws_instance", "compute"),
])
def test_terraform_resource_mapping(resource_type, kind):
    assert _terraform_kind(resource_type) == kind


def test_unknown_resource_is_reported_not_ignored(tmp_path):
    path = tmp_path / "main.tf"
    path.write_text('resource "acme_widget" "w" {\n  size = "large"\n}\n',
                    encoding="utf-8")
    assets, relations, notes = parse_file(path)
    assert assets == []
    assert notes and "not" in notes[0] and "analysed" in notes[0]


def test_broken_yaml_is_reported_not_crashing(tmp_path):
    path = tmp_path / "bad.yaml"
    path.write_text("services:\n  api:\n   - broken: [unclosed\n",
                    encoding="utf-8")
    assets, relations, notes = parse_file(path)
    assert assets == []
    assert notes, "a YAML parse error must produce a note, not silence"


def test_load_directory_skips_dependency_directories(tmp_path):
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "x.json").write_text("{}", encoding="utf-8")
    (tmp_path / "main.tf").write_text(
        'resource "aws_s3_bucket" "b" {\n  acl = "private"\n}\n',
        encoding="utf-8")
    assets, _, _ = load_directory(tmp_path)
    assert len(assets) == 1


def test_json_inventory_roundtrip(tmp_path):
    path = tmp_path / "inv.json"
    path.write_text(json.dumps({
        "assets": [{"id": "a1", "kind": "database", "name": "db",
                    "properties": {"publicly_accessible": True}}],
        "relations": [],
    }), encoding="utf-8")
    assets, _, _ = parse_file(path)
    assert len(assets) == 1
    findings = evaluate_assets(assets)
    assert any(f.detector.endswith("RDS_PUBLIC") for f in findings)


def test_graph_does_not_drop_edges_to_undefined_targets():
    """
    An edge naming a resource defined elsewhere still has to appear, or a real
    path is hidden behind a missing node.
    """
    assets = [Asset("db", "database", name="db")]
    relations = [Relation("internet-ish", "db", "allows", "x")]
    graph = build_graph(assets, relations)
    assert graph.has_node("internet-ish")
    assert graph.has_edge("internet-ish", "db")


def test_public_security_group_gets_an_internet_edge():
    assets = [Asset("sg", "security_group", name="sg",
                    properties={"cidr_blocks": '["0.0.0.0/0"]'}),
              Asset("db", "database", name="db")]
    relations = [Relation("sg", "db", "allows", "attached")]
    graph = build_graph(assets, relations)
    assert graph.has_edge("internet", "sg"), \
        "an open security group must be reachable from the internet"


def test_no_findings_when_graph_has_no_internet_node():
    import networkx as nx
    graph = nx.DiGraph()
    graph.add_node("db", kind="database", sensitive=True)
    assert find_attack_paths(graph, {"db": Asset("db", "database")}) == []