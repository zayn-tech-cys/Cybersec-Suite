"""Regression tests for the product-hardening and reporting upgrades."""
from pathlib import Path
import sys

import pytest
from fastapi.testclient import TestClient
from fastapi import Depends

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.auth import AuthStore, Role, make_token
from core.models import Evidence, Finding, Severity
from core.report import report_pdf
from core.storage import Store
from core.web import _login_limited, build_app


def test_pdf_report_is_valid_pdf_and_escapes_untrusted_text():
    finding = Finding(
        title="Reflected input <script>alert(1)</script>",
        severity=Severity.HIGH,
        category="Input validation",
        target="https://example.test",
        location="/search?q=test",
        description="Input was reflected in the response.",
        remediation="Escape untrusted output.",
        evidence=Evidence(request="GET /search", response="<script>untrusted</script>"),
    )
    data = report_pdf([finding], "https://example.test", "AutoPentest", {"scan": "test"})
    assert data.startswith(b"%PDF-")
    assert len(data) > 1000
    assert b"<script>" not in data


def test_login_limiter_blocks_after_threshold_and_can_reset():
    key = "upgrade-test-client"
    _login_limited(key, reset=True)
    for _ in range(8):
        limited, _ = _login_limited(key)
        assert not limited
    limited, retry = _login_limited(key)
    assert limited is True
    assert retry > 0
    assert _login_limited(key, reset=True) == (False, 0)


def test_login_sets_security_headers_and_user_role_is_rechecked(tmp_path):
    auth = AuthStore(tmp_path / "auth.db", secret=b"s" * 32)
    auth.create_user("analyst", "a-secure-password", Role.ANALYST)
    app = build_app("test", "test app", store=Store(tmp_path / "suite.db"), auth=auth)
    @app.get("/protected")
    async def protected(user=Depends(app.state.require_user)):
        return {"username": user.username}
    client = TestClient(app)
    login = client.post("/login", data={"username": "analyst", "password": "a-secure-password"}, follow_redirects=False)
    assert login.status_code == 303
    assert "httponly" in login.headers.get("set-cookie", "").lower()
    assert login.headers["x-content-type-options"] == "nosniff"
    assert login.headers["x-frame-options"] == "DENY"
    auth.set_disabled("admin", "analyst", True)
    # The token remains signed but disabled accounts cannot retain access.
    page = client.get("/protected", follow_redirects=False)
    assert page.status_code == 303
    assert page.headers["location"] == "/login"


def test_admin_user_page_requires_admin_role(tmp_path):
    auth = AuthStore(tmp_path / "auth.db", secret=b"k" * 32)
    auth.create_user("viewer", "viewer-password", Role.VIEWER)
    app = build_app("test", "test app", store=Store(tmp_path / "suite.db"), auth=auth)
    client = TestClient(app)
    token = make_token("viewer", auth.secret)
    client.cookies.set("suite_session", token)
    response = client.get("/admin/users")
    assert response.status_code == 403


def test_report_requires_login_and_pdf_download_works(tmp_path):
    from autopentest.web import router as autopentest_router

    auth = AuthStore(tmp_path / "auth.db", secret=b"p" * 32)
    auth.create_user("viewer", "viewer-password", Role.VIEWER)
    store = Store(tmp_path / "suite.db")
    target_id = store.add_target("example", "web", "https://example.test", authorized=True)
    app = build_app("test", "test app", store=store, auth=auth)
    app.include_router(autopentest_router, prefix="/autopentest")
    client = TestClient(app)

    denied = client.get(f"/autopentest/target/{target_id}/report?fmt=pdf", follow_redirects=False)
    assert denied.status_code == 303
    assert denied.headers["location"] == "/login"

    client.cookies.set("suite_session", make_token("viewer", auth.secret))
    response = client.get(f"/autopentest/target/{target_id}/report?fmt=pdf")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content.startswith(b"%PDF-")
    assert "attachment" in response.headers["content-disposition"]
    page = client.get(f"/autopentest/target/{target_id}")
    assert page.status_code == 200
    assert "Download PDF" in page.text


def test_admin_can_create_user_and_password_policy_is_enforced(tmp_path):
    auth = AuthStore(tmp_path / "auth.db", secret=b"a" * 32)
    auth.create_user("admin", "administrator-password", Role.ADMIN)
    app = build_app("test", "test app", store=Store(tmp_path / "suite.db"), auth=auth)
    client = TestClient(app)
    client.cookies.set("suite_session", make_token("admin", auth.secret))
    page = client.get("/admin/users")
    assert page.status_code == 200
    assert "Create account" in page.text
    weak = client.post("/admin/users", data={"username": "newuser", "password": "shortpass", "role": "viewer"})
    assert weak.status_code == 400
    good = client.post("/admin/users", data={"username": "newuser", "password": "a-strong-password", "role": "viewer"})
    assert good.status_code == 200
    assert auth.get_user("newuser").role == Role.VIEWER
    change = client.post("/admin/users/newuser/role", data={"role": "analyst"})
    assert change.status_code == 200
    assert auth.get_user("newuser").role == Role.ANALYST
    disabled = client.post("/admin/users/newuser/status", data={"disabled": "1"})
    assert disabled.status_code == 200
    assert auth.get_user("newuser").disabled is True
    # The only active admin cannot demote or disable themselves.
    demote_self = client.post("/admin/users/admin/role", data={"role": "viewer"})
    assert demote_self.status_code == 200
    assert "cannot remove your own admin role" in demote_self.text.lower()
    disable_self = client.post("/admin/users/admin/status", data={"disabled": "1"})
    assert "cannot disable your own account" in disable_self.text.lower()
