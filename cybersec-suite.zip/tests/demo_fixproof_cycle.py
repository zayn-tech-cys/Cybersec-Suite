"""
End-to-end regression demonstration, driven by the real AutoPentest engine.

The scenario FixProof exists for, executed for real:

  1. scan a vulnerable app -> the finding is recorded
  2. import it as a regression test -> DISARMED, because nothing has been
     observed fixed yet
  3. fix the vulnerability -> rescan -> the finding is recorded as FIXED
     (retained, not deleted)
  4. re-import -> the test is now ARMED and guarding the fix
  5. run the suite -> PASS
  6. reintroduce the bug -> run the suite -> FAIL, flagged as a regression
  7. re-import -> the regression history survives

Every scan here is the production engine, so the fingerprints the tests compare
are the ones the real tool produces. A demo that used a hand-made finding would
pass while proving nothing.

Run directly:  python tests/demo_fixproof_cycle.py
"""

from __future__ import annotations

import sys
import tempfile
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# FastAPI and uvicorn are imported at MODULE level on purpose. This file uses
# ``from __future__ import annotations``, so annotations are strings and FastAPI
# resolves them against the module globals. A function-local import makes the
# name invisible there, ``request: Request`` degrades to a required *query
# parameter*, and every request to the handler returns 422 -- which looks
# exactly like a target with no vulnerability.
import uvicorn  # noqa: E402
from fastapi import FastAPI, Request  # noqa: E402
from fastapi.responses import HTMLResponse  # noqa: E402

from core.storage import Store  # noqa: E402
from fixproof.cli import junit_xml  # noqa: E402
from fixproof.engine import (  # noqa: E402
    ProofStore, RunConfig, gate_run, run_suite, tests_from_findings)

OK, BAD = "[ ok ]", "[FAIL]"
results = []


def check(label, condition, detail=""):
    results.append(bool(condition))
    mark = OK if condition else BAD
    print(f"  {mark} {label}" + (f"  {detail}" if detail else ""))


def main() -> int:
    import socket

    # One server, one URL, behaviour switched at runtime. Regression testing
    # checks the *same* target before and after a fix.
    state = {"fixed": False}
    app = FastAPI()

    @app.get("/")
    async def index():
        return HTMLResponse(
            '<html><body><a href="/search">search</a></body></html>',
            headers={"x-frame-options": "DENY", "x-content-type-options": "nosniff"})

    @app.get("/search")
    async def search(request: Request):
        q = request.query_params.get("q", "")
        headers = {"x-frame-options": "DENY",
                   "x-content-type-options": "nosniff"}
        if state["fixed"]:
            # The real fix: stop reflecting user input into the response
            # entirely. Searching returns results, never the query echoed back.
            return HTMLResponse(
                f"<p>{len(q.split())} result(s) found</p>", headers=headers)
        # The bug: the query is written into the response with no encoding.
        return HTMLResponse(f"<p>results for: {q}</p>", headers=headers)

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app, log_level="error",
                                           lifespan="on"))
    thread = threading.Thread(target=server.run, kwargs={"sockets": [sock]},
                              daemon=True)
    thread.start()
    deadline = time.monotonic() + 10
    while not server.started and time.monotonic() < deadline:
        time.sleep(0.02)
    url = f"http://127.0.0.1:{port}"

    from autopentest.engine import ScanConfig, scan

    # Reflection only: the point of this demo is the regression lifecycle, and
    # the other detectors only add noise and time.
    config = ScanConfig(max_pages=5, max_depth=1, rate_per_second=50,
                        check_sql=False, check_traversal=False,
                        check_info_leaks=False)

    def do_scan():
        return scan(url, authorized=True, config=config, log=lambda *a: None)

    with tempfile.TemporaryDirectory() as tmp:
        store = Store(Path(tmp) / "suite.db")
        proofs = ProofStore(Path(tmp) / "suite.db")
        target_id = store.add_target("demo", "web", url, authorized=True)

        print("\n1. SCAN the vulnerable app")
        result = do_scan()
        reflection = [f for f in result.findings if f.detector == "reflection"]
        check("vulnerability found by the real engine", len(reflection) == 1,
              f"{len(reflection)} reflection finding(s)")
        if not reflection:
            return 1
        fingerprint = reflection[0].fingerprint

        scan_id = store.start_scan(target_id, "autopentest")
        store.record_scan(scan_id, target_id, "autopentest", result.findings)
        store.finish_scan(scan_id, "completed", result.summary())

        print("\n2. IMPORT as regression tests")
        recorded = store.latest_findings(target_id, "autopentest")
        tests = tests_from_findings(recorded, "autopentest", url, scan_id)
        for test in tests:
            proofs.upsert(test)
        check("tests registered", len(tests) > 0, f"{len(tests)} test(s)")
        mine = [t for t in tests if t.fingerprint == fingerprint][0]
        check("test starts DISARMED", not mine.armed,
              "nothing has been fixed, so nothing guards it yet")
        check("and does not claim to pass", mine.last_result == "unknown")

        print("\n3. FIX the vulnerability, rescan")
        state["fixed"] = True
        fixed = do_scan()
        check("fix verified: no reflection finding",
              not [f for f in fixed.findings if f.detector == "reflection"])
        scan2 = store.start_scan(target_id, "autopentest")
        store.record_scan(scan2, target_id, "autopentest", fixed.findings)
        store.finish_scan(scan2, "completed", fixed.summary())

        print("\n4. RE-IMPORT: the test arms itself")
        after = store.latest_findings(target_id, "autopentest")
        was_fixed = [f for f in after if f.fingerprint == fingerprint]
        check("fixed finding retained, not deleted", len(was_fixed) == 1)
        check("and marked FIXED",
              was_fixed and was_fixed[0].status.value == "fixed",
              f"status: {was_fixed[0].status.value if was_fixed else 'absent'}")
        reimported = tests_from_findings(after, "autopentest", url, scan2)
        for test in reimported:
            proofs.upsert(test)
        armed = [t for t in proofs.list_tests(url) if t.armed]
        check("test is now ARMED", len(armed) >= 1,
              f"{len(armed)} armed test(s)")

        print("\n5. RUN the suite against the FIXED app")
        run = run_suite(proofs, url, RunConfig(rate_per_second=50),
                        log=lambda *a: None)
        check("not treated as a baseline", not run.baseline)
        outcomes = {r.test.fingerprint: r.outcome for r in run.results}
        check("our test passes", outcomes.get(fingerprint) in ("pass", "pending"),
              f"outcome: {outcomes.get(fingerprint)}")
        passed, reasons = gate_run(run)
        check("CI gate passes", passed, f"{len(reasons)} reason(s)")

        print("\n6. REINTRODUCE the bug, run again")
        state["fixed"] = False
        run2 = run_suite(proofs, url, RunConfig(rate_per_second=50),
                         log=lambda *a: None)
        outcomes2 = {r.test.fingerprint: r.outcome for r in run2.results}
        check("regression detected", outcomes2.get(fingerprint) == "fail",
              f"outcome: {outcomes2.get(fingerprint)}")
        failed = [r for r in run2.results if r.is_regression]
        check("regression names the right test",
              bool(failed) and failed[0].test.fingerprint == fingerprint)
        passed2, reasons2 = gate_run(run2)
        check("CI gate FAILS on regression", not passed2,
              f"{len(reasons2)} reason(s)")

        proofs.save_results(run2, url)
        stored = proofs.list_tests(url)
        check("regression counted in history",
              stored[0].regression_count >= 1 or
              any(t.regression_count >= 1 for t in stored),
              f"counts: {[t.regression_count for t in stored]}")

        print("\n7. HISTORY survives re-import")
        before = {t.fingerprint: t.regression_count for t in stored}
        scan3 = store.start_scan(target_id, "autopentest")
        store.record_scan(scan3, target_id, "autopentest", do_scan().findings)
        store.finish_scan(scan3, "completed", {})
        for test in tests_from_findings(
                store.latest_findings(target_id, "autopentest"),
                "autopentest", url, scan3):
            proofs.upsert(test)
        after_counts = {t.fingerprint: t.regression_count
                        for t in proofs.list_tests(url)}
        check("regression_count not reset by re-import",
              all(after_counts.get(k, 0) >= v for k, v in before.items()),
              f"before={before} after={after_counts}")

        print("\n8. JUnit XML distinguishes failure from flaky")
        xml = junit_xml(run2.results, "demo")
        check("junit records the failure", "<failure" in xml)
        check("junit records an error slot for flaky separately",
              "<error" in xml or 'errors="0"' in xml)
        check("junit counts are consistent",
              'failures="1"' in xml, xml.split("<testcase")[0][:120])

    server.should_exit = True
    thread.join(timeout=10)

    print()
    print(f"  {sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())