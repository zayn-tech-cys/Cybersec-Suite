"""
FixProof tests.

The cycle itself is proven by ``demo_fixproof_cycle.py``, which drives the real
AutoPentest engine through scan -> fix -> re-introduce. These tests cover the
unit-level rules that the demo does not reach, with particular attention to the
state machine:

* only an **armed** test can report a regression;
* a **downgraded** finding is a pass, not a failure;
* **history survives** re-import;
* a **flaky** check is never confused with a regression.

Plus the negative controls: an empty run must not claim success, and a broken
scanner must produce skipped tests rather than passes.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.models import Finding, Severity, Status  # noqa: E402
from fixproof.cli import junit_xml  # noqa: E402
from fixproof.engine import (  # noqa: E402
    CheckResult, ProofStore, RegressionTest, RunConfig, RunResult,
    gate_run, run_suite)
from fixproof.engine import tests_from_findings as build_tests_from_findings


@pytest.fixture()
def proofs():
    with tempfile.TemporaryDirectory() as tmp:
        yield ProofStore(Path(tmp) / "t.db")


def finding(**overrides) -> Finding:
    """A finding whose fingerprint is derived from its own content."""
    defaults = dict(
        title="Reflected input on /search", severity=Severity.HIGH,
        category="A03:2021 Injection", target="http://lab",
        location="/search", detector="reflection")
    defaults.update(overrides)
    return Finding(**defaults)


# The canonical finding these tests reason about. Its fingerprint is computed
# from the same content the scanner would produce, so a test built from it and
# a rescan of it always agree.
CANON = finding()
FP = CANON.fingerprint


def make_test(**overrides) -> RegressionTest:
    """
    A regression test matching :data:`CANON`.

    Deriving the fingerprint from the finding rather than hard-coding it is what
    makes the state-machine tests meaningful: a mismatch here used to make
    "the finding returned" look like "the finding vanished", and the suite
    happily reported a regression as a pass.
    """
    defaults = dict(
        fingerprint=FP, product="autopentest", detector=CANON.detector,
        title=CANON.title, severity=CANON.severity, target=CANON.target,
        location=CANON.location, armed=True,
    )
    defaults.update(overrides)
    return RegressionTest(**defaults)




# -- test generation -----------------------------------------------------

def test_open_finding_produces_a_disarmed_test():
    tests = build_tests_from_findings([finding()], "autopentest", "http://lab")
    assert len(tests) == 1
    assert tests[0].armed is False, \
        "nothing guards a vulnerability that has never been fixed"


def test_fixed_finding_produces_an_armed_test():
    fixed = finding()
    fixed.status = Status.FIXED
    tests = build_tests_from_findings([fixed], "autopentest", "http://lab")
    assert tests[0].armed is True, "a fix must start guarding immediately"
    assert tests[0].first_passed


def test_recurred_finding_produces_an_armed_test():
    recurred = finding()
    recurred.status = Status.RECURRED
    assert build_tests_from_findings([recurred], "autopentest", "http://lab")[0].armed


def test_accepted_risk_is_not_turned_into_a_test():
    accepted = finding()
    accepted.status = Status.ACCEPTED
    assert build_tests_from_findings([accepted], "autopentest", "http://lab") == [], \
        "risk-accepted is not going to be fixed, so it is not a test"


def test_origin_scan_is_recorded():
    tests = build_tests_from_findings([finding()], "autopentest", "http://lab", 42)
    assert tests[0].origin_scan == 42


# -- persistence ---------------------------------------------------------

def test_upsert_then_list_roundtrip(proofs):
    proofs.upsert(make_test())
    loaded = proofs.list_tests("http://lab")
    assert len(loaded) == 1
    assert loaded[0].fingerprint == FP
    assert loaded[0].armed is True
    assert loaded[0].recent_results == []


def test_upsert_preserves_history(proofs):
    test = make_test()
    proofs.upsert(test)
    run = RunResult(started_at="now", duration_s=0, baseline=False,
                    results=[CheckResult(test=test, outcome="fail",
                                         detail="came back")])
    proofs.save_results(run, "http://lab")

    # Regenerating the test list from a fresh scan must not reset history.
    proofs.upsert(make_test())
    loaded = proofs.list_tests("http://lab")[0]
    assert loaded.run_count == 1
    assert loaded.fail_count == 1
    assert loaded.regression_count == 1


def test_upsert_does_not_re_arm_a_disarmed_test(proofs):
    proofs.upsert(make_test(armed=False))
    proofs.upsert(make_test(armed=False))
    assert proofs.list_tests("http://lab")[0].armed is False


def test_list_tests_filters_by_target(proofs):
    proofs.upsert(make_test(target="http://a"))
    proofs.upsert(make_test(fingerprint="def456", target="http://b"))
    assert len(proofs.list_tests("http://a")) == 1
    assert len(proofs.list_tests()) == 2


def test_recent_history_is_bounded(proofs):
    test = make_test()
    proofs.upsert(test)
    for _ in range(30):
        run = RunResult(started_at="now", duration_s=0, baseline=False,
                        results=[CheckResult(test=test, outcome="pass")])
        proofs.save_results(run, "http://lab")
    assert len(proofs.list_tests("http://lab")[0].recent_results) <= 20


def test_run_history_is_recorded(proofs):
    test = make_test()
    proofs.upsert(test)
    proofs.save_results(RunResult(started_at="a", duration_s=0, baseline=False,
                                  results=[]), "http://lab")
    proofs.save_results(RunResult(started_at="b", duration_s=0, baseline=True,
                                  results=[]), "http://lab")
    history = proofs.run_history("http://lab")
    assert len(history) == 2
    assert history[0]["baseline"] is True


# -- flakiness -----------------------------------------------------------

def test_alternating_results_are_flaky():
    test = make_test(recent_results=["pass", "fail", "pass", "fail"])
    assert test.is_flaky


def test_consistent_passing_is_not_flaky():
    assert not make_test(recent_results=["pass"] * 6).is_flaky
    assert not make_test(recent_results=["fail"] * 6).is_flaky


def test_too_few_results_is_not_flaky():
    assert not make_test(recent_results=["pass", "fail"]).is_flaky


def test_a_settled_test_is_not_flaky_after_flapping():
    """Two passes at the tail means it has settled, whatever came before."""
    test = make_test(recent_results=["fail", "pass", "fail", "pass", "pass"])
    assert not test.is_flaky


def test_stability_is_reported(proofs):
    test = make_test()
    proofs.upsert(test)
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=test, outcome="pass"),
        CheckResult(test=test, outcome="fail"),
        CheckResult(test=test, outcome="pass"),
        CheckResult(test=test, outcome="pass")])
    proofs.save_results(run, "http://lab")
    assert proofs.list_tests("http://lab")[0].stability == 0.75


# -- the state machine, without any network -----------------------------

class StubProofs(ProofStore):
    """ProofStore with the scanner call replaced, so the rules can be tested."""

    def __init__(self, findings_by_product, tests):
        self._findings = findings_by_product
        self._tests = tests

    def list_tests(self, target=None):
        return list(self._tests)


@pytest.fixture()
def stub(monkeypatch):
    def build(current_findings, tests):
        stubbed = StubProofs({"autopentest": current_findings}, tests)
        monkeypatch.setattr("fixproof.engine._rerun_product",
                            lambda *a, **k: list(current_findings))
        return stubbed
    return build


def test_armed_test_passes_when_the_finding_is_gone(stub):
    test = make_test()
    run = run_suite(stub([], [test]), "http://lab", log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["pass"]
    assert run.baseline is False


def test_armed_test_fails_when_the_finding_returns(stub):
    test = make_test()
    run = run_suite(stub([finding()], [test]), "http://lab",
                    log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["fail"]
    assert run.results[0].is_regression


def test_disarmed_test_that_is_still_present_is_pending(stub):
    """
    Known-unfixed debt must not read as a regression. A suite that reports
    "fail" from the moment it is created gets switched off.
    """
    test = make_test(armed=False)
    run = run_suite(stub([finding()], [test]), "http://lab", log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["pending"]
    assert not any(r.is_regression for r in run.results)


def test_disarmed_test_arms_itself_when_the_finding_disappears(stub):
    test = make_test(armed=False)
    run = run_suite(stub([], [test]), "http://lab", log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["pending"]
    assert "armed" in run.results[0].detail


def test_downgraded_finding_counts_as_fixed(stub):
    """
    A scanner that reports escaped output at INFO has recorded a real
    improvement. Failing the build for a partial fix is not useful.
    """
    test = make_test(severity=Severity.HIGH)
    downgraded = finding(severity=Severity.INFO)
    run = run_suite(stub([downgraded], [test]), "http://lab", log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["pass"]
    assert "downgraded" in run.results[0].detail


def test_severity_increase_is_a_regression(stub):
    test = make_test(severity=Severity.LOW)
    worse = finding(severity=Severity.CRITICAL)
    run = run_suite(stub([worse], [test]), "http://lab", log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["fail"]


def test_first_run_is_a_baseline(stub):
    tests = [make_test(armed=False) for _ in range(3)]
    run = run_suite(stub([], tests), "http://lab", log=lambda *a: None)
    assert run.baseline is True


def test_no_tests_returns_a_baseline_not_a_pass(stub):
    run = run_suite(stub([], []), "http://lab", log=lambda *a: None)
    assert run.baseline is True
    assert run.results == []
    assert run.skipped, "an empty run must say why it checked nothing"


def test_scanner_failure_produces_skipped_not_passing(stub, monkeypatch):
    def boom(*args, **kwargs):
        raise ConnectionError("target unreachable")

    test = make_test()
    stubbed = StubProofs({}, [test])
    monkeypatch.setattr("fixproof.engine._rerun_product", boom)
    run = run_suite(stubbed, "http://lab", log=lambda *a: None)
    assert run.results == []
    assert len(run.skipped) == 1, \
        "an unreachable target means unknown, not passing"


def test_flaky_result_is_reported_separately(stub):
    """A test alternating pass/fail is broken, not a product regression."""
    test = make_test(recent_results=["pass", "fail", "pass", "fail"])
    run = run_suite(stub([finding()], [test]), "http://lab", log=lambda *a: None)
    assert [r.outcome for r in run.results] == ["flaky"]
    assert not any(r.is_regression for r in run.results)


# -- the gate ------------------------------------------------------------

def test_gate_passes_with_no_regressions():
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=make_test(), outcome="pass")])
    passed, reasons = gate_run(run)
    assert passed and not reasons


def test_gate_fails_on_a_regression():
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=make_test(), outcome="fail", detail="back")])
    passed, reasons = gate_run(run)
    assert not passed
    assert "Reflected input" in reasons[0]


def test_gate_ignores_pending_tests():
    """Pre-existing debt is tracked, not enforced."""
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=make_test(armed=False), outcome="pending")])
    passed, _ = gate_run(run)
    assert passed


def test_gate_fails_on_flaky_checks():
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=make_test(), outcome="flaky")])
    passed, reasons = gate_run(run)
    assert not passed
    assert "flaky" in reasons[0].lower()


def test_gate_tolerates_allowed_regressions():
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=make_test(), outcome="fail"),
        CheckResult(test=make_test(), outcome="fail")])
    passed, _ = gate_run(run, max_regressions=2)
    assert passed


def test_gate_reasons_name_severity_and_location():
    run = RunResult(started_at="x", duration_s=0, baseline=False, results=[
        CheckResult(test=make_test(), outcome="fail")])
    _, reasons = gate_run(run)
    assert "high" in reasons[0] and "/search" in reasons[0]


# -- JUnit ---------------------------------------------------------------

def test_junit_reports_failures():
    xml = junit_xml([CheckResult(test=make_test(), outcome="fail",
                                 detail="it came back")], "suite")
    assert "<failure" in xml and 'failures="1"' in xml
    assert "it came back" in xml


def test_junit_separates_errors_from_failures():
    """Flaky is an error, regression is a failure; they mean different things."""
    xml = junit_xml([
        CheckResult(test=make_test(), outcome="fail"),
        CheckResult(test=make_test(fingerprint="b"), outcome="flaky"),
    ], "suite")
    assert 'failures="1"' in xml
    assert 'errors="1"' in xml
    assert "<error" in xml


def test_junit_marks_pending_as_skipped():
    xml = junit_xml([CheckResult(test=make_test(), outcome="pending")], "s")
    assert 'skipped="1"' in xml and "<skipped" in xml


def test_junit_counts_match_the_results():
    results = [CheckResult(test=make_test(), outcome=p)
               for p in ("pass", "pass", "fail", "flaky", "pending")]
    xml = junit_xml(results, "s")
    assert 'tests="5"' in xml
    assert 'failures="1"' in xml and 'errors="1"' in xml and 'skipped="1"' in xml


def test_junit_is_valid_xml():
    import xml.etree.ElementTree as ET
    xml = junit_xml([CheckResult(test=make_test(), outcome="fail")], "s")
    ET.fromstring(xml)


# -- stats ---------------------------------------------------------------

def test_stats_count_armed_disarmed_and_failing(proofs):
    proofs.upsert(make_test(fingerprint="a", armed=True))
    proofs.upsert(make_test(fingerprint="b", armed=False))
    proofs.upsert(make_test(fingerprint="c", armed=True, severity=Severity.LOW))
    stats = proofs.stats()
    assert stats["total"] == 3
    assert stats["armed"] == 2
    assert stats["disarmed"] == 1


def test_stats_identify_the_worst_repeat_offender(proofs):
    once = make_test(fingerprint="a")
    twice = make_test(fingerprint="b")
    proofs.upsert(once)
    proofs.upsert(twice)
    proofs.save_results(
        RunResult(started_at="x", duration_s=0, baseline=False, results=[
            CheckResult(test=once, outcome="fail")]), "http://lab")
    proofs.save_results(
        RunResult(started_at="y", duration_s=0, baseline=False, results=[
            CheckResult(test=twice, outcome="fail"),
            CheckResult(test=twice, outcome="fail")]), "http://lab")
    stats = proofs.stats()
    assert stats["worst_repeat_offender"].fingerprint == "b"


def test_stats_on_empty_store(proofs):
    stats = proofs.stats()
    assert stats["total"] == 0
    assert stats["worst_repeat_offender"] is None