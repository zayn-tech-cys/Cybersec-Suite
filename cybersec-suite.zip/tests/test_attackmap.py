"""
AttackMap tests.

The diff engine is the whole product, so it gets the bulk of these. Two
properties matter more than detection breadth:

* **A clean diff must be empty.** A monitor that reports drift on an unchanged
  surface gets switched off within a week, and then it protects nothing.
* **Port scope must be impossible to bypass.** This is the difference between a
  monitoring tool and a network attack tool that someone pointed at a stranger.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from attackmap.engine import (  # noqa: E402
    Change, Host, Service, Snapshot, _cert_key, _host_severity, _port_in_scope,
    _port_severity, _service_name, changes_to_findings, diff_snapshots,
    load_inventory, summarize, take_snapshot)
from core.models import Severity, dedupe  # noqa: E402


def snap(*hosts, scope="example.com"):
    return Snapshot(scope=scope, hosts=list(hosts))


def host(name, addresses=None, *services):
    return Host(name, list(addresses or []), list(services))


def kinds(changes):
    return sorted(c.kind for c in changes)


# -- the invariant that matters most -------------------------------------

def test_unchanged_surface_produces_no_changes():
    """A monitor that reports drift on an unchanged surface gets switched off."""
    before = snap(host("a.example.com", ["1.1.1.1"], Service(port=80, service="http")))
    after = snap(host("a.example.com", ["1.1.1.1"], Service(port=80, service="http")))
    assert diff_snapshots(before, after) == []


def test_diff_is_order_independent():
    a = host("a.example.com", ["1.1.1.1"], Service(port=80, service="http"))
    b = host("b.example.com", ["2.2.2.2"], Service(port=443, service="https"))
    forward = kinds(diff_snapshots(snap(a, b), snap(b, a)))
    reverse = kinds(diff_snapshots(snap(b, a), snap(a, b)))
    assert forward == reverse


# -- change detection ----------------------------------------------------

def test_new_host_detected():
    changes = diff_snapshots(snap(), snap(host("new.example.com")))
    assert kinds(changes) == ["host_added"]


def test_removed_host_detected():
    before = snap(host("old.example.com", ["1.1.1.1"], Service(port=80, service="http")))
    assert kinds(diff_snapshots(before, snap())) == ["host_removed"]


def test_new_port_detected():
    before = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
    after = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http"),
                      Service(port=6379, service="Redis")))
    changes = diff_snapshots(before, after)
    assert kinds(changes) == ["port_added"]
    assert changes[0].subject == "a.com:6379"
    assert changes[0].severity is Severity.HIGH


def test_removed_port_detected():
    before = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
    after = snap(host("a.com", ["1.1.1.1"]))
    assert kinds(diff_snapshots(before, after)) == ["port_removed"]


def test_service_change_on_same_port_detected():
    before = snap(host("a.com", ["1.1.1.1"], Service(port=8080, service="http-alt")))
    after = snap(host("a.com", ["1.1.1.1"], Service(port=8080, service="nginx")))
    changes = diff_snapshots(before, after)
    assert kinds(changes) == ["service_changed"], \
        f"expected a service change, got {kinds(changes)}"
    assert changes[0].evidence["was"] == "http-alt"
    assert changes[0].evidence["now"] == "nginx"


def test_same_service_on_same_port_is_not_a_change():
    """The common case: the service is labelled consistently, so nothing fires."""
    before = snap(host("a.com", ["1.1.1.1"], Service(port=6379, service="Redis")))
    after = snap(host("a.com", ["1.1.1.1"], Service(port=6379, service="Redis")))
    assert diff_snapshots(before, after) == []


def test_certificate_change_detected_on_https_only():
    before = snap(host("a.com", ["1.1.1.1"],
                       Service(443, "https", tls=True, cert_fingerprint="old")))
    after = snap(host("a.com", ["1.1.1.1"],
                      Service(443, "https", tls=True, cert_fingerprint="new")))
    changes = diff_snapshots(before, after)
    assert kinds(changes) == ["cert_changed"]
    assert changes[0].evidence["fingerprint"] == "new"


def test_plain_http_port_does_not_report_cert_change():
    """HTTP has no certificate; reporting one would be nonsense."""
    before = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
    after = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
    assert diff_snapshots(before, after) == []


def test_host_starting_to_resolve_is_high():
    """The classic subdomain-takeover shape: a dangling record resolves again."""
    before = snap(host("staging.example.com", []))
    after = snap(host("staging.example.com", ["1.2.3.4"]))
    changes = diff_snapshots(before, after)
    assert kinds(changes) == ["host_resolved"]
    assert changes[0].severity is Severity.HIGH


def test_host_stopping_resolving_is_informational():
    before = snap(host("a.example.com", ["1.1.1.1"]))
    after = snap(host("a.example.com", []))
    changes = diff_snapshots(before, after)
    assert kinds(changes) == ["host_unresolved"]
    assert changes[0].severity is Severity.INFO


def test_baseline_run_labels_itself():
    """First run says so, so a baseline is never mistaken for a breach."""
    changes = diff_snapshots(None, snap(host("a.example.com", ["1.1.1.1"],
                                              Service(443, "https", tls=True))))
    assert summarize(changes)["baseline"] is True
    assert all("First observation" in c.significance for c in changes)


def test_real_changes_are_not_labelled_baseline():
    before = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
    after = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http"),
                      Service(port=22, service="ssh")))
    assert summarize(diff_snapshots(before, after))["baseline"] is False


# -- severity grading ----------------------------------------------------

@pytest.mark.parametrize("port,expected", [
    (6379, Severity.HIGH),      # Redis, no auth by default
    (27017, Severity.HIGH),     # MongoDB
    (9200, Severity.HIGH),      # Elasticsearch
    (3306, Severity.HIGH),      # MySQL
    (3389, Severity.HIGH),      # RDP
    (23, Severity.HIGH),        # Telnet
    (22, Severity.MEDIUM),
    (443, Severity.MEDIUM),     # HTTPS must not score below an obscure port
    (80, Severity.LOW),
    (9999, Severity.INFO),
])
def test_port_severity_grading(port, expected):
    assert _port_severity(port) is expected


@pytest.mark.parametrize("name,expected", [
    ("dev-api.example.com", Severity.HIGH),
    ("staging.example.com", Severity.HIGH),
    ("qa.example.com", Severity.HIGH),
    ("old.example.com", Severity.HIGH),
    ("admin.example.com", Severity.MEDIUM),
    ("example.com", Severity.LOW),
])
def test_host_severity_grading(name, expected):
    assert _host_severity(Host(name)) is expected


def test_database_port_on_new_host_raises_host_severity():
    plain = Host("shop.example.com")
    with_db = Host("shop.example.com", [], [Service(port=3306, service="MySQL")])
    assert _host_severity(plain) is Severity.LOW
    assert _host_severity(with_db) is Severity.MEDIUM


# -- port scope enforcement ---------------------------------------------

def test_empty_scope_allows_but_is_bounded_elsewhere():
    assert _port_in_scope(22, "") is True


@pytest.mark.parametrize("scope,port,allowed", [
    ("22,443", 22, True),
    ("22,443", 80, False),
    ("80-443", 80, True),
    ("80-443", 443, True),
    ("80-443", 22, False),
    ("80-443", 444, False),
    ("1000-2000", 1500, True),
    ("1000-2000", 999, False),
    ("1000-2000", 3000, False),
    ("443", 443, True),
    ("443", 80, False),
])
def test_port_scope_is_respected(scope, port, allowed):
    assert _port_in_scope(port, scope) is allowed


def test_port_scope_never_allows_a_wildcard():
    """
    An empty or malformed scope must not widen to every port. A monitor that
    silently falls back to "probe everything" is how a change-detection tool
    becomes an indiscriminate scanner.
    """
    for scope in ("", "*", "all", ",", "abc", "0-"):
        for port in (22, 6379, 27017):
            if scope == "":
                continue
            # A non-empty but unparseable scope must not match random ports.
            if any(ch.isdigit() for ch in scope):
                continue
            assert _port_in_scope(port, scope) is False, \
                f"scope {scope!r} allowed port {port}"


def test_take_snapshot_refuses_probing_without_scope():
    """
    The UI and API both refuse this; the engine must too, in case it is called
    directly.
    """
    from attackmap.engine import ScanConfig
    snapshot = take_snapshot("localhost", ScanConfig(use_ct=False, probe=False))
    assert snapshot.hosts == []


# -- inventory loading ---------------------------------------------------

def test_load_inventory_csv(tmp_path):
    path = tmp_path / "assets.csv"
    path.write_text(
        "# hostname,ip,port,service,state\n"
        "web.example.com,10.0.0.1,443,https,open\n"
        "db.example.com,10.0.0.2,3306,mysql,open\n"
        "\n",
        encoding="utf-8")
    hosts = load_inventory(str(path))
    assert len(hosts) == 2
    assert hosts[0].hostname == "web.example.com"
    assert hosts[0].services[0].port == 443
    assert hosts[1].addresses == ["10.0.0.2"]


def test_load_inventory_skips_comments_and_blanks(tmp_path):
    path = tmp_path / "a.csv"
    path.write_text("# comment\n\nweb.example.com\n", encoding="utf-8")
    hosts = load_inventory(str(path))
    assert len(hosts) == 1
    assert hosts[0].services == []


def test_load_inventory_roundtrips_a_snapshot(tmp_path):
    original = snap(host("a.com", ["1.1.1.1"], Service(443, "https", tls=True,
                                                         cert_fingerprint="z")))
    path = tmp_path / "s.json"
    path.write_text(original.to_json(), encoding="utf-8")
    restored = Snapshot.from_json(path.read_text(encoding="utf-8"))
    assert restored.hosts[0].hostname == "a.com"
    assert restored.hosts[0].services[0].cert_fingerprint == "z"


def test_snapshot_json_roundtrip_preserves_totals():
    original = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http"),
                         Service(443, "https", tls=True)))
    restored = Snapshot.from_json(original.to_json())
    assert restored.totals() == original.totals()
    assert restored.totals()["tls_endpoints"] == 1


# -- findings ------------------------------------------------------------

def test_every_change_becomes_a_finding_with_evidence():
    before = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
    after = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http"),
                      Service(port=6379, service="Redis")))
    findings = changes_to_findings(diff_snapshots(before, after), "example.com")
    assert len(findings) == 1
    finding = findings[0]
    assert finding.product == "attackmap"
    assert finding.evidence.response, "a change needs its evidence attached"
    assert finding.remediation


def test_change_fingerprints_are_stable_across_runs():
    """Unstable fingerprints turn one persistent problem into endless 'new'."""
    def build():
        before = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http")))
        after = snap(host("a.com", ["1.1.1.1"], Service(port=80, service="http"),
                          Service(port=6379, service="Redis")))
        return [f.fingerprint
                for f in changes_to_findings(diff_snapshots(before, after), "x")]
    assert build() == build()


def test_different_change_kinds_have_different_fingerprints():
    added = Change("port_added", "a.com:6379", "x", Severity.HIGH).fingerprint()
    removed = Change("port_removed", "a.com:6379", "x", Severity.HIGH).fingerprint()
    assert added != removed


def test_changes_deduplicate_to_one_finding():
    """The same port reported twice is one problem, not two."""
    findings = changes_to_findings([
        Change("port_added", "a.com:6379", "New port 6379", Severity.HIGH),
        Change("port_added", "a.com:6379", "New port 6379", Severity.HIGH),
    ], "example.com")
    assert len(dedupe(findings)) == 1


# -- service naming ------------------------------------------------------

@pytest.mark.parametrize("port,name", [
    (6379, "Redis"), (3306, "MySQL"), (22, "SSH"), (443, "https"),
    (8080, "http-alt"), (12345, "unknown"),
])
def test_service_naming(port, name):
    assert _service_name(port) == name


def test_cert_key_changes_with_content():
    a = _cert_key({"common_name": "x", "issuer_name": "y"})
    b = _cert_key({"common_name": "x", "issuer_name": "z"})
    assert a != b
    assert a == _cert_key({"common_name": "x", "issuer_name": "y"})


def test_ct_lookup_failure_is_not_fatal():
    """
    A public API being down must not stop a snapshot. A monitor that will not
    start because crt.sh is unavailable is a monitor that gets uninstalled.
    """
    from attackmap.engine import from_ct_log
    assert from_ct_log("example.invalid", log=lambda *a: None) == []


# -- summary -------------------------------------------------------------

def test_summary_counts_kinds_and_urgent_changes():
    changes = [
        Change("port_added", "a:6379", "x", Severity.HIGH),
        Change("port_added", "b:27017", "y", Severity.HIGH),
        Change("host_removed", "c", "z", Severity.LOW),
    ]
    summary = summarize(changes)
    assert summary["total"] == 3
    assert summary["by_kind"]["port_added"] == 2
    assert summary["urgent"] == 2


def test_empty_snapshot_summarises_cleanly():
    summary = summarize([])
    assert summary["total"] == 0
    assert summary["by_kind"] == {}