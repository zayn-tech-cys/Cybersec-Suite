"""Shared core for all five products."""
