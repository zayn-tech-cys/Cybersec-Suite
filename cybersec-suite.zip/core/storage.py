"""
SQLite persistence.

SQLite rather than PostgreSQL deliberately: these are single-operator tools and
requiring a database server to run a scan is a barrier with no upside at this
scale. WAL mode plus a short busy timeout is enough for the one-writer
workload here, and the schema is plain SQL so moving to Postgres later is
mechanical.

The interesting logic is in :meth:`Store.record_scan`, which is how regression
detection works across runs -- see the docstring there.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

from .models import Finding, Severity, Status, compare_scans, utcnow

DEFAULT_PATH = Path(__file__).resolve().parent.parent / "data" / "suite.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS targets (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    kind         TEXT NOT NULL,          -- web | api | domain | cloud | repo
    locator      TEXT NOT NULL,          -- url, spec path, domain, config dir
    authorized   INTEGER NOT NULL DEFAULT 0,
    notes        TEXT DEFAULT '',
    created_at   TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS targets_unique
    ON targets(kind, locator);

CREATE TABLE IF NOT EXISTS scans (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id    INTEGER NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    product      TEXT NOT NULL,          -- autopentest | apishield | ...
    started_at   TEXT NOT NULL,
    finished_at  TEXT,
    status       TEXT NOT NULL DEFAULT 'running',
    error        TEXT DEFAULT '',
    summary      TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (target_id) REFERENCES targets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS scans_target ON scans(target_id, product);

CREATE TABLE IF NOT EXISTS findings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id      INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    target_id    INTEGER NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    fingerprint  TEXT NOT NULL,
    title        TEXT NOT NULL,
    severity     TEXT NOT NULL,
    status       TEXT NOT NULL,
    category     TEXT NOT NULL,
    detector     TEXT DEFAULT '',
    location     TEXT DEFAULT '',
    payload      TEXT NOT NULL          -- full Finding JSON
);
CREATE INDEX IF NOT EXISTS findings_scan ON findings(scan_id);
CREATE INDEX IF NOT EXISTS findings_fp   ON findings(target_id, fingerprint);
CREATE INDEX IF NOT EXISTS findings_status ON findings(target_id, status);

-- Findings that were fixed and must be re-checked, FixProof's core table.
CREATE TABLE IF NOT EXISTS regressions (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id         INTEGER NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
    fingerprint       TEXT NOT NULL,
    title             TEXT NOT NULL,
    severity          TEXT NOT NULL,
    first_seen        TEXT NOT NULL,
    fixed_at          TEXT,
    reintroduced_at   TEXT,
    reintroduced_count INTEGER NOT NULL DEFAULT 0,
    payload           TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS regressions_target ON regressions(target_id, fingerprint);
"""


class Store:
    """Persistence for targets, scans and findings."""

    def __init__(self, path: Optional[Path | str] = None) -> None:
        self.path = Path(path) if path else DEFAULT_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 15000")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self.connect() as conn:
            conn.executescript(SCHEMA)

    # -- targets ---------------------------------------------------------

    def add_target(self, name: str, kind: str, locator: str,
                   authorized: bool = False, notes: str = "") -> int:
        """
        Register a target.

        ``authorized`` is not decoration. Every product refuses to actively test
        a target that is not marked authorized, and the reasoning is logged, so
        "why did it scan that?" always has an answer.
        """
        with self.connect() as conn:
            existing = conn.execute(
                "SELECT id FROM targets WHERE kind = ? AND locator = ?",
                (kind, locator),
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE targets SET name = ?, authorized = ?, notes = ? WHERE id = ?",
                    (name, int(authorized), notes, existing["id"]),
                )
                return int(existing["id"])
            cursor = conn.execute(
                "INSERT INTO targets(name, kind, locator, authorized, notes, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (name, kind, locator, int(authorized), notes, utcnow()),
            )
            return int(cursor.lastrowid)

    def get_target(self, target_id: int) -> Optional[dict]:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM targets WHERE id = ?",
                               (target_id,)).fetchone()
            return dict(row) if row else None

    def list_targets(self) -> list[dict]:
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(
                "SELECT * FROM targets ORDER BY kind, name").fetchall()]

    def find_target(self, kind: str, locator: str) -> Optional[dict]:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM targets WHERE kind = ? AND locator = ?",
                (kind, locator)).fetchone()
            return dict(row) if row else None

    # -- scans -----------------------------------------------------------

    def start_scan(self, target_id: int, product: str) -> int:
        with self.connect() as conn:
            cursor = conn.execute(
                "INSERT INTO scans(target_id, product, started_at, status)"
                " VALUES (?, ?, ?, 'running')",
                (target_id, product, utcnow()),
            )
            return int(cursor.lastrowid)

    def finish_scan(self, scan_id: int, status: str = "completed",
                    summary: Optional[dict] = None, error: str = "") -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE scans SET finished_at = ?, status = ?, summary = ?, error = ?"
                " WHERE id = ?",
                (utcnow(), status, json.dumps(summary or {}), error, scan_id),
            )

    def get_scan(self, scan_id: int) -> Optional[dict]:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM scans WHERE id = ?",
                               (scan_id,)).fetchone()
            if not row:
                return None
            data = dict(row)
            data["summary"] = json.loads(data.get("summary") or "{}")
            return data

    def previous_scan(self, target_id: int, product: str) -> Optional[dict]:
        """Most recent completed scan for this target and product."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM scans WHERE target_id = ? AND product = ?"
                " AND status = 'completed' ORDER BY id DESC LIMIT 1",
                (target_id, product)).fetchone()
            if not row:
                return None
            data = dict(row)
            data["summary"] = json.loads(data.get("summary") or "{}")
            return data

    def list_scans(self, target_id: int, product: str, limit: int = 50) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM scans WHERE target_id = ? AND product = ?"
                " ORDER BY id DESC LIMIT ?", (target_id, product, limit)).fetchall()
        out = []
        for row in rows:
            data = dict(row)
            data["summary"] = json.loads(data.get("summary") or "{}")
            out.append(data)
        return out

    # -- findings --------------------------------------------------------

    def save_findings(self, scan_id: int, target_id: int,
                      findings: list[Finding]) -> None:
        with self.connect() as conn:
            conn.executemany(
                "INSERT INTO findings(scan_id, target_id, fingerprint, title,"
                " severity, status, category, detector, location, payload)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [(scan_id, target_id, f.fingerprint, f.title, f.severity.value,
                  f.status.value, f.category, f.detector, f.location,
                  json.dumps(f.to_dict(), default=str)) for f in findings],
            )

    def findings_for_scan(self, scan_id: int) -> list[Finding]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT payload FROM findings WHERE scan_id = ?", (scan_id,)
            ).fetchall()
        return [Finding.from_dict(json.loads(r["payload"])) for r in rows]

    def latest_findings(self, target_id: int, product: str) -> list[Finding]:
        """Findings from the most recent completed scan of a product."""
        scan = self.previous_scan(target_id, product)
        return self.findings_for_scan(scan["id"]) if scan else []

    # -- the interesting part: cross-scan state -------------------------

    def previous_findings_before(self, target_id: int, product: str,
                                scan_id: int) -> list[Finding]:
        """
        Findings from the most recent earlier scan of this product.

        Keys off scan ordering, not on the previous scan having been marked
        ``completed``. An earlier version filtered on status, which meant that
        if a caller forgot to finish a scan -- easy to do, since recording and
        finishing are separate calls -- every scan looked like the first one and
        no fix or regression was ever detected. The tool would still report
        findings; it would just never notice that anything changed.
        """
        with self.connect() as conn:
            row = conn.execute(
                "SELECT id FROM scans WHERE target_id = ? AND product = ? AND id < ?"
                " ORDER BY id DESC LIMIT 1",
                (target_id, product, scan_id)).fetchone()
        return self.findings_for_scan(int(row["id"])) if row else []

    def fixed_fingerprints(self, target_id: int) -> set[str]:
        """
        Fingerprints with a recorded fix.

        The regressions table is the source of truth for "was this ever fixed",
        not the previous scan's status. A finding that disappeared in scan 2 and
        came back in scan 5 was never "open" in scan 4, so only the persisted
        fix record identifies it as a regression.
        """
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT fingerprint FROM regressions"
                " WHERE target_id = ? AND fixed_at IS NOT NULL",
                (target_id,)).fetchall()
        return {r["fingerprint"] for r in rows}

    def record_scan(self, scan_id: int, target_id: int, product: str,
                    findings: list[Finding]) -> dict:
        """
        Persist a scan and work out what changed since the last one.

        Returns counts of new, persisting, fixed and recurring. Recurrence is
        detected from the persisted fix history rather than by comparing
        consecutive scans, so a bug fixed in scan 2 and reintroduced in scan 9 is
        still reported as a regression.
        """
        previous = self.previous_findings_before(target_id, product, scan_id)
        previous_fps = {f.fingerprint for f in previous}
        ever_fixed = self.fixed_fingerprints(target_id)
        diff = compare_scans(previous, findings)

        now = utcnow()
        for finding in findings:
            if finding.fingerprint in ever_fixed:
                finding.status = Status.RECURRED
                finding.tags.append("regression")
                finding.tags.append("reintroduced_after_fix")
            elif finding.fingerprint in previous_fps:
                finding.status = Status.OPEN
                finding.tags.append("persisting")
            else:
                finding.status = Status.OPEN
                finding.tags.append("new")
            finding.scan_id = scan_id

        for finding in diff["fixed"]:
            finding.status = Status.FIXED
            finding.scan_id = scan_id

        self.save_findings(scan_id, target_id, findings + diff["fixed"])
        self._update_regressions(target_id, findings, diff, now)

        return {
            "new": len(diff["new"]),
            "persisting": sum(1 for f in findings if f.status is Status.OPEN
                              and "persisting" in f.tags),
            "fixed": len(diff["fixed"]),
            "recurring": sum(1 for f in findings if f.status is Status.RECURRED),
            "total": len(findings),
        }

    def _update_regressions(self, target_id: int, findings: list[Finding],
                           diff: dict, now: str) -> None:
        """Maintain the regressions table: first sighting, fixes, and returns."""
        present = {f.fingerprint for f in findings}
        with self.connect() as conn:
            for finding in findings:
                row = conn.execute(
                    "SELECT id, fixed_at, reintroduced_count FROM regressions"
                    " WHERE target_id = ? AND fingerprint = ?",
                    (target_id, finding.fingerprint)).fetchone()
                if row is None:
                    conn.execute(
                        "INSERT INTO regressions(target_id, fingerprint, title,"
                        " severity, first_seen, payload)"
                        " VALUES (?, ?, ?, ?, ?, ?)",
                        (target_id, finding.fingerprint, finding.title,
                         finding.severity.value, now,
                         json.dumps(finding.to_dict(), default=str)))
                elif row["fixed_at"]:
                    conn.execute(
                        "UPDATE regressions SET fixed_at = NULL,"
                        " reintroduced_at = ?, reintroduced_count ="
                        " reintroduced_count + 1 WHERE id = ?",
                        (now, row["id"]))

            for finding in diff["fixed"]:
                conn.execute(
                    "UPDATE regressions SET fixed_at = ?"
                    " WHERE target_id = ? AND fingerprint = ? AND fixed_at IS NULL",
                    (now, target_id, finding.fingerprint))

    def regression_history(self, target_id: int) -> list[dict]:
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(
                "SELECT fingerprint, title, severity, first_seen, fixed_at,"
                " reintroduced_at, reintroduced_count FROM regressions"
                " WHERE target_id = ? ORDER BY first_seen DESC",
                (target_id,)).fetchall()]

    def stats(self, target_id: int, product: str) -> dict:
        """Counts for a dashboard, computed from the live regressions table.

        Fixed findings are excluded from the severity counts. They are stored
        against the scan in which they were last seen so the history is
        complete, which means a raw count would report issues that no longer
        exist -- the exact number a dashboard must never get wrong.
        """
        scan = self.previous_scan(target_id, product)
        current = self.findings_for_scan(scan["id"]) if scan else []
        live = [f for f in current if f.status is not Status.FIXED]
        counts = {s.value: 0 for s in Severity}
        for finding in live:
            counts[finding.severity.value] += 1
        history = self.regression_history(target_id)
        return {
            "open": sum(1 for f in live if f.status is Status.OPEN),
            "regressions": sum(1 for f in live if f.status is Status.RECURRED),
            "by_severity": counts,
            "ever_reintroduced": sum(1 for h in history if h["reintroduced_count"]),
            "ever_fixed": sum(1 for h in history if h["fixed_at"]),
            "last_scan": scan["finished_at"] if scan else None,
            "total_open": len(live),
        }