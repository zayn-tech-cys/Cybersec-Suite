"""
Shared web application factory.

All five products are the same shape: a scan engine, a JSON API, an HTML
dashboard, and login. Writing that once here means each product module only
contains the part that is actually different -- its detectors and its views.

Product modules call :func:`build_app` with their own router and dashboard
callables and get the shell for free: auth, nav, styling, and the role gate.
"""

from __future__ import annotations

import functools
import os
import threading
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Callable, Optional

from fastapi import Depends, FastAPI, Form, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .auth import SESSION_COOKIE, AuthStore, Role, User, make_token, read_token
from .storage import Store

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("SUITE_DATA_DIR", str(BASE_DIR.parent / "data"))).resolve()
STATIC_DIR = BASE_DIR / "static"

_LOGIN_WINDOW_SECONDS = 300
_LOGIN_MAX_ATTEMPTS = 8
_login_lock = threading.Lock()
_login_attempts: dict[str, deque[float]] = defaultdict(deque)

def _login_limited(key: str, *, reset: bool = False) -> tuple[bool, int]:
    """Small per-process login throttle; use a proxy/shared limiter for multi-worker deployments."""
    now = time.monotonic()
    with _login_lock:
        attempts = _login_attempts[key]
        while attempts and now - attempts[0] > _LOGIN_WINDOW_SECONDS:
            attempts.popleft()
        if reset:
            attempts.clear()
            return False, 0
        if len(attempts) >= _LOGIN_MAX_ATTEMPTS:
            return True, max(1, int(_LOGIN_WINDOW_SECONDS - (now - attempts[0])))
        attempts.append(now)
        # Bound memory if clients rotate source addresses.
        if len(_login_attempts) > 4096:
            for stale in list(_login_attempts)[:1024]:
                queue = _login_attempts.get(stale)
                if queue is not None:
                    while queue and now - queue[0] > _LOGIN_WINDOW_SECONDS:
                        queue.popleft()
                    if not queue:
                        _login_attempts.pop(stale, None)
        return False, 0

NAV_CSS = """
:root{--bg:#0b1120;--panel:#111c33;--panel2:#16233d;--line:#243350;
 --fg:#e6edf7;--dim:#8fa3c0;--accent:#3b82f6;--crit:#f26d6d;--high:#f59e0b;
 --med:#eab308;--low:#38bdf8;--info:#64748b;--ok:#34d399}
*{box-sizing:border-box}
body{margin:0;background:radial-gradient(ellipse at top right,#142746 0%,var(--bg) 42%);color:var(--fg);font:14px/1.55
 ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
a{color:#93c5fd;text-decoration:none}a:hover{text-decoration:underline}
header.top{background:rgba(13,23,41,.94);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);
 position:sticky;top:0;z-index:20;padding:0 20px}
.topin{max-width:1240px;margin:0 auto;display:flex;align-items:center;gap:18px;
 height:56px;flex-wrap:wrap}
.brand{font-weight:700;font-size:15px;letter-spacing:-.2px;white-space:nowrap}
.brand span{color:var(--accent)}
nav{display:flex;gap:4px;flex:1;flex-wrap:wrap}
nav a{padding:6px 11px;border-radius:7px;color:var(--dim);font-size:13px}
nav a:hover{background:var(--panel);color:var(--fg);text-decoration:none}
nav a.on{background:var(--accent);color:#fff}
.spacer{flex:1}
.who{color:var(--dim);font-size:12px}
.who b{color:var(--fg)}
.role{padding:1px 7px;border-radius:5px;background:var(--panel2);
 border:1px solid var(--line);font-size:11px;color:var(--dim)}
main{max-width:1240px;margin:0 auto;padding:24px 20px 80px}
h1{font-size:21px;margin:0 0 3px}h2{font-size:16px;margin:26px 0 10px}
h3{font-size:14px;margin:16px 0 7px;color:var(--dim);
 text-transform:uppercase;letter-spacing:.5px}
p.lede{color:var(--dim);margin:0 0 22px;font-size:14px}
.grid{display:grid;gap:14px}
.g2{grid-template-columns:repeat(auto-fit,minmax(300px,1fr))}
.g3{grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
.g4{grid-template-columns:repeat(auto-fit,minmax(165px,1fr))}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;
 padding:18px 20px;box-shadow:0 10px 28px rgba(0,0,0,.12);transition:transform .16s,border-color .16s}
.card:hover{border-color:#38547d}
.card h3{margin-top:0}
.kpi .n{font-size:27px;font-weight:650;letter-spacing:-.6px;line-height:1.15}
.kpi .l{color:var(--dim);font-size:11px;text-transform:uppercase;
 letter-spacing:.6px;margin-top:2px}
table{width:100%;border-collapse:collapse;background:var(--panel);
 border:1px solid var(--line);border-radius:11px;overflow:hidden}
th,td{padding:9px 12px;border-bottom:1px solid var(--line);text-align:left;
 font-size:13px;vertical-align:top}
th{background:#0e1a30;color:var(--dim);font-size:11px;text-transform:uppercase;
 letter-spacing:.5px}
tr:last-child td{border-bottom:none}
tr:hover td{background:#132038}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;
 font-weight:650;color:#fff;text-transform:uppercase;letter-spacing:.4px;
 white-space:nowrap}
.b-critical{background:var(--crit)}.b-high{background:var(--high);color:#1a1200}
.b-medium{background:var(--med);color:#1a1200}.b-low{background:var(--low);
 color:#04141f}.b-info{background:var(--info)}
.b-open{background:#3b82f6}.b-fixed{background:var(--ok);color:#04231a}
.b-recurred{background:#a855f7}.b-accepted{background:#64748b}
.btn{display:inline-block;padding:8px 15px;border-radius:9px;border:1px solid
 var(--line);background:linear-gradient(180deg,var(--panel2),#111c33);color:var(--fg);cursor:pointer;
 font-size:13px;font-family:inherit}
.btn:hover{border-color:var(--accent);text-decoration:none}
.btn.primary{background:var(--accent);border-color:var(--accent);color:#fff}
.btn.danger{background:#b3261e;border-color:#b3261e;color:#fff}
form.inline{display:inline}
label{display:block;font-size:12px;color:var(--dim);margin:10px 0 4px}
input,select,textarea{width:100%;padding:8px 10px;border-radius:8px;
 border:1px solid var(--line);background:#0c1729;color:var(--fg);
 font-family:inherit;font-size:13px}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--accent)}
textarea{min-height:90px;font-family:ui-monospace,Menlo,Consolas,monospace;
 font-size:12px}
.hint{color:var(--dim);font-size:12px;margin-top:4px}
.warn{background:#2a1f0d;border:1px solid #7c5a10;border-left:3px solid
 var(--high);border-radius:8px;padding:12px 15px;margin:14px 0;font-size:13px;
 color:#f5e2b8}
.err{background:#2b1113;border:1px solid #7a2020;border-left:3px solid var(--crit);
 border-radius:8px;padding:12px 15px;margin:14px 0;font-size:13px;color:#f8c9c9}
.ok{background:#0d2a20;border:1px solid #1c6b4f;border-left:3px solid var(--ok);
 border-radius:8px;padding:12px 15px;margin:14px 0;font-size:13px;color:#b6efd7}
.mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px}
.muted{color:var(--dim)}
.empty{background:var(--panel);border:1px dashed var(--line);border-radius:11px;
 padding:34px;text-align:center;color:var(--dim)}
.bar{display:flex;height:11px;border-radius:6px;overflow:hidden;
 border:1px solid var(--line);background:#0c1729}
.bar div{height:100%}
details{margin-top:6px}
summary{cursor:pointer;color:#93c5fd;font-size:12px}
pre{background:#080f1d;border:1px solid var(--line);border-radius:8px;padding:11px;
 overflow:auto;font-size:11.5px;line-height:1.5;margin:6px 0 0;
 font-family:ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;
 word-break:break-word;max-height:330px}
.login{max-width:420px;margin:11vh auto}
@media(max-width:720px){.topin{height:auto;padding:12px 0;gap:10px}.top{padding:0 12px!important}nav{order:3;flex-basis:100%;overflow-x:auto}.who{margin-left:auto}main{padding:20px 12px 48px}.g2{grid-template-columns:1fr}.card{padding:15px}}
:focus-visible{outline:2px solid #60a5fa;outline-offset:2px}
::selection{background:#2563eb;color:#fff}
.steps{counter-reset:s;list-style:none;padding:0;margin:10px 0}
.steps li{counter-increment:s;padding:7px 0 7px 32px;position:relative;
 border-bottom:1px solid var(--line)}
.steps li:last-child{border-bottom:none}
.steps li::before{content:counter(s);position:absolute;left:0;top:7px;width:20px;
 height:20px;border-radius:50%;background:var(--panel2);color:var(--dim);
 font-size:11px;display:grid;place-items:center}
footer{max-width:1240px;margin:0 auto;padding:20px;color:var(--dim);font-size:12px;
 border-top:1px solid var(--line)}
"""

PRODUCTS = [
    ("/", "Overview", "index"),
    ("/autopentest", "AutoPentest", "autopentest"),
    ("/apishield", "APIShield", "apishield"),
    ("/attackmap", "AttackMap", "attackmap"),
    ("/cloudpath", "CloudPath", "cloudpath"),
    ("/fixproof", "FixProof", "fixproof"),
]


class _RoleGate:
    """
    Import-time-safe role dependency.

    A product module writes ``Depends(require_role_at(Role.ANALYST))`` when its
    router is defined, which happens before ``build_app`` has run and therefore
    before ``app.state.require_role`` exists. This resolves the real dependency
    from the request at call time instead of closing over it early -- the
    alternative, building the dependency lazily inside each handler, invites
    silently forgetting the check.
    """

    def install(self, app: FastAPI) -> None:
        self._app = app

    def __call__(self, minimum: str) -> Callable:
        async def dependency(request: Request) -> User:
            # Resolve identity and role here rather than delegating to the
            # nested dependency in build_app: that dependency's own signature
            # takes an injected User, so calling it directly with a Request
            # silently substituted the Request for the user and blew up on
            # ``user.role``.
            state = request.app.state
            token = request.cookies.get(SESSION_COOKIE)
            username = read_token(token, state.auth.secret) if token else None
            user = state.auth.get_user(username) if username else None
            if user is None or user.disabled:
                raise HTTPException(status_code=401, detail="not signed in")
            if not Role.at_least(user.role, minimum):
                raise HTTPException(
                    status_code=403,
                    detail=f"role '{user.role}' cannot perform this; "
                           f"'{minimum}' or higher required")
            return user
        return dependency


_role_gate = _RoleGate()


def require_role_at(minimum: str) -> Callable:
    """Use in a product router: ``Depends(require_role_at(Role.ANALYST))``."""
    return _role_gate(minimum)


def severity_badge(severity: str) -> str:
    return f'<span class="badge b-{severity}">{severity}</span>'


def status_badge(status: str) -> str:
    label = {"recurred": "regressed", "accepted": "accepted"}.get(status, status)
    return f'<span class="badge b-{status}">{label}</span>'


def build_app(title: str, description: str,
              store: Optional[Store] = None,
              auth: Optional[AuthStore] = None,
              nav_products: Optional[list[tuple[str, str, str]]] = None,
              templates_dir: Optional[Path] = None) -> FastAPI:
    """
    Create the shared shell.

    Products pass their router in via ``include_router`` after this returns.
    """
    store = store or Store(DATA_DIR / "suite.db")
    auth = auth or AuthStore(DATA_DIR / "auth.db")
    templates = Jinja2Templates(directory=str(templates_dir or (BASE_DIR / "templates")))
    templates.env.globals.update(
        severity_badge=severity_badge, status_badge=status_badge, Role=Role)

    app = FastAPI(title=title, description=description, docs_url="/api/docs",
                  redoc_url=None)
    app.state.store = store
    app.state.auth = auth
    app.state.templates = templates

    if STATIC_DIR.exists():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    # -- auth wiring --------------------------------------------------

    def current_user(request: Request) -> Optional[User]:
        token = request.cookies.get(SESSION_COOKIE)
        if not token:
            return None
        username = read_token(token, auth.secret)
        user = auth.get_user(username) if username else None
        return user if user and not user.disabled else None

    def require_user(request: Request) -> User:
        user = current_user(request)
        if user is None:
            raise HTTPException(status_code=401, detail="not signed in")
        return user

    def require_role(minimum: str) -> Callable:
        """Dependency factory. Use as ``Depends(require_role(Role.ANALYST))``."""
        def dependency(user: User = Depends(require_user)) -> User:
            if not Role.at_least(user.role, minimum):
                raise HTTPException(
                    status_code=403,
                    detail=f"role '{user.role}' cannot perform this; "
                           f"'{minimum}' or higher required")
            return user
        return dependency

    app.state.require_user = require_user
    app.state.require_role = require_role
    app.state.current_user = current_user
    _role_gate.install(app)

    def render(request: Request, name: str, active: str, **ctx) -> HTMLResponse:
        user = current_user(request)
        if user is None:
            return RedirectResponse("/login", status_code=303)
        return templates.TemplateResponse(
            request, name,
            {"user": user, "active": active,
             "nav": nav_products if nav_products is not None else PRODUCTS,
             "css": NAV_CSS, **ctx})

    app.state.render = render
    app.state.templates_obj = templates

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        if request.url.path in ("/login", "/logout") or request.url.path.startswith("/admin"):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    # -- auth routes --------------------------------------------------

    @app.get("/login", response_class=HTMLResponse)
    async def login_page(request: Request):
        return templates.TemplateResponse(
            request, "login.html",
            {"error": None, "nav": nav_products or PRODUCTS, "css": NAV_CSS})

    @app.post("/login")
    async def login_submit(request: Request, username: str = Form(...),
                           password: str = Form(...)):
        ip = request.client.host if request.client else "unknown"
        limited, retry_after = _login_limited(ip)
        if limited:
            response = templates.TemplateResponse(
                request, "login.html",
                {"error": f"Too many sign-in attempts. Try again in about {retry_after} seconds.",
                 "username": username, "nav": nav_products or PRODUCTS, "css": NAV_CSS},
                status_code=429)
            response.headers["Retry-After"] = str(retry_after)
            return response
        user = auth.authenticate(username[:80], password)
        if user is None:
            return templates.TemplateResponse(
                request, "login.html",
                {"error": "Invalid username or password.", "username": username[:80],
                 "nav": nav_products or PRODUCTS, "css": NAV_CSS},
                status_code=401)
        _login_limited(ip, reset=True)
        response = RedirectResponse("/", status_code=303)
        response.set_cookie(
            SESSION_COOKIE, make_token(user.username, auth.secret),
            httponly=True, secure=os.getenv("SUITE_COOKIE_SECURE", "0").lower() in {"1", "true", "yes"},
            samesite="lax", max_age=60 * 60 * 12, path="/")
        return response

    @app.get("/admin/users", response_class=HTMLResponse)
    async def admin_users(request: Request):
        user = current_user(request)
        if user is None:
            return RedirectResponse("/login", status_code=303)
        if not Role.at_least(user.role, Role.ADMIN):
            return templates.TemplateResponse(request, "error.html",
                {"code": 403, "message": "Admin role required.", "nav": nav_products or PRODUCTS, "css": NAV_CSS}, status_code=403)
        return templates.TemplateResponse(request, "users.html",
            {"user": user, "users": auth.list_users(), "nav": nav_products or PRODUCTS, "css": NAV_CSS, "error": None, "success": None})

    @app.post("/admin/users")
    async def admin_create_user(request: Request, username: str = Form(...),
                                password: str = Form(...), role: str = Form("analyst")):
        actor = current_user(request)
        if actor is None:
            return RedirectResponse("/login", status_code=303)
        if not Role.at_least(actor.role, Role.ADMIN):
            raise HTTPException(status_code=403, detail="Admin role required")
        username = username.strip()
        if not username or len(username) > 80 or not all(c.isalnum() or c in "._-" for c in username):
            error = "Username must be 1–80 characters using letters, numbers, dot, underscore, or hyphen."
        else:
            error = None
        try:
            if error:
                raise ValueError(error)
            if len(password) < 12:
                raise ValueError("password must be at least 12 characters")
            auth.create_user(username, password, role)
        except ValueError as exc:
            return templates.TemplateResponse(request, "users.html",
                {"user": actor, "users": auth.list_users(), "nav": nav_products or PRODUCTS, "css": NAV_CSS, "error": str(exc), "success": None}, status_code=400)
        auth.audit(actor.username, "admin.user.create", f"username={username}; role={role}")
        return templates.TemplateResponse(request, "users.html",
            {"user": actor, "users": auth.list_users(), "nav": nav_products or PRODUCTS, "css": NAV_CSS, "error": None, "success": f"User {username} created."})

    @app.post("/admin/users/{username}/role")
    async def admin_update_role(request: Request, username: str, role: str = Form(...)):
        actor = current_user(request)
        if actor is None:
            return RedirectResponse("/login", status_code=303)
        if not Role.at_least(actor.role, Role.ADMIN):
            raise HTTPException(status_code=403, detail="Admin role required")
        target_user = auth.get_user(username)
        error = None
        if target_user is None:
            error = "User not found."
        elif role not in Role.ORDER:
            error = "Choose a valid role."
        elif username == actor.username and role != Role.ADMIN:
            error = "You cannot remove your own admin role."
        elif target_user.role == Role.ADMIN and role != Role.ADMIN and not target_user.disabled:
            active_admins = [u for u in auth.list_users() if u.role == Role.ADMIN and not u.disabled]
            if len(active_admins) <= 1:
                error = "The last active admin cannot be demoted."
        if error is None:
            auth.set_role(actor.username, username, role)
            auth.audit(actor.username, "admin.user.role", f"username={username}; role={role}")
            success = f"Updated {username} to {role}."
        else:
            success = None
        return templates.TemplateResponse(request, "users.html",
            {"user": actor, "users": auth.list_users(), "nav": nav_products or PRODUCTS, "css": NAV_CSS, "error": error, "success": success})

    @app.post("/admin/users/{username}/status")
    async def admin_update_status(request: Request, username: str, disabled: str = Form(...)):
        actor = current_user(request)
        if actor is None:
            return RedirectResponse("/login", status_code=303)
        if not Role.at_least(actor.role, Role.ADMIN):
            raise HTTPException(status_code=403, detail="Admin role required")
        target_user = auth.get_user(username)
        wants_disabled = disabled == "1"
        error = None
        if target_user is None:
            error = "User not found."
        elif username == actor.username and wants_disabled:
            error = "You cannot disable your own account."
        elif wants_disabled and target_user.role == Role.ADMIN and not target_user.disabled:
            active_admins = [u for u in auth.list_users() if u.role == Role.ADMIN and not u.disabled]
            if len(active_admins) <= 1:
                error = "The last active admin cannot be disabled."
        if error is None:
            auth.set_disabled(actor.username, username, wants_disabled)
            auth.audit(actor.username, "admin.user.status", f"username={username}; disabled={wants_disabled}")
            success = f"Updated account status for {username}."
        else:
            success = None
        return templates.TemplateResponse(request, "users.html",
            {"user": actor, "users": auth.list_users(), "nav": nav_products or PRODUCTS, "css": NAV_CSS, "error": error, "success": success})

    @app.post("/logout")
    async def logout():
        response = RedirectResponse("/login", status_code=303)
        # Clearing the cookie is all that "logout" does; see the module
        # docstring in auth.py about tokens remaining valid until expiry.
        response.delete_cookie(SESSION_COOKIE, path="/")
        return response

    @app.exception_handler(401)
    async def unauthenticated(request: Request, exc):
        if request.url.path.startswith("/api/"):
            return Response(content=b'{"detail":"not signed in"}',
                            media_type="application/json", status_code=401)
        return RedirectResponse("/login", status_code=303)

    @app.exception_handler(403)
    async def forbidden(request: Request, exc):
        # Product routers are mounted under /<product>/api/..., so the check has
        # to be for "/api/" anywhere in the path. Testing startswith("/api/")
        # served an HTML error page to a JSON client, which a CI script then
        # fails to parse.
        detail = getattr(exc, "detail", None) or "forbidden"
        if "/api/" in request.url.path:
            from fastapi.responses import JSONResponse
            return JSONResponse({"detail": str(detail)}, status_code=403)
        return templates.TemplateResponse(
            request, "error.html",
            {"code": 403, "message": str(detail),
             "nav": nav_products or PRODUCTS, "css": NAV_CSS},
            status_code=403)

    @app.exception_handler(404)
    async def not_found(request: Request, exc):
        detail = getattr(exc, "detail", None) or "not found"
        if "/api/" in request.url.path or request.url.path == "/health":
            from fastapi.responses import JSONResponse
            return JSONResponse({"detail": str(detail)}, status_code=404)
        return templates.TemplateResponse(
            request, "error.html",
            {"code": 404, "message": str(detail),
             "nav": nav_products or PRODUCTS, "css": NAV_CSS},
            status_code=404)

    return app


def require_auth(fn):
    """Decorator form for plain functions, for tests and scripts."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        return fn(*args, **kwargs)
    return wrapper