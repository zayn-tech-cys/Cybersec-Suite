"""
Scope-enforcing HTTP client.

Everything in this suite that touches the network goes through here, and this
is where the authorisation boundary lives. The rules:

* A target must be explicitly authorized before any request is sent.
* Every request URL must resolve inside the declared scope. A scanner that
  follows a redirect or a link off-host is both a bug and a legal problem.
* Rate limited, because pointing a scanner at a third-party host is how tools
  become abusive.
* Every exchange is recorded, so a finding's evidence is reproducible.

Refusing to leave scope is the single most important behaviour in this file.
"""

from __future__ import annotations

import ipaddress
import threading
import time
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urljoin, urlparse

import httpx


class ScopeError(Exception):
    """Raised when a request would leave the authorised scope."""


class AuthorizationError(Exception):
    """Raised when a target is not marked as authorised."""


@dataclass
class Exchange:
    """One recorded HTTP request/response, the evidence a finding is built on."""

    method: str
    url: str
    request_headers: dict = field(default_factory=dict)
    request_body: str = ""
    status_code: Optional[int] = None
    response_headers: dict = field(default_factory=dict)
    response_text: str = ""
    elapsed_ms: float = 0.0
    error: str = ""

    @property
    def ok(self) -> bool:
        return self.status_code is not None and 200 <= self.status_code < 400

    def to_dict(self) -> dict:
        return {
            "method": self.method, "url": self.url,
            "request_headers": self.request_headers,
            "request_body": self.request_body[:4000],
            "status_code": self.status_code,
            "response_headers": self.response_headers,
            "response_text": self.response_text[:4000],
            "elapsed_ms": round(self.elapsed_ms, 1),
            "error": self.error,
        }


class Scope:
    """
    The authorised boundary for a scan.

    ``allowed_hosts`` is the only thing that matters. Subdomains of an allowed
    host are permitted because a web application legitimately spans many hosts;
    anything resolving elsewhere is refused.
    """

    def __init__(self, base_url: str, allowed_hosts: Optional[list[str]] = None,
                 authorized: bool = False) -> None:
        parsed = urlparse(base_url)
        if parsed.scheme not in ("http", "https"):
            raise ScopeError(f"base_url must be http(s), got {parsed.scheme!r}")
        if not parsed.hostname:
            raise ScopeError(f"cannot determine host from {base_url!r}")

        self.base_url = base_url.rstrip("/")
        self.root_host = parsed.hostname.lower()
        self.authorized = authorized
        self.allowed_hosts = {h.lower().lstrip(".") for h in
                              (allowed_hosts or [self.root_host])}
        # Always allow the target itself, whatever the caller passed.
        self.allowed_hosts.add(self.root_host)

    def allows(self, host: str) -> bool:
        host = (host or "").lower().strip(".")
        if not host:
            return False
        if host in self.allowed_hosts:
            return True
        return any(host.endswith("." + allowed) for allowed in self.allowed_hosts)

    def check(self, url: str) -> None:
        """Raise unless ``url`` is inside scope."""
        host = urlparse(url).hostname or ""
        if not self.allows(host):
            raise ScopeError(
                f"{url} resolves to {host!r}, outside the authorised scope "
                f"({', '.join(sorted(self.allowed_hosts))})"
            )

    def join(self, path: str) -> str:
        return urljoin(self.base_url + "/", path.lstrip("/"))


class RateLimiter:
    """
    Leaky-bucket limiter: a burst allowance, then ``per_second`` steadily.

    Not fast, and that is the point. This is the difference between a tool that
    measures a target and one that is indistinguishable from a small DoS.

    Implemented as a token bucket with capacity ``burst`` refilled at
    ``per_second``. The earlier slot-based version set the next-slot time to
    ``now + interval * (burst - 1)``, which for ``burst=1`` is ``now`` -- so a
    limiter configured with no burst allowance allowed unlimited immediate
    requests, i.e. it silently did nothing in exactly the configuration used to
    demand strictest behaviour.
    """

    def __init__(self, per_second: float = 5.0, burst: int = 2) -> None:
        self.rate = max(0.0, per_second)
        self.burst = max(1, burst)
        self._tokens = float(self.burst)
        self._last = time.monotonic()
        self._lock = threading.Lock()
        self.waits = 0            # observable, so tests can assert it worked

    def wait(self) -> None:
        if self.rate <= 0:
            return
        while True:
            with self._lock:
                now = time.monotonic()
                # Refill for elapsed time, capped at the burst allowance.
                self._tokens = min(self.burst,
                                   self._tokens + (now - self._last) * self.rate)
                self._last = now
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return
                shortfall = 1.0 - self._tokens
                delay = shortfall / self.rate
            self.waits += 1
            time.sleep(min(delay, 1.0))


class SafeClient:
    """
    httpx wrapper that cannot leave its scope.

    Redirects are followed manually and each hop is scope-checked. Letting httpx
    follow redirects automatically would mean a single unchecked request to an
    off-site URL -- and an open redirect on the target would turn the scanner
    into a request amplifier pointed at someone else's server.
    """

    def __init__(self, scope: Scope, rate: Optional[RateLimiter] = None,
                 timeout: float = 10.0, verify: bool = False,
                 user_agent: str = "cybersec-suite/1.0 (authorized security testing)",
                 max_body: int = 2_000_000) -> None:
        if not scope.authorized:
            raise AuthorizationError(
                "target is not marked as authorized; refusing to send requests. "
                "Pass authorized=True only for systems you own or have written "
                "permission to test."
            )
        self.scope = scope
        self.rate = rate or RateLimiter()
        self.timeout = timeout
        self.max_body = max_body
        self.exchanges: list[Exchange] = []
        self._client = httpx.Client(
            timeout=timeout,
            verify=verify,
            follow_redirects=False,          # manual, so every hop is checked
            headers={"User-Agent": user_agent},
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "SafeClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -- requests --------------------------------------------------------

    def request(self, method: str, url: str, *, params: Optional[dict] = None,
                data: Optional[dict] = None, json_body: Optional[dict] = None,
                headers: Optional[dict] = None, follow: bool = True,
                max_redirects: int = 5) -> Exchange:
        """Perform a scoped request and record it."""
        target = url if urlparse(url).scheme else self.scope.join(url)
        self.scope.check(target)

        started = time.perf_counter()
        exchange = Exchange(method=method.upper(), url=target,
                           request_headers=dict(headers or {}))
        if params:
            exchange.request_body = str(params)
        if data:
            exchange.request_body = str(data)
        if json_body is not None:
            exchange.request_body = str(json_body)

        self.rate.wait()
        current = target
        for _hop in range(max_redirects + 1):
            self.scope.check(current)
            try:
                response = self._client.request(
                    method.upper(), current, params=params, data=data,
                    json=json_body, headers=headers,
                )
            except Exception as exc:
                exchange.error = f"{type(exc).__name__}: {exc}"
                break

            exchange.status_code = response.status_code
            exchange.response_headers = dict(response.headers)
            try:
                exchange.response_text = response.text[: self.max_body]
            except Exception:
                exchange.response_text = "<undecodable body>"

            location = response.headers.get("location")
            if follow and location and response.status_code in (301, 302, 303, 307, 308):
                nxt = urljoin(current, location)
                try:
                    self.scope.check(nxt)
                except ScopeError:
                    # Record the refusal rather than following it. An open
                    # redirect off-site is itself worth reporting.
                    exchange.response_headers["x-scope-blocked-redirect"] = nxt
                    break
                current = nxt
                continue
            break

        exchange.elapsed_ms = (time.perf_counter() - started) * 1000
        self.exchanges.append(exchange)
        return exchange

    def get(self, url: str, **kwargs) -> Exchange:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs) -> Exchange:
        return self.request("POST", url, **kwargs)

    def head(self, url: str, **kwargs) -> Exchange:
        return self.request("HEAD", url, **kwargs)

    def options(self, url: str, **kwargs) -> Exchange:
        return self.request("OPTIONS", url, **kwargs)

    # -- helpers ---------------------------------------------------------

    def probe_payload(self, url: str, payloads: list[str]) -> Optional[Exchange]:
        """
        Send each payload and return the first that reflects.

        This is how reflected-input checks confirm a finding rather than
        guessing: a payload appearing verbatim in the response is evidence.
        """
        for payload in payloads:
            candidate = url + ("&" if "?" in url else "?") + f"q={payload}"
            exchange = self.get(candidate)
            if exchange.status_code and payload in exchange.response_text:
                return exchange
        return None

    def last_for(self, detector: str) -> Optional[Exchange]:
        return self.exchanges[-1] if self.exchanges else None


def is_private_address(host: str) -> bool:
    """True if the host resolves to a private or reserved range."""
    try:
        return ipaddress.ip_address(host).is_private
    except ValueError:
        return False


def local_only(locator: str) -> bool:
    """
    Whether a locator points at the local machine.

    Used to require an extra acknowledgement before anything is scanned, since
    a loopback target is nearly always a deliberate lab setup and therefore
    almost certainly authorised -- but "almost certainly" is not the standard the
    suite holds itself to.
    """
    host = urlparse(locator).hostname or locator
    if host in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
        return True
    return is_private_address(host)


def describe_scope(scope: Scope) -> str:
    """One line explaining the boundary, printed at the start of every scan."""
    state = "AUTHORIZED" if scope.authorized else "NOT AUTHORIZED"
    hosts = ", ".join(sorted(scope.allowed_hosts))
    return f"target {scope.base_url} [{state}] allowing hosts: {hosts}"