"""
Risk scoring and prioritisation.

The problem this solves: scanners emit hundreds of findings and the operator has
no idea which to fix first. Raw severity is a poor sort key because it ignores
exploitability and ignores whether the endpoint is even reachable.

Scoring is therefore severity (base) x exploitability (multiplier) x exposure
(bonus), then a CVSS-like 0-10 number for familiar reporting. Deliberately
simple and inspectable -- every product prints the factors behind a score, so an
operator can disagree with the ranking and understand why.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional

from .models import Finding, Severity

# Base severity contribution, roughly aligned to CVSS bands.
BASE_SCORE = {
    Severity.CRITICAL: 9.5,
    Severity.HIGH: 7.5,
    Severity.MEDIUM: 5.0,
    Severity.LOW: 2.5,
    Severity.INFO: 0.5,
}

# Exploitability evidence -> multiplier. These are signals a machine can check
# for; absence of a signal is not proof of safety, only of lower confidence.
EXPLOIT_MULTIPLIER = {
    "publicly_reachable": 1.15,
    "unauthenticated": 1.20,
    "reflected_in_response": 1.15,
    "confirmed_by_probe": 1.25,
    "data_returned": 1.20,
    "state_changing": 1.10,
    "requires_authentication": 0.85,
    "requires_user_interaction": 0.75,
    "clickjacking_only": 0.70,
    "internal_hostname_only": 0.60,
}

# Exposure bonuses added after multiplication.
EXPOSURE_BONUS = {
    "internet_facing": 0.5,
    "handles_authentication": 0.4,
    "handles_payments": 0.5,
    "holds_personal_data": 0.4,
}


@dataclass
class RiskScore:
    """A score plus the arithmetic that produced it."""

    finding: Finding
    score: float
    severity: Severity
    cvss: float
    factors: list[str] = field(default_factory=list)
    rank: int = 0

    @property
    def explanation(self) -> str:
        if not self.factors:
            return "baseline severity only"
        return ", ".join(self.factors)


def score_finding(finding: Finding) -> RiskScore:
    """
    Score one finding.

    Exploitability signals are read from ``finding.tags``, which every detector
    sets. Keeping the signal in tags rather than a bespoke field means a new
    detector can contribute to prioritisation without touching this module.
    """
    score = BASE_SCORE[finding.severity]
    factors: list[str] = [f"base {score:.1f} ({finding.severity.value})"]

    tagset = {t.lower() for t in finding.tags}
    multiplier = 1.0
    for tag, factor in EXPLOIT_MULTIPLIER.items():
        if tag in tagset:
            multiplier *= factor
            factors.append(f"x{factor:.2f} {tag.replace('_', ' ')}")
    if multiplier != 1.0:
        score *= multiplier
        score = min(score, 10.0)

    bonus = 0.0
    for tag, value in EXPOSURE_BONUS.items():
        if tag in tagset:
            bonus += value
            factors.append(f"+{value:.1f} {tag.replace('_', ' ')}")
    score = min(score + bonus, 10.0)

    # Confidence softens a score we are not sure about. A likely-but-unproven
    # critical should not outrank a proven critical by much.
    confidence = max(0.0, min(1.0, finding.confidence))
    if confidence < 0.9:
        penalty = (1.0 - confidence) * 2.0
        score = max(score - penalty, 0.0)
        factors.append(f"-{penalty:.1f} confidence {confidence:.0%}")

    return RiskScore(
        finding=finding,
        score=round(score, 2),
        severity=finding.severity,
        cvss=round(cvss_from_score(score), 1),
        factors=factors,
    )


def cvss_from_score(score: float) -> float:
    """
    Map the 0-10 risk score onto a CVSS-shaped vector value.

    Not a real CVSS base score -- these are not CVSS vectors and must not be
    reported as one. It is a familiar 0-10 scale so the number means roughly
    what a reader expects, with the caveat documented wherever it is printed.
    """
    return max(0.0, min(10.0, score))


def prioritise(findings: Iterable[Finding], limit: Optional[int] = None) -> list[RiskScore]:
    """Score everything, sort worst-first, assign rank."""
    scored = [score_finding(f) for f in findings]
    scored.sort(key=lambda s: (-s.score, s.finding.title))
    for index, item in enumerate(scored, start=1):
        item.rank = index
    return scored[:limit] if limit else scored


def risk_summary(scored: list[RiskScore]) -> dict:
    """Dashboard-ready totals."""
    if not scored:
        return {"total": 0, "by_severity": {}, "average_score": 0.0,
                "highest": None, "actionable": 0}
    severities: dict[str, int] = {}
    for item in scored:
        severities[item.severity.value] = severities.get(item.severity.value, 0) + 1
    actionable = sum(1 for s in scored if s.severity <= Severity.MEDIUM)
    return {
        "total": len(scored),
        "by_severity": severities,
        "average_score": round(sum(s.score for s in scored) / len(scored), 2),
        "highest": scored[0].finding.title if scored else None,
        "highest_score": scored[0].score if scored else 0.0,
        # Anything medium or worse. This is the number an owner actually cares
        # about: how much work is on the table.
        "actionable": actionable,
    }


def gate(findings: Iterable[Finding], fail_on: Severity = Severity.HIGH) -> tuple[bool, list[str]]:
    """
    CI gate: does this result set fail?

    Returns ``(passed, reasons)``. Used by FixProof to fail a build. Compares
    on severity rank so ``fail_on=HIGH`` fails on critical and high but not
    medium.
    """
    failures: list[str] = []
    for finding in findings:
        if finding.severity.rank <= fail_on.rank:
            failures.append(f"[{finding.severity.value}] {finding.title} ({finding.location})")
    return (not failures), failures


def coverage_note(findings: list[Finding], expected_locations: set[str],
                  assessed: Optional[dict[str, list[str]]] = None,
                  total_pages: int = 0) -> str:
    """
    State what was tested, per check.

    A scanner that quietly skips a third of the endpoints and reports nothing
    about it is worse than one that says so, because the reader assumes the
    report is complete.

    ``assessed`` maps a check name to the URLs it actually ran against. When it
    is supplied the output is exact -- "reflection: 6 of 6" is a fact about the
    run. Without it the function falls back to comparing finding locations,
    which understates coverage badly: a page that was tested and returned
    nothing has no finding, so it would otherwise read as untested.

    Locations are compared on path-and-query, not the raw string. Detectors
    record a finding against ``/item?id`` while the crawler recorded
    ``http://host/item?id=1``, so comparing the strings verbatim reports every
    URL as uncovered.
    """
    def key(value: str) -> str:
        from urllib.parse import urlparse
        parsed = urlparse(value)
        path = parsed.path or "/"
        return f"{path}?{parsed.query}" if parsed.query else path

    if assessed:
        parts = []
        for check, urls in assessed.items():
            reached = len({key(u) for u in urls})
            parts.append(f"{check} {reached}")
        covered = f"assessed: {', '.join(parts)} page-check(s) run"
        skipped = [key(u) for u in expected_locations
                   if key(u) not in {key(x) for u2 in assessed.values() for x in u2}]
        if skipped:
            sample = ", ".join(sorted(set(skipped))[:4])
            more = (f" (+{len(set(skipped)) - 4} more)"
                    if len(set(skipped)) > 4 else "")
            covered += f"; never assessed: {sample}{more}"
        return covered

    seen = {key(f.location) for f in findings if f.location}
    missing = {key(loc) for loc in expected_locations} - seen
    total = {key(loc) for loc in expected_locations}
    if not missing:
        return f"all {len(total)} location(s) covered"
    sample = ", ".join(sorted(missing)[:5])
    more = f" (+{len(missing) - 5} more)" if len(missing) > 5 else ""
    return (f"{len(total) - len(missing)} of {len(total)} covered; "
            f"not assessed: {sample}{more}")