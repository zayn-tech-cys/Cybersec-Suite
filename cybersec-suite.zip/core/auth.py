"""
Authentication and role-based access control.

Scope: these tools are single-operator, local-first tools, so this is a
*minimum viable* auth layer, not an identity provider. It exists so that
"who ran this scan" is answerable and so a read-only viewer role is possible --
both of which matter for the audit story.

Honest limitations, stated plainly because a security tool that overstates its
own security is worse than one with no auth at all:

* PBKDF2-HMAC-SHA256 with a moderate iteration count, not Argon2id. Argon2id is
  the right answer; it is not in the standard library and this suite has no
  compiled dependencies.
* Sessions are HMAC-signed cookies, so logout does not invalidate a token that
  has already been issued. Fine for localhost, not for a shared deployment.
* Login attempts are throttled per source address in each server process. This
  does not coordinate across workers and resets on restart. There is no MFA or
  password-reset workflow.
* The default deployment binds to 127.0.0.1. Anyone exposing these dashboards
  to a network should put a real identity-aware proxy in front of them.

These limits are documented in the repository README so deployment operators
can make an informed decision.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

SESSION_COOKIE = "suite_session"
SESSION_TTL = 60 * 60 * 12          # 12 hours
PBKDF2_ROUNDS = 240_000


class Role:
    """Role names, ordered least to most privileged."""
    VIEWER = "viewer"        # read dashboards and reports, cannot start scans
    ANALYST = "analyst"      # can start scans and manage targets
    ADMIN = "admin"          # can create users and change roles

    ORDER = [VIEWER, ANALYST, ADMIN]

    @classmethod
    def at_least(cls, role: str, minimum: str) -> bool:
        try:
            return cls.ORDER.index(role) >= cls.ORDER.index(minimum)
        except ValueError:
            return False


@dataclass
class User:
    username: str
    role: str
    created_at: float
    disabled: bool = False


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username      TEXT PRIMARY KEY,
    salt          BLOB NOT NULL,
    password_hash BLOB NOT NULL,
    role          TEXT NOT NULL DEFAULT 'analyst',
    created_at    REAL NOT NULL,
    disabled      INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS audit_log (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    at       REAL NOT NULL,
    username TEXT NOT NULL,
    action   TEXT NOT NULL,
    detail   TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS audit_at ON audit_log(at DESC);
"""


def hash_password(password: str, salt: Optional[bytes] = None) -> tuple[bytes, bytes]:
    """PBKDF2-HMAC-SHA256. Returns (salt, hash)."""
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS
    )
    return salt, digest


def verify_password(password: str, salt: bytes, expected: bytes) -> bool:
    _, candidate = hash_password(password, salt)
    # Constant-time compare. A timing side channel on a password check is a
    # textbook finding and this suite should not ship one.
    return hmac.compare_digest(candidate, expected)


def make_token(username: str, secret: bytes, ttl: int = SESSION_TTL) -> str:
    """
    Build a signed session token: ``user|expiry|nonce|hmac``.

    Stateless, so logout cannot revoke it. Stated at the top of this module.
    """
    expiry = int(time.time()) + ttl
    nonce = secrets.token_hex(8)
    payload = f"{username}|{expiry}|{nonce}"
    sig = hmac.new(secret, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload}|{sig}"


def read_token(token: str, secret: bytes) -> Optional[str]:
    """Validate a token and return the username, or None."""
    try:
        username, expiry, nonce, sig = token.split("|")
    except ValueError:
        return None
    payload = f"{username}|{expiry}|{nonce}"
    expected = hmac.new(secret, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        return None
    try:
        if int(expiry) < time.time():
            return None
    except ValueError:
        return None
    return username


class AuthStore:
    """User records and the audit trail."""

    def __init__(self, path: Path | str, secret: Optional[bytes] = None) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = secret or self._load_or_create_secret()
        with self._connect() as conn:
            conn.executescript(SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=15)
        conn.row_factory = sqlite3.Row
        return conn

    def _load_or_create_secret(self) -> bytes:
        """
        The signing key lives next to the database.

        This means signing keys are not managed by a secret store, and copying
        the database also copies the ability to forge sessions. Called out in
        the README as a known weakness.
        """
        key_file = self.path.with_suffix(".secret")
        if key_file.exists():
            return key_file.read_bytes()
        secret = secrets.token_bytes(32)
        key_file.write_bytes(secret)
        try:                      # best effort on POSIX
            key_file.chmod(0o600)
        except OSError:
            pass
        return secret

    # -- users -----------------------------------------------------------

    def create_user(self, username: str, password: str,
                    role: str = Role.ANALYST) -> User:
        if role not in Role.ORDER:
            raise ValueError(f"unknown role {role!r}")
        if len(password) < 8:
            raise ValueError("password must be at least 8 characters")
        salt, digest = hash_password(password)
        now = time.time()
        try:
            with self._connect() as conn:
                conn.execute(
                    "INSERT INTO users(username, salt, password_hash, role,"
                    " created_at) VALUES (?, ?, ?, ?, ?)",
                    (username, salt, digest, role, now))
        except sqlite3.IntegrityError:
            # Surface a usable message instead of a raw UNIQUE constraint
            # failure, which tells an admin nothing about what to change.
            raise ValueError(f"user {username!r} already exists") from None
        self.audit(username, "user.create", f"role={role}")
        return User(username, role, now)

    def authenticate(self, username: str, password: str) -> Optional[User]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM users WHERE username = ?", (username,)
            ).fetchone()
        if row is None or row["disabled"]:
            # Hash anyway so a missing user and a wrong password take the same
            # time. Without this, response latency enumerates valid usernames.
            hash_password(password, b"\x00" * 16)
            return None
        if not verify_password(password, row["salt"], row["password_hash"]):
            self.audit(username, "login.failed", "bad password")
            return None
        self.audit(username, "login", "ok")
        return User(row["username"], row["role"], row["created_at"],
                    bool(row["disabled"]))

    def get_user(self, username: str) -> Optional[User]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT username, role, created_at, disabled FROM users"
                " WHERE username = ?", (username,)).fetchone()
        if row is None:
            return None
        return User(row["username"], row["role"], row["created_at"],
                    bool(row["disabled"]))

    def list_users(self) -> list[User]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT username, role, created_at, disabled FROM users"
                " ORDER BY username").fetchall()
        return [User(r["username"], r["role"], r["created_at"], bool(r["disabled"]))
                for r in rows]

    def set_role(self, actor: str, username: str, role: str) -> None:
        if role not in Role.ORDER:
            raise ValueError(f"unknown role {role!r}")
        with self._connect() as conn:
            conn.execute("UPDATE users SET role = ? WHERE username = ?",
                         (role, username))
        self.audit(actor, "user.role", f"{username} -> {role}")

    def set_disabled(self, actor: str, username: str, disabled: bool) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE users SET disabled = ? WHERE username = ?",
                         (int(disabled), username))
        self.audit(actor, "user.disable" if disabled else "user.enable", username)

    # -- audit -----------------------------------------------------------

    def audit(self, username: str, action: str, detail: str = "") -> None:
        """Append to the audit trail.

        Best-effort: an audit write failure must never abort the action being
        audited, but it is surfaced on stderr rather than swallowed.
        """
        try:
            with self._connect() as conn:
                conn.execute(
                    "INSERT INTO audit_log(at, username, action, detail)"
                    " VALUES (?, ?, ?, ?)",
                    (time.time(), username, action, detail))
        except sqlite3.Error as exc:
            import sys
            print(f"[audit] failed to record {action} by {username}: {exc}",
                  file=sys.stderr)

    def audit_log(self, limit: int = 200) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT at, username, action, detail FROM audit_log"
                " ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [{"at": r["at"], "username": r["username"],
                 "action": r["action"], "detail": r["detail"]} for r in rows]


def bootstrap(auth: AuthStore, admin_user: str = "admin",
              admin_password: Optional[str] = None) -> tuple[User, bool]:
    """
    Ensure an admin exists. Returns (user, created).

    A generated password is printed once. It is not recoverable afterwards,
    which is the correct behaviour for a credential this tool printed in a
    terminal -- a default password in a README is a default password forever.
    """
    if auth.get_user(admin_user):
        return auth.get_user(admin_user), False
    password = admin_password or secrets.token_urlsafe(12)
    user = auth.create_user(admin_user, password, Role.ADMIN)
    print("=" * 66)
    print(f"created admin user: {admin_user}")
    print(f"password: {password}")
    print("this is shown once and cannot be recovered -- save it now")
    print("=" * 66)
    return user, True