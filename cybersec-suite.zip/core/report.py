"""
Report rendering.

Three output formats because three different people read a security report:
an analyst debugging it (JSON), an engineer fixing it (HTML), and a manager
deciding whether to ship (the HTML summary page).

The HTML is written by hand rather than with a template engine. It has to be
self-contained -- one file, no external CSS, no CDN -- because a report gets
emailed and archived, and a report that renders as unstyled text in six months
is not a report anyone acted on.
"""

from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from typing import Optional

from .models import Finding, Severity
from .risk import RiskScore, prioritise, risk_summary

SEVERITY_COLOURS = {
    Severity.CRITICAL.value: "#b3261e",
    Severity.HIGH.value: "#d97706",
    Severity.MEDIUM.value: "#ca8a04",
    Severity.LOW.value: "#2563eb",
    Severity.INFO.value: "#64748b",
}

_SEVERITY_ORDER = [s.value for s in Severity]


def report_json(findings: list[Finding], target: str = "",
                product: str = "", meta: Optional[dict] = None) -> str:
    """Machine-readable report, including the prioritisation."""
    scored = prioritise(findings)
    return json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "target": target,
        "product": product,
        "meta": meta or {},
        "summary": risk_summary(scored),
        "findings": [
            {**s.finding.to_dict(), "risk_score": s.score, "rank": s.rank,
             "score_factors": s.factors}
            for s in scored
        ],
    }, indent=2, default=str)


def _e(text: str) -> str:
    """HTML-escape. Finding text is attacker-influenced: a reflected payload
    inside an XSS finding title would otherwise become stored XSS in the
    report viewer, which is a genuinely embarrassing bug in a security tool."""
    return html.escape(str(text), quote=True)


_STYLE = """
:root{--bg:#0f172a;--panel:#1e293b;--line:#334155;--fg:#e2e8f0;--dim:#94a3b8}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
 font:15px/1.55 ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.wrap{max-width:1100px;margin:0 auto;padding:32px 20px 80px}
h1{font-size:24px;margin:0 0 4px}
h2{font-size:17px;margin:32px 0 12px;border-bottom:1px solid var(--line);
 padding-bottom:6px}
.sub{color:var(--dim);font-size:13px;margin:0 0 24px}
.cards{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:8px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;
 padding:14px 18px;min-width:130px}
.card .n{font-size:26px;font-weight:650;letter-spacing:-.5px}
.card .l{color:var(--dim);font-size:12px;text-transform:uppercase;
 letter-spacing:.6px}
table{width:100%;border-collapse:collapse;background:var(--panel);
 border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);
 vertical-align:top;font-size:14px}
th{background:#172033;color:var(--dim);font-size:12px;text-transform:uppercase;
 letter-spacing:.5px}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;
 font-weight:650;letter-spacing:.4px;color:#fff;text-transform:uppercase}
.loc{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;
 color:var(--dim)}
.score{font-family:ui-monospace,monospace;font-weight:650}
details{margin-top:8px}
summary{cursor:pointer;color:#93c5fd;font-size:13px}
pre{background:#0b1220;border:1px solid var(--line);border-radius:8px;
 padding:12px;overflow:auto;font-size:12px;line-height:1.5;
 font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
 white-space:pre-wrap;word-break:break-word;max-height:340px}
.muted{color:var(--dim)}
.empty{background:var(--panel);border:1px dashed var(--line);border-radius:10px;
 padding:28px;text-align:center;color:var(--dim)}
.note{background:#1c2333;border-left:3px solid #d97706;border-radius:6px;
 padding:12px 16px;color:#cbd5e1;font-size:13px;margin:16px 0}
.factors{color:var(--dim);font-size:12px;margin-top:3px}
"""

JS = """
function f(id){var e=document.getElementById(id);if(e){e.style.display=e.style.display==='none'?'block':'none';}}
function sev(v){return document.querySelectorAll('[data-sev="'+v+'"]').length;}
function only(v){
  document.querySelectorAll('tr[data-sev]').forEach(function(r){
    r.style.display=(v==='all'||r.dataset.sev===v)?'':'none';});
  ['all'].concat(%s).forEach(function(k){
    var b=document.getElementById('f-'+k); if(b) b.classList.toggle('on',k===v);});
  var total=document.querySelectorAll('tr[data-sev]').length;
  var shown=document.querySelectorAll('tr[data-sev]:not([style*="display: none"])').length;
  var c=document.getElementById('shown'); if(c) c.textContent=shown+' of '+total;
}
"""


def report_html(findings: list[Finding], target: str = "", product: str = "",
                meta: Optional[dict] = None, title: str = "Security Report") -> str:
    """Self-contained HTML report with severity filters and expandable evidence."""
    scored: list[RiskScore] = prioritise(findings)
    summary = risk_summary(scored)
    meta = meta or {}
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    cards = []
    for sev in _SEVERITY_ORDER:
        n = summary["by_severity"].get(sev, 0)
        cards.append(
            f'<div class="card"><div class="n" style="color:'
            f'{SEVERITY_COLOURS[sev]}">{n}</div>'
            f'<div class="l">{sev}</div></div>')
    cards.append(f'<div class="card"><div class="n">{summary["actionable"]}</div>'
                 f'<div class="l">actionable</div></div>')
    cards.append(f'<div class="card"><div class="n">{summary["average_score"]}</div>'
                 f'<div class="l">avg risk</div></div>')

    if scored:
        rows = []
        for item in scored:
            f = item.finding
            ev = f.evidence
            evidence = ""
            if ev.request or ev.response:
                evidence = (
                    f'<details><summary>evidence</summary><pre>'
                    f'{_e(ev.request)}\n\n{"=" * 60}\n\n{_e(ev.response)}'
                    f'</pre></details>')
            refs = ""
            if f.references:
                links = " ".join(
                    f'<a href="{_e(r)}" style="color:#93c5fd" '
                    f'target="_blank" rel="noopener">{_e(r)}</a>'
                    for r in f.references)
                refs = f'<div class="muted" style="font-size:12px;margin-top:6px">{links}</div>'
            impact = (f'<div style="margin-top:6px"><b>Impact:</b> {_e(f.impact)}</div>'
                      if f.impact else "")
            fix = (f'<div style="margin-top:6px"><b>Fix:</b> {_e(f.remediation)}</div>'
                   if f.remediation else "")
            desc = f'<div class="muted">{_e(f.description)}</div>' if f.description else ""
            rows.append(
                f'<tr data-sev="{f.severity.value}">'
                f'<td><span class="badge" style="background:'
                f'{SEVERITY_COLOURS[f.severity.value]}">{f.severity.value}</span>'
                f'<div class="factors">{item.score} risk / cvss {item.cvss}</div>'
                f'<div class="factors">{_e(item.explanation)}</div></td>'
                f'<td><b>#{item.rank} {_e(f.title)}</b>{desc}'
                f'<div class="loc">{_e(f.location)}</div>{impact}{fix}{refs}{evidence}</td>'
                f'<td class="loc">{_e(f.category)}</td></tr>')
        table = (
            '<table><thead><tr><th style="width:170px">Severity</th>'
            '<th>Finding</th><th style="width:180px">Category</th></tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table>')
    else:
        table = ('<div class="empty">No findings. Either the target is clean, or '
                 'nothing was tested &mdash; check the scope below before '
                 'believing this.</div>')

    filters = ['<button id="f-all" class="on" onclick="only(\'all\')">all</button>']
    for sev in _SEVERITY_ORDER:
        filters.append(
            f'<button id="f-{sev}" onclick="only(\'{sev}\')">{sev}</button>')

    meta_rows = "".join(
        f'<tr><td class="loc">{_e(k)}</td><td>{_e(v)}</td></tr>'
        for k, v in meta.items())

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(title)}</title><style>{_STYLE}</style></head><body><div class="wrap">
<h1>{_e(title)}</h1>
<p class="sub">{_e(product or 'cybersec-suite')} &middot; target
<b>{_e(target or 'n/a')}</b> &middot; generated {generated}</p>
<div class="cards">{''.join(cards)}</div>
<div class="note">Risk score is a 0&ndash;10 internal prioritisation number, not a
CVSS base score. The &ldquo;cvss&rdquo; column is that same number on a CVSS-shaped
scale for familiar reporting. Verify every finding before acting on it.</div>
<h2>Findings</h2>
<p class="sub">{''.join(filters)}
&nbsp;&nbsp;<span id="shown">{len(scored)}</span> shown
&nbsp;&middot;&nbsp; click a row's <b>evidence</b> to see the raw exchange</p>
{table}
<h2>Scan details</h2>
<table><tbody>{meta_rows}</tbody></table>
</div><script>{JS % json.dumps(_SEVERITY_ORDER)}</script></body></html>"""


def severity_chart(counts: dict[str, int]) -> str:
    """Inline stacked bar. Avoids pulling in a charting library."""
    total = sum(counts.values()) or 1
    parts = []
    for sev in _SEVERITY_ORDER:
        n = counts.get(sev, 0)
        if not n:
            continue
        pct = n / total * 100
        parts.append(
            f'<div style="width:{pct:.2f}%;background:{SEVERITY_COLOURS[sev]}'
            f'" title="{sev}: {n}"></div>')
    return ('<div style="display:flex;height:12px;border-radius:6px;overflow:hidden;'
            f'border:1px solid var(--line)">{"".join(parts)}</div>')

def report_pdf(findings: list[Finding], target: str = "", product: str = "",
               meta: Optional[dict] = None) -> bytes:
    """Create a self-contained PDF security report using ReportLab.

    All attacker-controlled strings are XML-escaped before being passed to
    ReportLab Paragraph, which interprets a small markup language.
    """
    from io import BytesIO
    from xml.sax.saxutils import escape
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle, KeepTogether)

    scored = prioritise(findings)
    summary = risk_summary(scored)
    output = BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=17*mm,
                            leftMargin=17*mm, topMargin=16*mm, bottomMargin=16*mm,
                            title=f"{product or 'Security'} Report",
                            author="CyberSec Suite")
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="SmallMuted", parent=styles["BodyText"],
                              fontSize=8, leading=10, textColor=colors.HexColor("#475569")))
    styles.add(ParagraphStyle(name="FindingTitle", parent=styles["Heading3"],
                              fontSize=10, leading=13, spaceAfter=3))
    story = [Paragraph("CyberSec Suite — Security Assessment", styles["Title"]),
             Paragraph(f"Product: {escape(str(product or 'n/a'))} &nbsp; | &nbsp; Target: {escape(str(target or 'n/a'))}", styles["BodyText"]),
             Spacer(1, 5*mm)]
    story.append(Paragraph("Executive summary", styles["Heading2"]))
    rows = [["Severity", "Count"]]
    for sev in _SEVERITY_ORDER:
        rows.append([sev.title(), str(summary["by_severity"].get(sev, 0))])
    rows.extend([["Actionable findings", str(summary["actionable"])],
                 ["Average risk score", str(summary["average_score"]) ]])
    summary_table = Table(rows, colWidths=[95*mm, 35*mm], repeatRows=1)
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#172554")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), .35, colors.HexColor("#cbd5e1")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f8fafc")]),
        ("PADDING", (0,0), (-1,-1), 6),
    ]))
    story.extend([summary_table, Spacer(1, 5*mm)])
    story.append(Paragraph("Findings", styles["Heading2"]))
    if not scored:
        story.append(Paragraph("No findings were recorded. Confirm scan coverage before interpreting this as a clean result.", styles["BodyText"]))
    for index, item in enumerate(scored, 1):
        finding = item.finding
        severity = escape(str(finding.severity.value).upper())
        heading = Paragraph(f"{index}. [{severity}] {escape(str(finding.title))}", styles["FindingTitle"])
        details = [heading,
                   Paragraph(f"Location: {escape(str(finding.location or 'n/a'))} &nbsp; | &nbsp; Risk score: {escape(str(item.score))} &nbsp; | &nbsp; Status: {escape(str(finding.status.value))}", styles["SmallMuted"])]
        if finding.description:
            details.append(Paragraph(f"<b>Description:</b> {escape(str(finding.description))}", styles["BodyText"]))
        if finding.impact:
            details.append(Paragraph(f"<b>Impact:</b> {escape(str(finding.impact))}", styles["BodyText"]))
        if finding.remediation:
            details.append(Paragraph(f"<b>Recommended fix:</b> {escape(str(finding.remediation))}", styles["BodyText"]))
        if finding.evidence and (finding.evidence.request or finding.evidence.response):
            evidence = (finding.evidence.request + "\n\n--- response ---\n\n" + finding.evidence.response)[:2500]
            details.append(Paragraph(f"<b>Evidence (truncated):</b> {escape(evidence).replace(chr(10), '<br/>')}", styles["SmallMuted"]))
        details.append(Spacer(1, 4*mm))
        story.append(KeepTogether(details))
    if meta:
        story.append(Paragraph("Scan details", styles["Heading2"]))
        meta_rows = [[Paragraph(escape(str(k)), styles["SmallMuted"]),
                      Paragraph(escape(str(v))[:1000], styles["SmallMuted"])]
                     for k, v in meta.items()]
        detail_table = Table(meta_rows, colWidths=[45*mm, 125*mm])
        detail_table.setStyle(TableStyle([("GRID", (0,0), (-1,-1), .3, colors.HexColor("#cbd5e1")),
                                          ("VALIGN", (0,0), (-1,-1), "TOP"),
                                          ("PADDING", (0,0), (-1,-1), 5)]))
        story.append(detail_table)
    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawString(17*mm, 9*mm, "Confidential — use only for authorized security assessments")
        canvas.drawRightString(A4[0] - 17*mm, 9*mm, f"Page {document.page}")
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()
