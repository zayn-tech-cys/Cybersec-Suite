"""
Common data model shared by all five products.

Every product produces :class:`Finding` objects. Keeping the shape identical
across five separate scanners is what lets the reporting, storage, dedup and
regression-tracking code be written once instead of five times -- and it is why a
finding found by AutoPentest can be handed straight to FixProof.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


def utcnow() -> str:
    """ISO-8601 UTC timestamp. Single source of truth so sorting is reliable."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Severity(str, Enum):
    """Ordered severity levels. Order matters for sorting and for gates."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"

    @property
    def rank(self) -> int:
        return _SEVERITY_ORDER[self]

    @property
    def cvss_floor(self) -> float:
        """Rough CVSS band this severity corresponds to."""
        return _SEVERITY_CVSS[self]

    def __lt__(self, other: "Severity") -> bool:
        if not isinstance(other, Severity):
            return NotImplemented
        return self.rank < other.rank


_SEVERITY_ORDER = {
    Severity.CRITICAL: 0,
    Severity.HIGH: 1,
    Severity.MEDIUM: 2,
    Severity.LOW: 3,
    Severity.INFO: 4,
}

_SEVERITY_CVSS = {
    Severity.CRITICAL: 9.0,
    Severity.HIGH: 7.0,
    Severity.MEDIUM: 4.0,
    Severity.LOW: 0.1,
    Severity.INFO: 0.0,
}


class Status(str, Enum):
    """Lifecycle of a finding across scans. This is what makes regressions visible."""

    OPEN = "open"            # present in the most recent scan
    FIXED = "fixed"          # was open, now absent
    RECURRED = "recurred"    # was fixed, now present again -- a regression
    ACCEPTED = "accepted"    # risk-accepted by an operator, not a real fix

    @property
    def is_problem(self) -> bool:
        return self in (Status.OPEN, Status.RECURRED)


@dataclass
class Evidence:
    """
    Proof a finding is real.

    ``request`` and ``response`` are stored verbatim. A security report without
    reproducible evidence is an opinion, and the difference between a scanner
    and a pentest is whether anyone can re-run the proof.
    """

    request: str = ""
    response: str = ""
    status_code: Optional[int] = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Finding:
    """
    One security issue, normalised so all five products emit the same shape.

    ``fingerprint`` is what makes deduplication and regression detection work:
    it is a hash of the stable identity of the issue (what kind, where, what
    signal) and deliberately excludes volatile fields such as timestamps and
    response bodies, so the same bug hashes identically on every scan.
    """

    title: str
    severity: Severity
    category: str                       # OWASP-style category, e.g. "A01:2021 Broken Access Control"
    target: str                         # what was tested: host, spec path, asset, repo
    description: str = ""
    impact: str = ""
    remediation: str = ""
    location: str = ""                  # endpoint, file:line, host:port, resource id
    evidence: Evidence = field(default_factory=Evidence)
    # Optional fields used by specific products.
    detector: str = ""                  # which check produced it
    confidence: float = 1.0             # 0..1, distinct from severity
    references: list[str] = field(default_factory=list)
    product: str = ""                   # which product emitted it
    # Structured data for machine consumption (CWE, rule id, regression test id...).
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""
    first_seen: str = field(default_factory=utcnow)
    last_seen: str = field(default_factory=utcnow)
    status: Status = Status.OPEN
    scan_id: Optional[int] = None

    def __post_init__(self) -> None:
        if not self.fingerprint:
            self.fingerprint = self.compute_fingerprint()

    def compute_fingerprint(self) -> str:
        """
        Stable identity hash.

        Only fields that identify *which issue this is* take part. Timestamps,
        response bodies and status text vary between runs and would produce a
        different hash every scan, defeating dedup and regression detection.
        """
        parts = [
            self.detector or self.category,
            self.location or self.target,
            _normalise_title(self.title),
        ]
        raw = "|".join(parts)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

    def to_dict(self) -> dict:
        data = asdict(self)
        data["severity"] = self.severity.value
        data["status"] = self.status.value
        data["evidence"] = self.evidence.to_dict()
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "Finding":
        evidence = Evidence(**(data.get("evidence") or {}))
        payload = {k: v for k, v in data.items() if k not in ("evidence", "severity", "status")}
        payload["evidence"] = evidence
        payload["severity"] = Severity(data.get("severity", "info"))
        payload["status"] = Status(data.get("status", "open"))
        return cls(**payload)


def _normalise_title(title: str) -> str:
    """Lowercase, strip digits and punctuation, so wording drift is tolerated.

    "Missing X-Frame-Options on /admin (v2)" and "Missing X-Frame-Options on
    /admin" must hash the same, or every rescan looks like a new finding.
    """
    keep = [c.lower() for c in title if c.isalpha()]
    return "".join(keep)


def dedupe(findings: list[Finding]) -> list[Finding]:
    """
    Collapse findings that share a fingerprint.

    When duplicates are found the more severe instance wins, and evidence from
    each is merged into ``metadata['also_seen_at']`` rather than discarded --
    two hosts hitting the same bug is worth reporting as two.
    """
    merged: dict[str, Finding] = {}
    for finding in findings:
        existing = merged.get(finding.fingerprint)
        if existing is None:
            merged[finding.fingerprint] = finding
            continue
        if finding.severity < existing.severity:
            finding.metadata.setdefault("also_seen_at", list(existing.metadata.get("also_seen_at", [])))
            if existing.location != finding.location:
                finding.metadata["also_seen_at"].append(existing.location)
            merged[finding.fingerprint] = finding
        else:
            existing.metadata.setdefault("also_seen_at", [])
            if finding.location != existing.location:
                existing.metadata["also_seen_at"].append(finding.location)
    return sorted(merged.values(), key=lambda f: (f.severity, f.title))


def compare_scans(previous: list[Finding], current: list[Finding]
                  ) -> dict[str, list[Finding]]:
    """
    Diff two scans by fingerprint.

    Returns new, persisting, fixed and recurring. "Recurring" is separated from
    "new" because a bug that was fixed and has come back is a different and much
    worse signal than a bug never seen before -- and conflating them hides
    exactly the failure mode FixProof exists to catch.
    """
    prev = {f.fingerprint: f for f in previous}
    curr = {f.fingerprint: f for f in current}

    new = [f for key, f in curr.items() if key not in prev]
    persisting = [f for key, f in curr.items() if key in prev]
    fixed = [f for key, f in prev.items() if key not in curr]
    recurring = [
        f for f in persisting
        if prev[f.fingerprint].status is Status.FIXED
    ]
    return {
        "new": new,
        "persisting": [f for f in persisting if f not in recurring],
        "fixed": fixed,
        "recurring": recurring,
    }


def severity_counts(findings: list[Finding]) -> dict[str, int]:
    counts = {s.value: 0 for s in Severity}
    for finding in findings:
        counts[finding.severity.value] += 1
    return counts


def to_json(findings: list[Finding], indent: int = 2) -> str:
    return json.dumps([f.to_dict() for f in findings], indent=indent, default=str)