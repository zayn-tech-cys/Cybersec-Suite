"""
APIShield web interface: identity setup, scan control, findings, reports.

The identity configuration is the centre of this UI, because everything the
tool concludes depends on it. It is deliberately prominent and editable --
a BOLA result from a single identity is not a result, and the operator should
have to think about that rather than have it buried in a log.
"""

from __future__ import annotations

import html
import json
from typing import Optional
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from core.auth import Role
from core.models import Finding, Severity
from core.report import report_html, report_json, report_pdf, severity_chart
from core.risk import prioritise, risk_summary
from core.web import require_role_at

from .engine import PRODUCT, Identity, ScanConfig, scan

router = APIRouter()

# How many identities to keep between runs. Session-bound is overkill for a
# local tool; a module-level list matches how the CLI works and keeps the
# dashboard stateless.
IDENTITIES: list[Identity] = []


def _store(request: Request):
    return request.app.state.store


def _e(value) -> str:
    return html.escape(str(value), quote=True)


def _target_for(request: Request, url: str) -> Optional[dict]:
    return _store(request).find_target("api", url.rstrip("/"))


# -- pages ---------------------------------------------------------------

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    render = request.app.state.render
    store = _store(request)
    rows = []
    for target in store.list_targets():
        if target["kind"] != "api":
            continue
        stats = store.stats(target["id"], PRODUCT)
        rows.append({"target": target, "stats": stats,
                     "scan": store.previous_scan(target["id"], PRODUCT)})

    return render(request, "apishield_dashboard.html", "apishield",
                  page="dashboard", rows=rows, identities=IDENTITIES,
                  has_identities=bool(any(not i.is_anonymous
                                           for i in IDENTITIES)))


@router.get("/target/{target_id}", response_class=HTMLResponse)
async def target_detail(request: Request, target_id: int):
    render = request.app.state.render
    store = _store(request)
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)

    findings = store.latest_findings(target_id, PRODUCT)
    scored = prioritise(findings)
    stats = store.stats(target_id, PRODUCT)

    by_detector: dict[str, int] = {}
    for finding in findings:
        by_detector[finding.detector] = by_detector.get(finding.detector, 0) + 1

    last = store.previous_scan(target_id, PRODUCT)
    return render(request, "apishield_target.html", "apishield", page="target",
                  target=target, scored=scored, stats=stats,
                  summary=risk_summary(scored), by_detector=by_detector,
                  severity_counts=stats["by_severity"],
                  chart=severity_chart(stats["by_severity"]),
                  identities=IDENTITIES,
                  coverage=(last.get("summary") or {}).get("coverage"),
                  spec_source=(last.get("summary") or {}).get("spec_source"))


@router.get("/target/{target_id}/report", response_class=HTMLResponse)
async def report(request: Request, target_id: int, fmt: str = "html",
                 user=Depends(require_role_at(Role.VIEWER))):
    store = _store(request)
    target = store.get_target(target_id)
    if target is None:
        return HTMLResponse("target not found", status_code=404)
    findings = store.latest_findings(target_id, PRODUCT)
    meta = {"target": target["locator"], "product": PRODUCT,
            "identities used": ", ".join(i.name for i in IDENTITIES) or "none"}
    if fmt == "pdf":
        pdf = report_pdf(findings, target["locator"], PRODUCT, meta)
        safe_product = "".join(c for c in PRODUCT.lower() if c.isalnum() or c in "-_") or "security"
        return Response(pdf, media_type="application/pdf", headers={
            "Content-Disposition": f'attachment; filename="{safe_product}-report-{target_id}.pdf"',
            "X-Content-Type-Options": "nosniff",
        })
    if fmt == "json":
        return HTMLResponse(report_json(findings, target["locator"], PRODUCT, meta),
                            media_type="application/json")
    return HTMLResponse(report_html(findings, target["locator"], PRODUCT, meta,
                                    title="APIShield Report"))


# -- identity management -------------------------------------------------

@router.post("/identities")
async def save_identities(request: Request,
                          payload: str = Form(...),
                          user=Depends(require_role_at(Role.ANALYST))):
    """
    Replace the identity set from a JSON textarea.

    JSON rather than a repeating form because the shape is nested (per-identity
    headers with arbitrary keys), and a form that fakes nesting is a form that
    drops data.
    """
    global IDENTITIES
    try:
        raw = json.loads(payload)
        if not isinstance(raw, list):
            raise ValueError("expected a JSON list of identities")
    except json.JSONDecodeError as exc:
        return HTMLResponse(
            f"<h1>Invalid JSON</h1><p>{_e(exc)}</p>"
            f"<p><a href='/apishield/'>back</a></p>", status_code=400)

    parsed: list[Identity] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        if not name:
            continue
        headers = item.get("headers") or {}
        if not isinstance(headers, dict):
            continue
        parsed.append(Identity(
            name=name,
            headers={str(k): str(v) for k, v in headers.items()},
            role=str(item.get("role", "user")),
            privilege=int(item.get("privilege", 1)),
            note=str(item.get("note", "")),
        ))
    IDENTITIES = parsed
    request.app.state.auth.audit(user.username, "apishield.identities",
                                 f"{len(parsed)} identity/identities")
    return RedirectResponse("/apishield/", status_code=303)


# -- running a scan ------------------------------------------------------

@router.post("/run")
async def run(request: Request, url: str = Form(...),
              confirm_authorized: str = Form(""),
              rate: float = Form(5.0),
              user=Depends(require_role_at(Role.ANALYST))):
    store = _store(request)
    url = url.strip().rstrip("/")
    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    if confirm_authorized != "yes":
        return HTMLResponse(
            f"<h1>Authorization required</h1>"
            f"<p>APIShield sends real requests carrying real credentials. "
            f"Confirm you are authorized to test <b>{_e(url)}</b>.</p>"
            f"<form method='post' action='/apishield/run'>"
            f"<input type='hidden' name='url' value='{_e(url)}'>"
            f"<label><input type='checkbox' name='confirm_authorized' "
            f"value='yes' checked style='width:auto'> I am authorized</label>"
            f"<p><button class='btn primary'>Run scan</button></p></form>",
            status_code=400)

    if not IDENTITIES:
        return HTMLResponse(
            "<h1>No identities configured</h1>"
            "<p>APIShield needs at least one authenticated identity. With only "
            "anonymous access it cannot test BOLA or BFLA, and reporting "
            "'nothing found' would be meaningless.</p>"
            "<p><a class='btn' href='/apishield/'>Configure identities</a></p>",
            status_code=400)

    target = _target_for(request, url)
    target_id = (target["id"] if target else
                 store.add_target(urlparse(url).hostname or url, "api", url,
                                  authorized=True))

    scan_id = store.start_scan(target_id, PRODUCT)
    try:
        result = scan(url, IDENTITIES, authorized=True,
                      config=ScanConfig(rate_per_second=max(0.5, min(rate, 25.0))),
                      log=lambda *a: None)
        diff = store.record_scan(scan_id, target_id, PRODUCT, result.findings)
        store.finish_scan(scan_id, "completed", {**result.summary(), **diff})
    except Exception as exc:
        store.finish_scan(scan_id, "failed", {}, error=str(exc))
        return HTMLResponse(f"<h1>Scan failed</h1><p>{_e(exc)}</p>",
                            status_code=500)

    return RedirectResponse(f"/apishield/target/{target_id}", status_code=303)


# -- JSON API ------------------------------------------------------------

@router.get("/api/targets")
async def api_targets(request: Request):
    store = _store(request)
    return {"targets": [
        {"id": t["id"], "url": t["locator"],
         "stats": store.stats(t["id"], PRODUCT)}
        for t in store.list_targets() if t["kind"] == "api"]}


@router.get("/api/targets/{target_id}/findings")
async def api_findings(request: Request, target_id: int):
    store = _store(request)
    scored = prioritise(store.latest_findings(target_id, PRODUCT))
    return {
        "summary": risk_summary(scored),
        "findings": [{**s.finding.to_dict(), "risk_score": s.score}
                     for s in scored],
    }


@router.post("/api/scan")
async def api_scan(request: Request, url: str, rate: float = 5.0,
                   user=Depends(require_role_at(Role.ANALYST))):
    store = _store(request)
    url = url.rstrip("/")
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    if not IDENTITIES:
        return {"error": "no identities configured; call POST /apishield/"
                         "identities or use the dashboard first"}
    target = _target_for(request, url)
    target_id = (target["id"] if target else
                 store.add_target(urlparse(url).hostname or url, "api", url,
                                  authorized=True))
    scan_id = store.start_scan(target_id, PRODUCT)
    try:
        result = scan(url, IDENTITIES, authorized=True,
                      config=ScanConfig(rate_per_second=rate),
                      log=lambda *a: None)
        diff = store.record_scan(scan_id, target_id, PRODUCT, result.findings)
        store.finish_scan(scan_id, "completed", {**result.summary(), **diff})
    except Exception as exc:
        store.finish_scan(scan_id, "failed", {}, error=str(exc))
        return {"error": str(exc), "scan_id": scan_id}
    return {"scan_id": scan_id, "diff": diff, "summary": result.summary()}