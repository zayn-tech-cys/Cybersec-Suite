#!/usr/bin/env python
"""
APIShield command line.

    python -m apishield.cli http://localhost:8000 --yes \\
        --identity alice:1:user:1 --identity bob:2:user:1 --identity root:9:admin:3

Identity format: ``name:header_value:role:privilege``, using the target's
convention for identifying a user. The header name defaults to ``x-user-id``
and can be changed with ``--header``.

Identities are passed on the command line, which means they land in shell
history and process listings. That is a real limitation, stated here and in the
README rather than hidden -- for anything beyond a lab, use the dashboard or
supply them through an environment variable.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from apishield.engine import Identity, ScanConfig, scan            # noqa: E402
from core.models import Severity                                   # noqa: E402
from core.report import report_html, report_json                   # noqa: E402
from core.risk import gate, prioritise, risk_summary               # noqa: E402
from core.storage import Store                                     # noqa: E402

COLOURS = {
    "critical": "\033[41;97m", "high": "\033[43;30m", "medium": "\033[43;30m",
    "low": "\033[46;30m", "info": "\033[100;30m", "reset": "\033[0m",
    "dim": "\033[2m", "bold": "\033[1m",
}


def colour(text: str, name: str, enabled: bool) -> str:
    return f"{COLOURS.get(name,'')}{text}{COLOURS['reset']}" if enabled else text


def parse_identity(spec: str, header_name: str) -> Identity:
    """
    ``name:value:role:privilege`` or just ``name`` (anonymous).

    Colons cannot appear inside the value, which is a real constraint; a value
    containing one means a token was pasted in by mistake, and treating the
    whole string as a value would produce a confusing authentication failure
    rather than a clear parse error.
    """
    parts = spec.split(":")
    if len(parts) == 1:
        return Identity(parts[0], {}, role="user", privilege=1)
    if len(parts) == 2:
        return Identity(parts[0], {header_name: parts[1]}, role="user",
                        privilege=1)
    if len(parts) < 4:
        raise argparse.ArgumentTypeError(
            f"identity {spec!r}: expected name:value:role:privilege")
    name, value, role, privilege = parts[:4]
    try:
        level = int(privilege)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"identity {spec!r}: privilege must be an integer") from None
    return Identity(name, {header_name: value}, role=role, privilege=level)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="apishield")
    parser.add_argument("url")
    parser.add_argument("--yes", action="store_true",
                        help="confirm authorization for this API")
    parser.add_argument("--identity", action="append", default=[],
                        metavar="name:value:role:priv",
                        help="repeatable; at least one authenticated identity "
                             "is required for BOLA/BFLA")
    parser.add_argument("--header", default="x-user-id",
                        help="header carrying the identity (default x-user-id)")
    parser.add_argument("--identities-json", metavar="PATH",
                        help="read identities from a JSON file instead, which "
                             "keeps credentials out of shell history")
    parser.add_argument("--rate", type=float, default=5.0)
    parser.add_argument("--no-writes", action="store_true",
                        help="skip mass-assignment probes, which write one "
                             "sentinel value per endpoint")
    parser.add_argument("--fail-on", default="high")
    parser.add_argument("--json", metavar="PATH")
    parser.add_argument("--html", metavar="PATH")
    parser.add_argument("--no-color", action="store_true")
    parser.add_argument("--no-store", action="store_true")
    args = parser.parse_args(argv)
    colour_on = not args.no_color and sys.stdout.isatty()

    if not args.yes:
        print("APIShield sends real requests with real credentials.")
        print("Re-run with --yes to confirm you are authorized to test:")
        print(f"  {args.url}")
        return 2

    identities: list[Identity] = []
    if args.identities_json:
        import json
        with open(args.identities_json, encoding="utf-8") as handle:
            for item in json.load(handle):
                identities.append(Identity(
                    name=item["name"], headers=item.get("headers") or {},
                    role=item.get("role", "user"),
                    privilege=int(item.get("privilege", 1))))
    else:
        for spec in args.identity:
            try:
                identities.append(parse_identity(spec, args.header))
            except argparse.ArgumentTypeError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return 2

    if not identities:
        print("No identities supplied. Without at least one authenticated")
        print("identity BOLA and BFLA cannot be evaluated, and 'no findings'")
        print("would be indistinguishable from 'nothing tested'. Add one with:")
        print("  --identity alice:1:user:1")
        return 2

    config = ScanConfig(rate_per_second=args.rate,
                        allow_write_probes=not args.no_writes)
    result = scan(args.url, identities, authorized=True, config=config,
                  log=lambda m: print(colour(m, "dim", colour_on)))

    scored = prioritise(result.findings)
    summary = risk_summary(scored)

    print()
    print(colour(f"  {summary['total']} finding(s), "
                 f"{summary['actionable']} actionable", "bold", colour_on))
    print(colour(f"  {result.summary()['endpoints_tested']} endpoints, "
                 f"{len(result.identities)} identities", "dim", colour_on))
    for item in scored:
        tag = colour(f" {item.severity.value.upper():<8}",
                     item.severity.value, colour_on)
        print(f"  {tag} {item.score:>5}  {item.finding.title}")
        print(f"  {'':8} {colour(item.finding.location, 'dim', colour_on)}")
        print(f"  {'':8} {colour(item.explanation, 'dim', colour_on)}")
    print()
    print(f"  {result.coverage}")

    if not args.no_store:
        try:
            store = Store()
            target_id = store.add_target(args.url, "api", args.url.rstrip("/"),
                                         authorized=True)
            scan_id = store.start_scan(target_id, "apishield")
            diff = store.record_scan(scan_id, target_id, "apishield",
                                     result.findings)
            store.finish_scan(scan_id, "completed", {**result.summary(), **diff})
            print(f"  recorded as scan #{scan_id} "
                  f"({diff['new']} new, {diff['recurring']} regressed)")
        except Exception as exc:
            print(f"  could not record scan: {exc}")

    meta = {"target": args.url, "product": "apishield",
            "identities": ", ".join(i.name for i in identities),
            "coverage": result.coverage,
            "spec source": result.spec_source}
    if args.json:
        Path(args.json).write_text(
            report_json(result.findings, args.url, "apishield", meta),
            encoding="utf-8")
        print(f"  JSON report -> {args.json}")
    if args.html:
        Path(args.html).write_text(
            report_html(result.findings, args.url, "apishield", meta,
                        title="APIShield Report"),
            encoding="utf-8-sig")
        print(f"  HTML report -> {args.html}")

    if args.fail_on.lower() != "none":
        level = Severity(args.fail_on.lower())
        passed, reasons = gate(result.findings, level)
        print()
        if passed:
            print(colour(f"  GATE PASSED: no findings at {level.value} or worse",
                         "bold", colour_on))
            return 0
        print(colour(f"  GATE FAILED: {len(reasons)} finding(s) at {level.value}"
                     f" or worse", "bold", colour_on))
        for reason in reasons[:10]:
            print(f"    - {reason}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())