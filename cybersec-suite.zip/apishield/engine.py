"""
APIShield engine: test a REST API for authorization failures.

The thesis: **authorization bugs are only detectable with two identities.**
Scanning a single-authenticated API for BOLA finds nothing, because every
request comes back 200 and 200 looks fine. The bug only appears when user A's
token fetches user B's object.

So the core of this engine is :class:`IdentitySet` -- a set of credentials with
different privilege levels -- and every object-level check is performed as each
one in turn, comparing who could see what.

Checks implemented:
  BOLA        object owned by another identity is readable/writable
  BFLA        an endpoint restricted by role is reachable by a lower role
  mass assign a field the API should ignore is writable
  exposure    a response returns fields no caller should receive
  CORS        wildcard origin combined with credentials
  methods     a method is accepted on a read-only resource
  enumeration a collection returns everything with no bound
  no auth     an endpoint responds to an anonymous caller

Not implemented: stateful auth flows, OAuth token acquisition, GraphQL,
WebSockets, request signing, and rate-limit abuse. See the README.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional
from urllib.parse import urljoin, urlparse

from core.httpclient import Exchange, RateLimiter, SafeClient, Scope, describe_scope
from core.models import Evidence, Finding, Severity, dedupe, utcnow
from core.risk import prioritise, risk_summary

PRODUCT = "apishield"

# Fields that are almost never meant to be client-writable.
PROTECTED_FIELDS = {
    "role", "is_admin", "admin", "is_staff", "permissions", "verified",
    "email_verified", "balance", "credits", "plan", "subscription",
    "internal_note", "created_by", "owner_id", "user_id", "account_id",
}

# Fields whose presence in a response is suspicious for a self-service endpoint.
SENSITIVE_FIELDS = {
    "password", "password_hash", "token", "secret", "api_key", "private_key",
    "internal_note", "ssn", "credit_card", "salary", "notes",
}


@dataclass
class Identity:
    """
    One set of credentials.

    ``name`` is what appears in the report, so it should be meaningful
    ("alice", "anonymous", "admin"). ``role`` drives the privilege comparisons;
    ``headers`` is how the credential is presented, since APIs disagree on
    whether identity travels in a header, a bearer token or a cookie.
    """

    name: str
    headers: dict[str, str] = field(default_factory=dict)
    role: str = "user"
    privilege: int = 1          # higher wins; anonymous is 0
    note: str = ""

    @property
    def is_anonymous(self) -> bool:
        return not self.headers


ANONYMOUS = Identity("anonymous", {}, role="anonymous", privilege=0,
                     note="no credentials")


@dataclass
class Endpoint:
    """
    One API operation, normalised from whatever source described it.

    ``base_url`` was removed from this dataclass. It was never read, and its
    position as the third field meant ``Endpoint("GET", "/x/{id}", {"id": "7"})``
    silently bound the dict to the base URL and ignored the intended parameter
    values -- a mistake that produced a 404 rather than an error.
    """
    method: str
    path: str
    parameters: dict[str, str] = field(default_factory=dict)  # path params
    required_role: str = "user"
    summary: str = ""
    source: str = "discovered"

    def concrete(self, base_url: str, overrides: Optional[dict] = None) -> str:
        """Fill path parameters so the endpoint is actually requestable."""
        values = dict(self.parameters)
        values.update(overrides or {})
        path = self.path
        for key, value in values.items():
            path = re.sub(r"\{%s\}" % re.escape(key), str(value), path)
        # Any parameter we have no value for gets a probe value rather than
        # being sent literally -- "{id}" in a URL 404s and tells us nothing.
        for key in re.findall(r"\{(\w+)\}", path):
            path = path.replace("{%s}" % key, "1")
        return urljoin(base_url.rstrip("/") + "/", path.lstrip("/"))

    @property
    def path_params(self) -> list[str]:
        return re.findall(r"\{(\w+)\}", self.path)

    def key(self) -> str:
        return f"{self.method.upper()} {self.path}"


@dataclass
class ObjectSample:
    """A real object id, learned by creating or listing resources."""
    path_param: str
    value: str
    owner: str = "unknown"       # which identity can see it
    fetched_by: str = ""


# -- spec loading --------------------------------------------------------

def load_openapi(base_url: str, client: SafeClient,
                 paths: Iterable[str] = ("/openapi.json", "/api/openapi.json",
                                         "/swagger.json")) -> tuple[list[Endpoint], str]:
    """
    Read an OpenAPI document and turn it into endpoints.

    Tries several conventional locations because there is no standard path for
    the document itself. Falls back to :func:`discover_endpoints` when none
    exist, because plenty of real APIs have no spec at all and refusing to scan
    them would make the tool useless in exactly the case it matters.
    """
    for path in paths:
        exchange = client.get(urljoin(base_url.rstrip("/") + "/", path.lstrip("/")))
        if exchange.status_code != 200 or not exchange.response_text.strip():
            continue
        try:
            document = json.loads(exchange.response_text)
        except json.JSONDecodeError:
            continue
        if not isinstance(document, dict):
            continue
        endpoints = parse_openapi(document)
        if endpoints:
            return endpoints, path
    return discover_endpoints(client, base_url), "discovery"


def parse_openapi(document: dict) -> list[Endpoint]:
    endpoints: list[Endpoint] = []
    security_schemes = set()
    for name, scheme in (document.get("components", {})
                         .get("securitySchemes", {}) or {}).items():
        security_schemes.add(name)

    for path, operations in (document.get("paths") or {}).items():
        if not isinstance(operations, dict):
            continue
        # Path-level parameters apply to every operation under the path.
        shared = {}
        for param in (operations.get("parameters") or []):
            if isinstance(param, dict) and param.get("in") == "path":
                shared[param.get("name", "id")] = "1"
        for method, operation in operations.items():
            if method.lower() not in ("get", "post", "put", "patch", "delete"):
                continue
            if not isinstance(operation, dict):
                continue
            params = dict(shared)
            for param in (operation.get("parameters") or []):
                if isinstance(param, dict) and param.get("in") == "path":
                    params[param.get("name", "id")] = "1"
            endpoints.append(Endpoint(
                method=method.upper(), path=path, parameters=params,
                summary=(operation.get("summary") or "")[:120],
                required_role=_required_role(operation),
                source="openapi",
            ))
    return endpoints


def _required_role(operation: dict) -> str:
    """
    Infer the intended minimum role from the spec.

    A spec that declares only an admin-scoped security scheme for an endpoint
    means the endpoint is meant to be admin-only. Inferring from the operation
    name is the fallback; it is a guess and findings from it are marked as
    lower confidence rather than presented as fact.
    """
    security = operation.get("security")
    if security:
        schemes = set()
        for requirement in security:
            if isinstance(requirement, dict):
                schemes.update(requirement.keys())
        if schemes and not (schemes & {"bearer", "basic", "oauth2", "apiKey",
                                       "oauth"}):
            return "admin"
    text = f"{operation.get('summary','')} {operation.get('operationId','')}".lower()
    if any(word in text for word in ("admin", "delete", "wipe", "root",
                                     "impersonate", "internal")):
        return "admin"
    return "user"


def discover_endpoints(client: SafeClient, base_url: str,
                       limit: int = 40) -> list[Endpoint]:
    """
    Find endpoints without a spec.

    Tries a conservative list of conventional paths. This is guessing, and the
    findings derived from a guess are labelled lower confidence for exactly that
    reason -- a tool that hides how much of a result was guessed is a tool whose
    results cannot be triaged.
    """
    candidates = [
        ("GET", "/api/me"), ("GET", "/api/users"), ("GET", "/api/users/1"),
        ("GET", "/api/users/2"), ("GET", "/api/admin"), ("GET", "/api/config"),
        ("GET", "/api/settings"), ("GET", "/api/debug"), ("GET", "/api/status"),
        ("GET", "/api/health"), ("GET", "/api/orders"), ("GET", "/api/orders/1"),
        ("GET", "/api/orders/2"), ("GET", "/api/profile"), ("GET", "/api/token"),
        ("GET", "/api/internal/notes"), ("GET", "/api/export"),
    ]
    endpoints: list[Endpoint] = []
    for method, path in candidates[:limit]:
        exchange = client.request(method, urljoin(base_url.rstrip("/") + "/",
                                                  path.lstrip("/")), follow=False)
        if exchange.status_code and exchange.status_code != 404:
            endpoints.append(Endpoint(method=method, path=path, source="guessed"))
    return endpoints


# -- checks --------------------------------------------------------------

def check_missing_auth(client: SafeClient, endpoint: Endpoint, base_url: str,
                       required_role: str = "user") -> Optional[Finding]:
    """
    An endpoint that should require authentication and does not.

    "Should" is doing a lot of work in that sentence, so it is defined
    explicitly rather than guessed per-endpoint:

    * the path must be an API path -- a public web page returning 200 to
      everyone is not a missing-authentication bug, and reporting every one
      buries the endpoints that genuinely matter;
    * it must not be a conventional public path (login, health, docs...);
    * it must look like it handles per-user or administrative data.

    Without these filters this check fired on ``/``, ``/search`` and
    ``/download`` -- three of the lab's nine findings were pure noise of this
    kind, which is exactly how a scanner gets ignored.
    """
    if not _should_require_auth(endpoint):
        return None

    url = endpoint.concrete(base_url)
    exchange = client.get(url)
    if not exchange.status_code or exchange.status_code >= 400:
        return None

    # Compare against what an authenticated caller sees. If anonymous gets
    # strictly less, the endpoint is closed enough and this is not a bug.
    return Finding(
        title=f"{endpoint.key()} responds to an unauthenticated caller",
        severity=Severity.HIGH, category="A07:2021 Identification and "
        "Authentication Failures", target=base_url, location=endpoint.path,
        detector="no_auth", product=PRODUCT,
        description=f"Anonymous request to {endpoint.key()} returned HTTP "
                    f"{exchange.status_code} with a "
                    f"{len(exchange.response_text)} byte body.",
        impact="Unauthenticated access to data or administrative functionality. "
               "No credentials required.",
        remediation="Require authentication on this route and verify the "
                    "identity before producing a response.",
        tags=["unauthenticated", "publicly_reachable", "data_returned",
              "internet_facing"],
        evidence=Evidence(request=f"GET {url}  (no credentials)",
                          response=exchange.response_text[:1200],
                          status_code=exchange.status_code),
    )


# API paths that carry per-user or administrative data.
SENSITIVE_API_HINTS = re.compile(
    r"/(api/|/v\d+/)(.*(user|account|profile|order|invoice|billing|payment|"
    r"admin|token|key|secret|setting|config|internal|export|report|download))",
    re.I)


def _should_require_auth(endpoint: Endpoint) -> bool:
    """
    Whether this endpoint is expected to require authentication.

    Deliberately conservative. A false "this should be authenticated" turns
    every public page into a high-severity finding, and a report padded with
    those is a report nobody reads.
    """
    path = endpoint.path
    if PUBLIC_PATH_HINTS.match(path):
        return False
    if not path.startswith(("/api/", "/v1/", "/v2/")):
        return False
    if SENSITIVE_API_HINTS.search(path) or ADMIN_PATH_HINTS.search(path):
        return True
    # A collection of objects is per-user data by nature.
    return bool(endpoint.path_params) and not path.endswith("/")


def _public_reason(endpoint: Endpoint) -> str:
    """Short explanation for why an endpoint was not treated as privileged."""
    return "public path" if PUBLIC_PATH_HINTS.match(endpoint.path) else "not an API path"


OWNER_FIELDS = ("owner", "owner_id", "user_id", "account_id", "created_by",
               "belongs_to", "userId", "ownerId")

# Fields that identify *whose* record this is when there is no explicit owner.
# Only trusted because _object_owner requires the value to match one of the
# identities we were given -- a field called "username" is not proof of
# ownership, but "username": "bob" when bob is one of our identities and alice
# is the caller is.
IDENTITY_FIELDS = ("username", "user", "name", "email", "login", "handle")


def _object_owner(body: str, identities: list[Identity]) -> Optional[str]:
    """
    Whose object is this? Match the response against the identities we know.

    ``owner: "alice"`` in the body plus an identity named ``alice`` means we
    know who the object belongs to. That is what makes a BOLA proof conclusive:
    not "two users got different bytes" but "alice received an object that
    names bob as its owner".
    """
    try:
        payload = json.loads(body)
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(payload, dict):
        return None

    known = {}
    for identity in identities:
        for candidate in (identity.name, identity.headers.get("x-user-id")):
            if candidate:
                known[str(candidate).lower()] = identity.name

    for field in OWNER_FIELDS + IDENTITY_FIELDS:
        if field not in payload:
            continue
        value = str(payload[field]).lower()
        if value in known:
            return known[value]
    # Also look one level down: {"order": {"owner": "bob"}}
    for value in payload.values():
        if isinstance(value, dict):
            for field in OWNER_FIELDS + IDENTITY_FIELDS:
                if field in value and str(value[field]).lower() in known:
                    return known[str(value[field]).lower()]
    return None


def _candidate_ids(param: str, samples: dict[str, list[str]]) -> list[str]:
    """
    Ids to try for a path parameter.

    An exact match on the parameter name is the only reliable signal. Falling
    straight through to ``__any__`` is not: order ids are 1001..1004 and user
    ids are 1,2,9, so a ``user_id`` parameter probed with an order id returns
    404 every time and the endpoint is silently reported as clean. That is the
    worst possible failure for this tool -- a missed BOLA reads as a pass.

    So: exact ids when available, otherwise small integers plus a couple of
    sampled ids, since integer primary keys are overwhelmingly the common case.

    Probing guessed ids is sound *for proving a finding*: an id that does not
    exist yields 404 and nothing is reported, while an id that does exist and
    belongs to someone else is conclusive. It is only unsound for proving
    absence, and absence is never reported -- that limitation is stated in the
    coverage note instead.
    """
    exact = samples.get(param)
    if exact:
        return list(exact)

    candidates = ["1", "2", "3"]
    for value in (samples.get("__any__") or [])[:2]:
        if value not in candidates:
            candidates.append(value)
    return candidates


def check_bola(client: SafeClient, endpoint: Endpoint, base_url: str,
               identities: list[Identity], samples: dict[str, list[str]],
               log=print) -> list[Finding]:
    """
    BOLA / IDOR: can one identity reach another identity's object?

    Two independent proofs, either of which is conclusive:

    **Ownership mismatch** -- the response names an owner, and that owner is not
    the requester. This is the primary proof and the one that catches the most
    common real bug: an endpoint that ignores identity entirely and returns the
    same row to everybody. A purely differential test misses exactly that case,
    because every caller gets byte-identical responses; it previously scored
    zero findings against a lab endpoint with textbook BOLA.

    **Differential response** -- the same object returns *different* bodies to
    different identities, showing the response is built per-caller without any
    object-ownership check.

    Preconditions: the URL must contain an object identifier. ``/api/me`` has
    none, and an earlier version invented an ``id`` parameter for it, compared
    three users' own ``/me`` responses, saw three different bodies, and
    reported the endpoint working correctly as a privilege escalation.
    """
    findings: list[Finding] = []
    params = endpoint.path_params
    if not params:
        return findings

    param = params[0]
    seen_ids: set[str] = set()

    for object_id in _candidate_ids(param, samples)[:4]:
        if object_id in seen_ids:
            continue
        seen_ids.add(object_id)
        url = endpoint.concrete(base_url, {param: object_id})

        observations: list[tuple[Identity, Exchange]] = []
        for identity in identities:
            exchange = client.request(
                endpoint.method, url, headers=identity.headers or None,
                json_body={"probe": "apishield"} if endpoint.method in
                ("POST", "PUT", "PATCH") else None, follow=False)
            observations.append((identity, exchange))

        readable_by = [(i, e) for i, e in observations
                       if e.status_code and e.status_code < 300
                       and e.response_text.strip()]
        if not readable_by:
            continue

        # -- proof 1: ownership mismatch ------------------------------
        mismatches = []
        for identity, exchange in readable_by:
            owner = _object_owner(exchange.response_text, identities)
            if owner and owner != identity.name:
                mismatches.append((identity, owner, exchange))

        # -- proof 2: differential response ---------------------------
        bodies: dict[str, list[str]] = {}
        for identity, exchange in readable_by:
            bodies.setdefault(_body_identity(exchange.response_text),
                              []).append(identity.name)
        differential = len(bodies) > 1

        if not mismatches and not differential:
            continue

        anonymous_involved = any(i.is_anonymous for i, _ in readable_by)

        if mismatches:
            severity = Severity.CRITICAL if anonymous_involved else Severity.HIGH
            reader, owner, exchange = mismatches[0]
            detail = (
                f"Identity '{reader.name}' received an object owned by "
                f"'{owner}'. The endpoint returned HTTP {exchange.status_code} "
                f"for an object that belongs to someone else."
                + (f" {len(mismatches)} identity/identities could do this."
                   if len(mismatches) > 1 else ""))
            proof = "ownership-mismatch"
        else:
            severity = Severity.CRITICAL if anonymous_involved else Severity.MEDIUM
            exchange = readable_by[0][1]
            detail = (
                f"The same object returned different content to "
                f"{len(bodies)} identities ({', '.join(sorted(bodies.values(), key=str)[0])}) "
                f"with no ownership check distinguishing them.")
            proof = "differential-response"

        best = next(e for i, e in readable_by if not i.is_anonymous) \
            if any(not i.is_anonymous for i, _ in readable_by) else readable_by[0][1]
        findings.append(Finding(
            title=f"BOLA on {endpoint.key()} ({param}={object_id})",
            severity=severity, category="A01:2021 Broken Access Control",
            target=base_url, location=f"{endpoint.path} -> {object_id}",
            detector="bola", product=PRODUCT,
            description=detail,
            impact="Any authenticated user can read or modify another user's "
                   "data by changing the identifier in the URL. This is the "
                   "single most common serious API vulnerability.",
            remediation="Look up the object scoped to the authenticated "
                        "principal and return 404 when the caller does not own "
                        "it. Verify on every request, not only on the list.",
            tags=["confirmed_by_probe", "data_returned"]
            + (["state_changing"] if endpoint.method != "GET" else [])
            + (["unauthenticated"] if anonymous_involved else []),
            evidence=Evidence(
                request="; ".join(
                    f"{endpoint.method} {url} as {i.name}"
                    f"{' (no credentials)' if i.is_anonymous else ''}"
                    for i, _ in readable_by),
                response="; ".join(
                    f"--- as {i.name}: HTTP {e.status_code} "
                    f"{e.response_text[:250]}" for i, e in readable_by),
                status_code=best.status_code,
                extra={"identities": [i.name for i, _ in readable_by],
                       "object_id": object_id, "proof": proof}),
            references=["https://owasp.org/API-Security/editions/2023/en/"
                        "0xa1-broken-object-level-authorization/"],
        ))
        log(f"  BOLA CONFIRMED: {endpoint.key()} id={object_id} "
            f"({proof})")
    return _merge_bola(findings)


def _merge_bola(findings: list[Finding]) -> list[Finding]:
    """
    One finding per endpoint, not one per object id.

    Three readable order ids are one broken endpoint, and reporting them as
    three separate criticals triples the apparent severity of the same bug. The
    affected ids are listed in the description, and the count is recorded --
    because "3 of 4 orders readable" is a much stronger remediation argument
    than one example.
    """
    merged: dict[str, Finding] = {}
    for finding in findings:
        key = f"{finding.detector}|{finding.location.split('->')[0].strip()}"
        existing = merged.get(key)
        if existing is None:
            finding.metadata.setdefault("affected_ids", [])
            ids = str(finding.evidence.extra.get("object_id", ""))
            if ids:
                finding.metadata["affected_ids"].append(ids)
            merged[key] = finding
            continue
        object_id = str(finding.evidence.extra.get("object_id", ""))
        if object_id and object_id not in existing.metadata["affected_ids"]:
            existing.metadata["affected_ids"].append(object_id)
        if finding.severity < existing.severity:
            existing.severity = finding.severity

    for finding in merged.values():
        ids = finding.metadata.get("affected_ids") or []
        if len(ids) > 1:
            sample = ", ".join(ids[:5])
            more = f" (+{len(ids) - 5} more)" if len(ids) > 5 else ""
            finding.title = (f"{finding.title.split('(')[0].strip()} "
                             f"-- {len(ids)} object(s) exposed")
            finding.description += (
                f" Confirmed on {len(ids)} object id(s): {sample}{more}.")
        elif ids:
            finding.title = f"{finding.title.split(' -- ')[0]}"
        finding.fingerprint = finding.compute_fingerprint()
    return list(merged.values())


def check_bfla(client: SafeClient, endpoint: Endpoint, base_url: str,
               identities: list[Identity], log=print) -> list[Finding]:
    """
    Broken function-level authorization: a low-privilege role reaching an
    administrative action.

    The precondition that matters: **the endpoint has to be privileged at all.**
    An earlier version compared "admin gets 200" against "user gets 200" for
    every endpoint, which flagged every public page in the application -- `/`,
    `/search`, `/download` -- as a critical privilege escalation. On an
    endpoint that ignores credentials entirely both identities necessarily get
    the same answer, and that is a missing-auth finding, not a BFLA one.

    So the endpoint must look privileged (declared admin-only in the spec, or
    an unmistakably administrative path), and there must be an admin and a
    non-admin identity to compare. Otherwise this returns nothing.
    """
    if not _is_privileged_endpoint(endpoint):
        return []

    admins = [i for i in identities if i.privilege >= 3]
    others = [i for i in identities if i.privilege < 3 and not i.is_anonymous]
    if not admins or not others:
        return []

    findings: list[Finding] = []
    url = endpoint.concrete(base_url)
    admin_status = None
    for admin in admins:
        exchange = client.request(endpoint.method, url, headers=admin.headers,
                                  follow=False)
        if exchange.status_code and exchange.status_code < 300:
            admin_status = exchange.status_code
            break
    if admin_status is None:
        return []   # not actually reachable even by an admin; nothing to compare

    for other in others:
        exchange = client.request(endpoint.method, url, headers=other.headers,
                                  follow=False)
        if not exchange.status_code or exchange.status_code >= 300:
            continue
        findings.append(Finding(
            title=f"BFLA on {endpoint.key()} reachable by '{other.role}'",
            severity=Severity.CRITICAL,
            category="A01:2021 Broken Access Control", target=base_url,
            location=endpoint.path, detector="bfla", product=PRODUCT,
            description=f"An identity with role '{other.role}' received HTTP "
                        f"{exchange.status_code} from an endpoint that answers "
                        f"an admin identity with HTTP {admin_status}. The "
                        f"function is not restricted to the role it needs.",
            impact="Any logged-in user can perform administrative actions: "
                   "deleting data, changing configuration, or reading "
                   "operational secrets.",
            remediation="Enforce the required role server-side on every "
                        "request. Do not rely on the UI hiding the button.",
            tags=["confirmed_by_probe", "state_changing", "data_returned",
                  "requires_authentication"],
            evidence=Evidence(
                request=f"{endpoint.method} {url} as {other.name} "
                        f"(role={other.role})",
                response=f"HTTP {exchange.status_code}\n"
                         f"{exchange.response_text[:400]}",
                status_code=exchange.status_code,
                extra={"low_privilege": other.name, "admin_status": admin_status}),
            references=["https://owasp.org/API-Security/editions/2023/en/"
                        "0xa5-broken-function-level-authorization/"],
        ))
        log(f"  BFLA CONFIRMED: {endpoint.key()} as {other.role}")
    return findings


# Path fragments that indicate an administrative function. Used both here and
# by the missing-auth check to decide what is worth testing.
ADMIN_PATH_HINTS = re.compile(
    r"/(admin|administrator|root|internal|ops|operations|manage|management|"
    r"console|dashboard|superuser|system)(/|$)", re.I)

# Paths that are inherently public and must never be reported as missing auth.
PUBLIC_PATH_HINTS = re.compile(
    r"^/(login|logout|register|signup|health|healthz|ready|livez|status|"
    r"version|ping|docs|openapi\.json|swagger|favicon|robots\.txt|\.?$)",
    re.I)


def _is_privileged_endpoint(endpoint: Endpoint) -> bool:
    """Whether this endpoint is supposed to be administrative."""
    if endpoint.required_role == "admin":
        return True
    return bool(ADMIN_PATH_HINTS.search(endpoint.path))


def check_mass_assignment(client: SafeClient, endpoint: Endpoint, base_url: str,
                          identity: Identity,
                          log=print) -> list[Finding]:
    """
    Mass assignment: can a normal client write a field it should not control?

    Probed by attempting to set one protected field to a sentinel and reading
    it back. Only ``PATCH``/``PUT``/``POST`` on an endpoint with a path
    parameter are tested -- writing to a collection root creates junk data, and
    a scanner that creates junk data is a scanner people delete.
    """
    findings: list[Finding] = []
    if endpoint.method not in ("PATCH", "PUT", "POST"):
        return findings
    if not endpoint.path_params:
        return findings
    if identity.is_anonymous:
        return findings

    for field_name in ("role", "is_admin"):
        sentinel = "apishield-probe"
        payload = {field_name: sentinel}
        probe = Endpoint(method=endpoint.method, path=endpoint.path,
                         parameters=endpoint.parameters)
        url = probe.concrete(base_url)
        client.request(endpoint.method, url, headers=identity.headers,
                       json_body=payload, follow=False)
        # Read back.
        read = client.get(url, headers=identity.headers, follow=False)
        body = read.response_text or ""
        if sentinel not in body:
            continue
        findings.append(Finding(
            title=f"Mass assignment on {endpoint.key()} accepts '{field_name}'",
            severity=Severity.HIGH, category="A08:2021 Software and Data "
            "Integrity Failures", target=base_url, location=endpoint.path,
            detector="mass_assignment", product=PRODUCT,
            description=f"A request from identity '{identity.name}' wrote "
                        f"{field_name}={sentinel!r} and the value persisted on "
                        f"read-back. The API writes client-supplied fields "
                        f"without an allow-list.",
            impact="Privilege escalation to administrator, or modification of "
                   "any internal field the server assumed it controlled.",
            remediation="Bind the request body to an explicit schema. Reject "
                        "unknown fields rather than storing them.",
            tags=["confirmed_by_probe", "state_changing",
                  "requires_authentication"],
            evidence=Evidence(
                request=f"{endpoint.method} {url} "
                        f'{{"{field_name}": "{sentinel}"}}',
                response=f"HTTP {read.status_code}\n{body[:400]}",
                status_code=read.status_code,
                extra={"field": field_name, "sentinel": sentinel}),
        ))
        log(f"  MASS ASSIGNMENT CONFIRMED: {endpoint.key()} -> {field_name}")
        break   # one proof per endpoint is enough; do not keep writing
    return findings


def check_excessive_exposure(exchange: Exchange, endpoint: Endpoint,
                             base_url: str) -> list[Finding]:
    """Fields in a response that no ordinary caller should receive."""
    findings: list[Finding] = []
    try:
        payload = json.loads(exchange.response_text)
    except (json.JSONDecodeError, TypeError):
        return findings

    leaked = _find_sensitive(payload)
    if not leaked:
        return findings

    findings.append(Finding(
        title=f"Excessive data exposure on {endpoint.key()}",
        severity=Severity.MEDIUM, category="A01:2021 Broken Access Control",
        target=base_url, location=endpoint.path, detector="exposure",
        product=PRODUCT,
        description=f"Response contains field(s) {', '.join(leaked)} that are "
                    f"not part of what a caller needs to see.",
        impact="Internal-only or sensitive fields leak to any caller who can "
               "reach the endpoint, and end up in logs and caches.",
        remediation="Return a purpose-built response object. Do not serialise "
                    "the database row directly.",
        confidence=0.7,   # field-name heuristic, not proven misuse
        tags=["data_returned"],
        evidence=Evidence(request=f"GET {exchange.url}",
                          response=exchange.response_text[:1000],
                          status_code=exchange.status_code,
                          extra={"leaked_fields": leaked}),
    ))
    return findings


def _find_sensitive(payload: Any, prefix: str = "") -> list[str]:
    """Walk a JSON body and report sensitive field names found."""
    found: list[str] = []
    if isinstance(payload, dict):
        for key, value in payload.items():
            path = f"{prefix}.{key}" if prefix else key
            if key.lower() in SENSITIVE_FIELDS:
                found.append(path)
            elif key.lower().endswith(("_secret", "_token", "_key")):
                found.append(path)
            else:
                found.extend(_find_sensitive(value, path))
    elif isinstance(payload, list):
        for item in payload[:5]:          # a sample; not the whole collection
            found.extend(_find_sensitive(item, prefix))
    return found


def check_cors(client: SafeClient, endpoint: Endpoint, base_url: str,
               log=print) -> list[Finding]:
    """
    CORS misconfiguration.

    The finding that matters is wildcard origin *combined with credentials
    allowed*. A wildcard on its own is often harmless for public endpoints, and
    browsers reject the credentialed wildcard combination -- but a server that
    echoes the request's Origin while allowing credentials is the genuinely
    dangerous variant, and that is what is reported here.
    """
    findings: list[Finding] = []
    url = endpoint.concrete(base_url)
    exchange = client.request(
        "OPTIONS", url,
        headers={"Origin": "https://apishield-probe.example",
                 "Access-Control-Request-Method": "GET"},
        follow=False)
    headers = {k.lower(): v for k, v in exchange.response_headers.items()}
    allow_origin = headers.get("access-control-allow-origin", "")
    allow_creds = headers.get("access-control-allow-credentials", "").lower()
    if not allow_origin:
        return findings

    echoed = "apishield-probe.example" in allow_origin
    wildcard = allow_origin.strip() == "*"
    if not (wildcard or echoed) or allow_creds not in ("true", "1"):
        return findings

    severity = Severity.HIGH if echoed else Severity.MEDIUM
    findings.append(Finding(
        title=f"CORS allows credentialed cross-origin reads on {endpoint.key()}",
        severity=severity, category="A05:2021 Security Misconfiguration",
        target=base_url, location=endpoint.path, detector="cors", product=PRODUCT,
        description=f"Access-Control-Allow-Origin: {allow_origin} with "
                    f"Access-Control-Allow-Credentials: {allow_creds}. "
                    + ("The server reflects any requesting origin, so any site "
                       "can read authenticated responses."
                       if echoed else
                       "A wildcard origin is combined with credentials."),
        impact="An attacker's page can read authenticated API responses in the "
               "victim's browser and exfiltrate them.",
        remediation="Allow-list specific origins. Never combine a wildcard or "
                    "reflected origin with credentials.",
        tags=["internet_facing", "confirmed_by_probe"],
        evidence=Evidence(
            request=f"OPTIONS {url} with Origin: "
                    f"https://apishield-probe.example",
            response="\n".join(f"{k}: {v}" for k, v in sorted(
                headers.items()) if k.startswith("access-control")),
            status_code=exchange.status_code,
            extra={"allow_origin": allow_origin,
                   "allow_credentials": allow_creds}),
        references=["https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS"],
    ))
    log(f"  CORS: {endpoint.key()} origin={allow_origin} creds={allow_creds}")
    return findings


def check_method_confusion(client: SafeClient, endpoint: Endpoint,
                           base_url: str, log=print) -> list[Finding]:
    """
    A method accepted on a resource that should not allow it.

    Read-only resources advertising PUT/DELETE in Allow, or actually executing
    them, is a real defect: it usually means the route table was built without
    thinking about what each verb means.
    """
    findings: list[Finding] = []
    url = endpoint.concrete(base_url)
    preflight = client.request("OPTIONS", url, follow=False)
    allow = preflight.response_headers.get("allow", "")
    if not allow:
        return findings

    declared = {m.strip().upper() for m in allow.split(",")}
    read_only = {"GET", "HEAD", "OPTIONS"}
    dangerous = declared & {"DELETE", "PUT", "PATCH"}
    if endpoint.method not in read_only or not dangerous:
        # Only a read-only resource is a method-confusion problem; a resource
        # that already accepts DELETE is not confused about it.
        return findings

    # Only report verbs the server actually executes, not merely advertises.
    executed = []
    for method in sorted(dangerous):
        exchange = client.request(method, url, follow=False)
        if exchange.status_code and exchange.status_code < 400:
            executed.append((method, exchange.status_code))

    if not executed:
        return findings

    findings.append(Finding(
        title=f"{endpoint.key()} accepts state-changing methods "
              f"({', '.join(m for m, _ in executed)})",
        severity=Severity.MEDIUM, category="A04:2021 Insecure Design",
        target=base_url, location=endpoint.path, detector="methods",
        product=PRODUCT,
        description=f"Allow header advertises {allow}. The server executed "
                    f"{', '.join(f'{m} -> HTTP {s}' for m, s in executed)} on a "
                    f"read-only resource.",
        impact="Accidental or malicious deletion/overwrite of resources through "
               "an endpoint that should be read-only.",
        remediation="Restrict the verbs a route accepts to those it "
                    "implements, and set Allow accordingly.",
        tags=["confirmed_by_probe", "state_changing"],
        evidence=Evidence(
            request=f"OPTIONS {url}",
            response=f"Allow: {allow}\n" + "\n".join(
                f"{m} {url} -> HTTP {s}" for m, s in executed),
            extra={"declared": allow}),
    ))
    log(f"  METHOD CONFUSION: {endpoint.key()} -> {executed}")
    return findings


def check_unbounded_collection(exchange: Exchange, endpoint: Endpoint,
                               base_url: str, limit: int = 50) -> list[Finding]:
    """
    A collection endpoint returning everything with no bound.

    Reported only above ``limit`` records, because a small collection is not a
    problem -- flagging it would train people to ignore this check entirely.
    """
    findings: list[Finding] = []
    try:
        payload = json.loads(exchange.response_text)
    except (json.JSONDecodeError, TypeError):
        return findings

    items = None
    if isinstance(payload, list):
        items = payload
    elif isinstance(payload, dict):
        for key in ("items", "data", "results", "records", "rows"):
            if isinstance(payload.get(key), list):
                items = payload[key]
                break
    if items is None or len(items) <= limit:
        return findings

    findings.append(Finding(
        title=f"Unbounded collection on {endpoint.key()} "
              f"({len(items)} items, no pagination)",
        severity=Severity.MEDIUM, category="A04:2021 Insecure Design",
        target=base_url, location=endpoint.path, detector="enumeration",
        product=PRODUCT,
        description=f"The endpoint returned {len(items)} records in one "
                    f"response with no limit, offset or cursor parameter.",
        impact="Bulk exfiltration of the whole collection, and enough load to "
               "make the endpoint a denial-of-service lever.",
        remediation="Require pagination and cap the page size server-side.",
        tags=["data_returned", "internet_facing"],
        evidence=Evidence(request=f"GET {exchange.url}",
                          response=f"{len(items)} items returned",
                          status_code=exchange.status_code,
                          extra={"item_count": len(items), "limit": limit}),
    ))
    return findings


# -- helpers -------------------------------------------------------------

def _body_identity(body: str) -> str:
    """
    A stable-ish signature of a response body, used to tell identities apart.

    Hashing rather than string-comparing avoids embedding whole bodies in the
    comparison while still detecting "these two got different things".
    """
    import hashlib
    try:
        payload = json.loads(body)
        normalised = json.dumps(payload, sort_keys=True, default=str)
    except (json.JSONDecodeError, TypeError):
        normalised = body or ""
    return hashlib.sha256(normalised.encode("utf-8")).hexdigest()[:16]


def sample_objects(client: SafeClient, base_url: str,
                   identities: list[Identity], limit: int = 4) -> dict[str, list[str]]:
    """
    Collect real object ids from list endpoints.

    Testing ``/orders/{id}`` against a guessed id proves nothing -- a 404 for
    an id that does not exist and a 403 for one you may not see are
    indistinguishable, and a scanner that cannot tell them apart reports
    "inconclusive" constantly. So ids are harvested from the collections first.

    Ids are indexed three ways, because a path parameter's name rarely matches
    the field name in the response. ``/api/orders/{order_id}`` returns objects
    with an ``id`` field, so keying only on the field name meant the BOLA test
    found no candidates for that endpoint and silently skipped it -- missing the
    vulnerability the product exists to find.

      * ``__any__``    every id seen, usable for any path parameter
      * field name     e.g. ``id``
      * singular of the collection, e.g. ``order_id`` for ``/api/orders``
    """
    samples: dict[str, list[str]] = {}

    def record(keys: Iterable[str], value: str) -> None:
        for key in keys:
            bucket = samples.setdefault(key, [])
            if value not in bucket:
                bucket.append(value)

    for path in ("/api/orders", "/api/users", "/api/items", "/api/objects",
                 "/api/accounts", "/api/documents"):
        exchange = client.get(urljoin(base_url.rstrip("/") + "/",
                                      path.lstrip("/")))
        if not exchange.status_code or exchange.status_code >= 400:
            continue
        try:
            payload = json.loads(exchange.response_text)
        except (json.JSONDecodeError, TypeError):
            continue
        items = payload.get("items") if isinstance(payload, dict) else payload
        if not isinstance(items, list):
            continue

        # /api/orders -> order_id, so the path parameter of /api/orders/{order_id}
        # resolves to ids harvested from /api/orders.
        singular = path.rstrip("/").split("/")[-1].rstrip("s") + "_id"
        for item in items[:limit]:
            if isinstance(item, dict):
                for key in ("id", "order_id", "user_id", "uuid"):
                    if key in item:
                        value = str(item[key])
                        record([key, singular, "__any__"], value)
                        break
    return samples


# -- the scan ------------------------------------------------------------

@dataclass
class ScanConfig:
    max_endpoints: int = 40
    rate_per_second: float = 5.0
    run_bola: bool = True
    run_bfla: bool = True
    run_mass_assignment: bool = True
    run_exposure: bool = True
    run_cors: bool = True
    run_methods: bool = True
    run_enumeration: bool = True
    # Mass assignment writes. Off unless asked for, because they mutate data.
    allow_write_probes: bool = True


@dataclass
class ScanResult:
    findings: list[Finding]
    endpoints: list[Endpoint]
    spec_source: str
    identities: list[Identity]
    started_at: str
    duration_s: float
    coverage: str
    samples: dict[str, list[str]] = field(default_factory=dict)

    def summary(self) -> dict:
        scored = prioritise(self.findings)
        return {
            **risk_summary(scored),
            "endpoints_tested": len(self.endpoints),
            "identities": len(self.identities),
            "spec_source": self.spec_source,
            "duration_s": round(self.duration_s, 1),
            "coverage": self.coverage,
        }


def scan(base_url: str, identities: list[Identity], authorized: bool = False,
         config: Optional[ScanConfig] = None, log=print) -> ScanResult:
    """
    Run the API authorization test suite.

    ``identities`` must contain at least one authenticated identity. With only
    anonymous access, BOLA and BFLA cannot be evaluated at all -- and the run
    says so rather than reporting a clean result, because "no access" is not
    "no vulnerability".
    """
    config = config or ScanConfig()
    started = time.perf_counter()
    started_at = utcnow()
    identities = list(identities)

    scope = Scope(base_url, authorized=authorized)
    log(describe_scope(scope))
    if not any(not i.is_anonymous for i in identities):
        log("WARNING: only anonymous identity supplied. BOLA and BFLA cannot "
            "be evaluated and will not be reported.")

    with SafeClient(scope, rate=RateLimiter(config.rate_per_second)) as client:
        endpoints, spec_source = load_openapi(base_url, client)
        log(f"  {len(endpoints)} endpoint(s) from {spec_source}")
        endpoints = endpoints[: config.max_endpoints]

        samples = sample_objects(client, base_url, identities) if config.run_bola else {}
        if samples:
            log(f"  sampled object ids: "
                f"{ {k: len(v) for k, v in samples.items()} }")

        # Which identities can read anything at all -- decides whether BOLA is
        # evaluable.
        accessible = [i for i in identities if not i.is_anonymous]
        findings: list[Finding] = []
        assessed: dict[str, int] = {}

        for endpoint in endpoints:
            log(f"testing {endpoint.key()}...")
            url = endpoint.concrete(base_url)
            primary = next((i for i in accessible), ANONYMOUS)
            base_exchange = client.request(endpoint.method, url,
                                           headers=primary.headers or None,
                                           follow=False)

            if ANONYMOUS not in identities:
                anon = client.request(endpoint.method, url, follow=False)
                if anon.status_code and anon.status_code < 300:
                    endpoint_finding = check_missing_auth(
                        client, endpoint, base_url)
                    if endpoint_finding:
                        findings.append(endpoint_finding)

            if config.run_bola and samples and accessible:
                before = len(findings)
                findings += check_bola(client, endpoint, base_url, accessible,
                                       samples, log=log)
                assessed["bola"] = assessed.get("bola", 0) + (
                    1 if len(findings) > before else 0)

            if config.run_bfla:
                before = len(findings)
                findings += check_bfla(client, endpoint, base_url, identities,
                                       log=log)
                assessed["bfla"] = assessed.get("bfla", 0) + (
                    1 if len(findings) > before else 0)

            if (config.run_mass_assignment and config.allow_write_probes
                    and endpoint.path_params and accessible):
                before = len(findings)
                findings += check_mass_assignment(client, endpoint, base_url,
                                                  accessible[0], log=log)
                assessed["mass_assignment"] = assessed.get("mass_assignment", 0) + (
                    1 if len(findings) > before else 0)

            if config.run_exposure and base_exchange.response_text:
                findings += check_excessive_exposure(base_exchange, endpoint,
                                                     base_url)
                assessed["exposure"] = assessed.get("exposure", 0) + 1

            if config.run_cors:
                findings += check_cors(client, endpoint, base_url, log=log)

            if config.run_methods:
                findings += check_method_confusion(client, endpoint, base_url,
                                                   log=log)

            if config.run_enumeration and endpoint.method == "GET":
                findings += check_unbounded_collection(base_exchange, endpoint,
                                                       base_url)
                assessed["enumeration"] = assessed.get("enumeration", 0) + 1

    findings = dedupe(findings)
    for finding in findings:
        finding.target = base_url
        finding.fingerprint = finding.compute_fingerprint()

    coverage = _coverage_note(assessed, len(endpoints), identities, samples)
    duration = time.perf_counter() - started
    log(f"done in {duration:.1f}s: {len(findings)} finding(s). {coverage}")

    return ScanResult(findings=findings, endpoints=endpoints,
                      spec_source=spec_source, identities=identities,
                      started_at=started_at, duration_s=duration,
                      coverage=coverage, samples=samples)


def _coverage_note(assessed: dict[str, int], total_endpoints: int,
                   identities: list[Identity], samples: dict) -> str:
    """
    Be explicit about what could *not* be evaluated.

    The most important sentence in an authorization report is which checks were
    impossible. A run with one identity cannot test BOLA, and saying "no BOLA
    found" there reads as a pass.
    """
    parts = [f"endpoints {total_endpoints}"]
    parts += [f"{check} evaluated on {count}" for check, count in
              sorted(assessed.items())]
    if not samples:
        parts.append("BOLA not evaluated: no object ids could be sampled")
    authenticated = [i for i in identities if not i.is_anonymous]
    if len(authenticated) < 2:
        parts.append("BOLA/BFLA not evaluated: needs 2+ authenticated "
                     f"identities, got {len(authenticated)}")
    return "; ".join(parts)