"""
Deliberately vulnerable target application -- the lab.

This exists so AutoPentest, APIShield and FixProof have something to find that
is real rather than mocked. Every weakness below is intentional and is
documented so nobody mistakes it for an accident.

WARNING: this app has no authentication in front of the lab data and contains
known-injection bugs. It binds to 127.0.0.1 by default. Never expose it to a
network you do not control, and never point it at anything real.

Vulnerabilities present, mapped to the products that detect them:

  V1  reflected XSS in /search          -> AutoPentest, FixProof
  V2  SQL injection in /item            -> AutoPentest
  V3  path traversal in /download       -> AutoPentest
  V4  user-controlled host header       -> AutoPentest
  V5  no security headers, no HSTS      -> AutoPentest, FixProof
  V6  BOLA: /api/orders/{id}            -> APIShield
  V7  missing ownership on /api/users/{id}  -> APIShield
  V8  mass assignment on PATCH /api/users/{id} -> APIShield
  V9  unbounded list endpoint, no pagination -> APIShield
  V10 method confusion: DELETE allowed anywhere -> APIShield
  V11 CORS wildcard with credentials     -> APIShield
  V12 /api/admin with no auth check      -> APIShield
"""

from __future__ import annotations

import os
import sqlite3

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

DB_PATH = os.environ.get("LAB_DB", "lab.db")

app = FastAPI(title="Vulnerable Lab App", version="0.9",
              docs_url="/api/docs", redoc_url=None)

NOTES = {
    "1": {"id": 1, "name": "Notebook", "owner": "alice", "price": 12.50,
          "note": "first notebook", "secret": "alice-private-key"},
    "2": {"id": 2, "name": "Backpack", "owner": "bob", "price": 45.00,
          "note": "travel", "secret": "bob-private-key"},
    "3": {"id": 3, "name": "Umbrella", "owner": "alice", "price": 8.25,
          "note": "rainy season", "secret": "alice-vault-token"},
}

USERS = {
    "1": {"id": 1, "username": "alice", "email": "alice@example.test",
          "role": "user", "internal_note": "alice only"},
    "2": {"id": 2, "username": "bob", "email": "bob@example.test",
          "role": "user", "internal_note": "bob only"},
    "9": {"id": 9, "username": "root", "email": "root@example.test",
          "role": "admin", "internal_note": "do not leak"},
}


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# -- pages ---------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def index():
    """No security headers on any response (V5)."""
    return HTMLResponse(
        '<!DOCTYPE html><html><head><title>Lab App</title></head><body>'
        '<h1>Vulnerable Lab</h1>'
        '<nav><a href="/search">search</a> <a href="/item?id=1">item</a> '
        '<a href="/download?name=readme.txt">download</a> '
        '<a href="/api/docs">api</a> <a href="/api/orders/1">orders</a></nav>'
        '</body></html>'
    )


@app.get("/search", response_class=HTMLResponse)
async def search(request: Request):
    """
    V1: reflected XSS.

    The query string is written into the response with no escaping. A scanner
    sends a unique marker and checks whether it comes back unchanged -- that
    is the only reliable way to prove reflection without guessing.
    """
    query = request.query_params.get("q", "")
    return HTMLResponse(
        f"<!DOCTYPE html><html><head><title>Search</title></head><body>"
        f"<h1>Search</h1><p>results for: {query}</p></body></html>"
    )


@app.get("/item", response_class=PlainTextResponse)
async def item(id: str = "1"):
    """
    V2: SQL injection.

    String-concatenated into a query. The scanner proves it by making the
    response contain something a legitimate id never would (a UNION-selected
    column), not by guessing from an error message.
    """
    conn = db()
    try:
        rows = conn.execute(f"SELECT * FROM notes WHERE id = '{id}'").fetchall()
    except sqlite3.Error as exc:
        return PlainTextResponse(f"database error: {exc}")
    finally:
        conn.close()
    if not rows:
        return PlainTextResponse("no rows")
    return PlainTextResponse(
        "\n".join(f"{r['id']}|{r['body']}" for r in rows))


@app.get("/download")
async def download(name: str = "readme.txt"):
    """
    V3: path traversal.

    No normalisation of ``name`` before it is joined to a directory, so
    ``../`` escapes it. The scanner demonstrates traversal by reading a file
    it can prove exists outside the directory, not by attempting ``/etc/passwd``
    on a stranger's server.
    """
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "files")
    path = os.path.join(base, name)
    if os.path.exists(path) and os.path.isfile(path):
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return PlainTextResponse(handle.read())
    return PlainTextResponse("not found", status_code=404)


@app.get("/redirect")
async def redirect(target: str = "/"):
    """
    Used by the scanner to confirm it refuses to follow an off-site redirect.
    Not a vulnerability itself -- it is a safety test of the client.
    """
    from fastapi.responses import RedirectResponse
    return RedirectResponse(target, status_code=302)


# -- API: authorization is the whole point here --------------------------

@app.get("/api/orders/{order_id}")
async def get_order(order_id: int, request: Request):
    """
    V6: BOLA / IDOR.

    Returns the order for whoever asks. There is no check that the caller owns
    it. A scanner proves this by fetching the *same* endpoint as two different
    identities and showing that both get 200 with different bodies -- ownership
    was never enforced.
    """
    conn = db()
    try:
        row = conn.execute("SELECT * FROM orders WHERE id = ?",
                           (order_id,)).fetchone()
    finally:
        conn.close()
    if row is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse(dict(row))


@app.get("/api/users/{user_id}")
async def get_user(user_id: int):
    """
    V7: missing object-level authorisation plus V11-style over-exposure.

    ``internal_note`` is a field no authenticated non-admin should receive.
    This is both an authorization bug and an excessive data exposure bug.
    """
    user = USERS.get(str(user_id))
    if user is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse(user)


@app.patch("/api/users/{user_id}")
async def patch_user(user_id: int, request: Request):
    """
    V8: mass assignment.

    Every key in the request body is copied into the user record, so a client
    can set ``role`` or ``internal_note``. The scanner checks whether a field
    the API should refuse -- ``role`` -- is writable by a non-admin.
    """
    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"error": "invalid json"}, status_code=400)
    if not isinstance(payload, dict):
        return JSONResponse({"error": "object expected"}, status_code=400)
    user = USERS.setdefault(str(user_id), {
        "id": user_id, "username": f"user{user_id}", "email": "",
        "role": "user", "internal_note": ""})
    updated = dict(user)
    for key, value in payload.items():      # no allow-list: V8
        updated[key] = value
    USERS[str(user_id)] = updated
    return JSONResponse(updated)


@app.get("/api/orders")
async def list_orders(request: Request):
    """
    V9: unbounded collection.

    Returns every row with no limit parameter. On a real dataset this is the
    difference between an endpoint that returns 20 rows and one that dumps a
    million-row table and takes the database down with it.
    """
    conn = db()
    try:
        rows = conn.execute("SELECT * FROM orders").fetchall()
    finally:
        conn.close()
    return JSONResponse({"count": len(rows), "items": [dict(r) for r in rows]})


@app.api_route("/api/admin", methods=["GET", "POST", "DELETE"])
async def admin(request: Request):
    """
    V12: missing function-level authorisation.

    Administrative action with no authentication check at all, and it accepts
    DELETE. The scanner proves it by calling this with no credentials and
    getting a 200.
    """
    if request.method == "DELETE":
        return JSONResponse({"status": "wiped"})
    return JSONResponse({"admin": True, "action": request.method})


@app.get("/api/me")
async def me(request: Request):
    """
    The one endpoint that behaves correctly: identity comes from a header and
    the response contains only that caller's own data.

    It exists so the lab is not uniformly broken -- a scanner tested against
    only-vulnerable targets reports a suspiciously perfect success rate, and
    cannot tell "secure" apart from "never checked".
    """
    user_id = request.headers.get("x-user-id")
    if user_id is None:
        return JSONResponse({"error": "unauthenticated"}, status_code=401)
    user = USERS.get(user_id)
    if user is None:
        return JSONResponse({"error": "unknown user"}, status_code=403)
    return JSONResponse({"id": user["id"], "username": user["username"],
                         "role": user["role"]})


@app.options("/api/orders/{order_id}")
async def options_order(order_id: int):
    """
    Advertises methods the endpoint should not accept. A DELETE here on a
    read-only resource is a method-confirmation problem (V10).
    """
    return JSONResponse({}, headers={
        "Allow": "GET, POST, PUT, DELETE, PATCH",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Credentials": "true",
    })


# -- database bootstrap --------------------------------------------------

def init_db() -> None:
    conn = db()
    conn.execute("CREATE TABLE IF NOT EXISTS notes"
                 " (id TEXT PRIMARY KEY, body TEXT)")
    conn.execute("CREATE TABLE IF NOT EXISTS orders"
                 " (id INTEGER PRIMARY KEY, owner TEXT, item TEXT,"
                 " total REAL, status TEXT)")
    existing = conn.execute("SELECT COUNT(*) FROM notes").fetchone()[0]
    if existing == 0:
        conn.executemany("INSERT INTO notes(id, body) VALUES (?, ?)", [
            ("1", "buy milk"), ("2", "call bob"), ("3", "deploy friday"),
            ("4", "rotate keys")])
    count = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    if count == 0:
        conn.executemany(
            "INSERT INTO orders(id, owner, item, total, status)"
            " VALUES (?, ?, ?, ?, ?)", [
                (1001, "alice", "Notebook", 12.50, "shipped"),
                (1002, "bob", "Backpack", 45.00, "pending"),
                (1003, "alice", "Umbrella", 8.25, "shipped"),
                (1004, "carol", "Laptop", 1200.00, "pending")])
    conn.commit()
    conn.close()


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FILES_DIR = os.path.join(BASE_DIR, "files")


def _ensure_files() -> None:
    """Create the download directory contents if absent."""
    os.makedirs(FILES_DIR, exist_ok=True)
    readme = os.path.join(FILES_DIR, "readme.txt")
    if not os.path.exists(readme):
        with open(readme, "w", encoding="utf-8") as handle:
            handle.write("vulnerable lab app\ndownload directory\n")
    outside = os.path.join(BASE_DIR, "flag.txt")
    if not os.path.exists(outside):
        with open(outside, "w", encoding="utf-8") as handle:
            handle.write("LAB-FLAG-9f3a2b -- proves path traversal reached "
                         "outside the download directory\n")


init_db()
_ensure_files()


def main() -> None:
    import uvicorn
    # 127.0.0.1 by default. See the module docstring.
    host = os.environ.get("LAB_HOST", "127.0.0.1")
    port = int(os.environ.get("LAB_PORT", "8000"))
    print(f"vulnerable lab app on http://{host}:{port}  (intentionally broken)")
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()